/*
Navicat MySQL Data Transfer

Source Server         : Local MySql
Source Server Version : 50616
Source Host           : localhost:3307
Source Database       : calidad

Target Server Type    : MYSQL
Target Server Version : 50616
File Encoding         : 65001

Date: 2015-12-21 16:38:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for actividades
-- ----------------------------
DROP TABLE IF EXISTS `actividades`;
CREATE TABLE `actividades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USUARIO` varchar(255) DEFAULT NULL,
  `DESCRIPCION` varchar(255) DEFAULT NULL,
  `TIPO` varchar(255) DEFAULT NULL,
  `OPERACION` varchar(255) DEFAULT NULL,
  `FECHA_INICIO` date DEFAULT NULL,
  `FECHA_FIN` date DEFAULT NULL,
  `ESTADO` varchar(255) DEFAULT NULL,
  `PRIORIDAD` int(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `FECHA_CIERRE` date DEFAULT NULL,
  `OFICINA` varchar(2) DEFAULT NULL,
  `CLIENTES` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `us` (`USUARIO`),
  CONSTRAINT `actividades_ibfk_1` FOREIGN KEY (`USUARIO`) REFERENCES `usuario` (`user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for actividades_productos
-- ----------------------------
DROP TABLE IF EXISTS `actividades_productos`;
CREATE TABLE `actividades_productos` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESCRIPCION` varchar(255) DEFAULT NULL,
  `TIPO` varchar(50) DEFAULT NULL,
  `FECHA_INICIO` date DEFAULT NULL,
  `FECHA_FIN` date DEFAULT NULL,
  `ESTADO` varchar(50) DEFAULT NULL,
  `USUARIO` varchar(50) DEFAULT NULL,
  `APLICATIVO` varchar(50) DEFAULT NULL,
  `DETALLES` longtext,
  `PRIORIDAD` int(11) DEFAULT NULL,
  `FECHA_CIERRE` date DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `USS` (`USUARIO`) USING BTREE,
  CONSTRAINT `USS` FOREIGN KEY (`USUARIO`) REFERENCES `usuario` (`user`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for alertas
-- ----------------------------
DROP TABLE IF EXISTS `alertas`;
CREATE TABLE `alertas` (
  `CODIGO` int(11) NOT NULL,
  `DESCRIPCION` varchar(255) DEFAULT NULL,
  `CAMPO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CODIGO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for archivo_subido
-- ----------------------------
DROP TABLE IF EXISTS `archivo_subido`;
CREATE TABLE `archivo_subido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `archivo` varchar(255) DEFAULT NULL,
  `fecha_subida` date DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for banca
-- ----------------------------
DROP TABLE IF EXISTS `banca`;
CREATE TABLE `banca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_banca` varchar(255) DEFAULT NULL,
  `Opcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for campos
-- ----------------------------
DROP TABLE IF EXISTS `campos`;
CREATE TABLE `campos` (
  `CAMPO` varchar(255) NOT NULL,
  `TABLA` varchar(255) DEFAULT NULL,
  `DESCRIPCION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CAMPO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for campos_remediados
-- ----------------------------
DROP TABLE IF EXISTS `campos_remediados`;
CREATE TABLE `campos_remediados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_remediacion` int(11) DEFAULT NULL,
  `tabla` varchar(255) DEFAULT NULL,
  `campo` varchar(255) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for cheque
-- ----------------------------
DROP TABLE IF EXISTS `cheque`;
CREATE TABLE `cheque` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CLIENTE` int(11) DEFAULT NULL,
  `NOMBRE` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `OFICINA` varchar(255) DEFAULT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  `BANCA` int(11) DEFAULT NULL,
  `BANCO` varchar(255) DEFAULT 'BOD',
  `FECHA` date DEFAULT NULL,
  `TELEFONO1` varchar(255) DEFAULT NULL,
  `TELEFONO2` varchar(255) DEFAULT NULL,
  `TELEFONO3` varchar(255) DEFAULT NULL,
  `CORREO` varchar(255) DEFAULT NULL,
  `ESTATUS` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=267941 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for cheque_devuelto
-- ----------------------------
DROP TABLE IF EXISTS `cheque_devuelto`;
CREATE TABLE `cheque_devuelto` (
  `BANCO` varchar(255) DEFAULT NULL,
  `FECHA` date DEFAULT NULL,
  `BANCA` varchar(255) DEFAULT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  `NomEjecutivo` varchar(255) DEFAULT NULL,
  `PropAgencia` int(255) DEFAULT NULL,
  `ClienteEsp` varchar(255) DEFAULT NULL,
  `NoCliente` varchar(255) DEFAULT NULL,
  `TipoPer` varchar(255) DEFAULT NULL,
  `Identifiacion` varchar(255) DEFAULT NULL,
  `NomCliente` varchar(255) DEFAULT NULL,
  `Telefono1` varchar(255) DEFAULT NULL,
  `Telefono2` varchar(255) DEFAULT NULL,
  `Telefono3` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `NoRegistro` int(11) NOT NULL AUTO_INCREMENT,
  `Estado_envio` int(11) DEFAULT '0',
  `Error_local` int(11) DEFAULT '0',
  `Error_celular` int(11) DEFAULT '0',
  `Error_email` int(11) DEFAULT '0',
  `Archivo` int(255) DEFAULT NULL,
  `Error_contacto` int(11) DEFAULT '0',
  PRIMARY KEY (`NoRegistro`)
) ENGINE=InnoDB AUTO_INCREMENT=237199 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for clientes_db
-- ----------------------------
DROP TABLE IF EXISTS `clientes_db`;
CREATE TABLE `clientes_db` (
  `CLIENT` int(11) NOT NULL,
  `TIPOPE` varchar(255) NOT NULL,
  `IDENTF` varchar(255) NOT NULL,
  `NOMBRE_IBS` varchar(255) DEFAULT NULL,
  `NOMBRE_DB` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CLIENT`,`TIPOPE`,`IDENTF`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for clientes_tbl
-- ----------------------------
DROP TABLE IF EXISTS `clientes_tbl`;
CREATE TABLE `clientes_tbl` (
  `CLIENT` int(11) NOT NULL,
  `NOMBRE` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `IDENTF` int(11) NOT NULL,
  `OFICINA` int(11) DEFAULT NULL,
  `EJECUTIVO` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `BANCA` int(255) DEFAULT NULL,
  PRIMARY KEY (`CLIENT`,`IDENTF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for cognos
-- ----------------------------
DROP TABLE IF EXISTS `cognos`;
CREATE TABLE `cognos` (
  `mejora` varchar(255) DEFAULT NULL,
  `reportado` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL COMMENT 'cerrado pendiente eliminado',
  `observaciones` text,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for cpsolicitudes
-- ----------------------------
DROP TABLE IF EXISTS `cpsolicitudes`;
CREATE TABLE `cpsolicitudes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) DEFAULT NULL,
  `tipo` varchar(255) DEFAULT NULL,
  `codigo_tabla` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `fecha_recibida` date DEFAULT NULL,
  `fecha_cierre` date DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `sistema` varchar(255) DEFAULT NULL,
  `prioridad` varchar(255) DEFAULT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=742 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for dbclientes
-- ----------------------------
DROP TABLE IF EXISTS `dbclientes`;
CREATE TABLE `dbclientes` (
  `TIPOPE` varchar(255) DEFAULT NULL,
  `IDENTF` int(11) NOT NULL,
  `DBORIGEN` varchar(255) NOT NULL,
  `TIPOID` varchar(255) DEFAULT NULL,
  `NOMB1` varchar(255) DEFAULT NULL,
  `NOMB2` varchar(255) DEFAULT NULL,
  `APELL1` varchar(255) DEFAULT NULL,
  `APELL2` varchar(255) DEFAULT NULL,
  `NOMCOM` varchar(255) DEFAULT NULL,
  `SEXO` varchar(255) DEFAULT NULL,
  `ESTCIVIL` varchar(255) DEFAULT NULL,
  `PROFESION` varchar(255) DEFAULT NULL,
  `ACTECO` varchar(255) DEFAULT NULL,
  `LUGNAC` varchar(255) DEFAULT NULL,
  `FECNAC` varchar(255) DEFAULT NULL,
  `PAISID` varchar(255) DEFAULT NULL,
  `NACIONALIDAD` varchar(255) DEFAULT NULL,
  `NIVACA` varchar(255) DEFAULT NULL,
  `NUMHIJOS` varchar(255) DEFAULT NULL,
  `TIPOVIA` varchar(255) DEFAULT NULL,
  `NOMVIA` varchar(255) DEFAULT NULL,
  `TIPOIMB` varchar(255) DEFAULT NULL,
  `NOMIMB` varchar(255) DEFAULT NULL,
  `NUMIMB` varchar(255) DEFAULT NULL,
  `TIPOPISO` varchar(255) DEFAULT NULL,
  `NUMPISO` varchar(255) DEFAULT NULL,
  `TIPOSEC` varchar(255) DEFAULT NULL,
  `NOMSEC` varchar(255) DEFAULT NULL,
  `PAIS` varchar(255) DEFAULT NULL,
  `ESTADO` varchar(255) DEFAULT NULL,
  `CIUDAD` varchar(255) DEFAULT NULL,
  `MUNICIPIO` varchar(255) DEFAULT NULL,
  `PARROQUIA` varchar(255) DEFAULT NULL,
  `ZONAPOS` varchar(255) DEFAULT NULL,
  `EMPRESA` varchar(255) DEFAULT NULL,
  `CARGO` varchar(255) DEFAULT NULL,
  `TIPOSERV` varchar(255) DEFAULT NULL,
  `INGRESOS` varchar(255) DEFAULT NULL,
  `INGOTROS` varchar(255) DEFAULT NULL,
  `TIPOVIA_T` varchar(255) DEFAULT NULL,
  `NOMVIA_T` varchar(255) DEFAULT NULL,
  `TIPOIMB_T` varchar(255) DEFAULT NULL,
  `NOMIMB_T` varchar(255) DEFAULT NULL,
  `NUMIMB_T` varchar(255) DEFAULT NULL,
  `TIPOPISO_T` varchar(255) DEFAULT NULL,
  `NUMPISO_T` varchar(255) DEFAULT NULL,
  `TIPOSEC_T` varchar(255) DEFAULT NULL,
  `NOMSEC_T` varchar(255) DEFAULT NULL,
  `PAIS_T` varchar(255) DEFAULT NULL,
  `ESTADO_T` varchar(255) DEFAULT NULL,
  `CIUDAD_T` varchar(255) DEFAULT NULL,
  `MUNICIPIO_T` varchar(255) DEFAULT NULL,
  `PARROQUIA_T` varchar(255) DEFAULT NULL,
  `ZONAPOST_T` varchar(255) DEFAULT NULL,
  `DIR_PRINCIPAL` varchar(255) DEFAULT NULL,
  `DIR_TRABAJO` varchar(255) DEFAULT NULL,
  `CLI_RIF` varchar(255) DEFAULT NULL,
  `EMP_RIF` varchar(255) DEFAULT NULL,
  `ESTATUS` varchar(255) DEFAULT NULL,
  `TELFHAB` varchar(255) DEFAULT NULL,
  `TELFCON` varchar(255) DEFAULT NULL,
  `TEFLFAX` varchar(255) DEFAULT NULL,
  `TELFTRA` varchar(255) DEFAULT NULL,
  `TELF01` varchar(255) DEFAULT NULL,
  `TELF02` varchar(255) DEFAULT NULL,
  `TELF03` varchar(255) DEFAULT NULL,
  `TELF04` varchar(255) DEFAULT NULL,
  `TELF05` varchar(255) DEFAULT NULL,
  `TELF06` varchar(255) DEFAULT NULL,
  `TELF07` varchar(255) DEFAULT NULL,
  `TELF08` varchar(255) DEFAULT NULL,
  `TELF09` varchar(255) DEFAULT NULL,
  `TELF10` varchar(255) DEFAULT NULL,
  `TELF11` varchar(255) DEFAULT NULL,
  `TELF12` varchar(255) DEFAULT NULL,
  `TELF13` varchar(255) DEFAULT NULL,
  `TELF14` varchar(255) DEFAULT NULL,
  `TELF15` varchar(255) DEFAULT NULL,
  `TELF16` varchar(255) DEFAULT NULL,
  `TELF17` varchar(255) DEFAULT NULL,
  `TELF18` varchar(255) DEFAULT NULL,
  `TELF19` varchar(255) DEFAULT NULL,
  `TELF20` varchar(255) DEFAULT NULL,
  `EMAIL01` varchar(255) DEFAULT NULL,
  `EMAIL02` varchar(255) DEFAULT NULL,
  `EMAIL03` varchar(255) DEFAULT NULL,
  `EMAIL04` varchar(255) DEFAULT NULL,
  `EMAIL05` varchar(255) DEFAULT NULL,
  `GSE` varchar(255) DEFAULT NULL,
  `CARACT` text,
  PRIMARY KEY (`IDENTF`,`DBORIGEN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for direccion
-- ----------------------------
DROP TABLE IF EXISTS `direccion`;
CREATE TABLE `direccion` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ZONA_POSTAL` varchar(255) DEFAULT NULL,
  `COD_AREA` varchar(255) DEFAULT NULL,
  `SECTOR` varchar(255) DEFAULT NULL,
  `PARROQUIA` varchar(255) DEFAULT NULL,
  `MUNICIPIO` varchar(255) DEFAULT NULL,
  `CIUDAD` varchar(255) DEFAULT NULL,
  `ESTADO` varchar(255) DEFAULT NULL,
  `COD_PARROQUIA` varchar(255) DEFAULT NULL,
  `COD_MUNICIPIO` varchar(255) DEFAULT NULL,
  `COD_CIUDAD` varchar(255) DEFAULT NULL,
  `COD_ESTADO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34227 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for fechas
-- ----------------------------
DROP TABLE IF EXISTS `fechas`;
CREATE TABLE `fechas` (
  `FECHA` date DEFAULT NULL,
  `holdad` varchar(255) DEFAULT NULL,
  `holdam` varchar(255) DEFAULT NULL,
  `holday` varchar(255) DEFAULT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=768 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for gestiones
-- ----------------------------
DROP TABLE IF EXISTS `gestiones`;
CREATE TABLE `gestiones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  `tipo` char(2) NOT NULL,
  `user` varchar(30) NOT NULL,
  `fechaini` date DEFAULT NULL,
  `fechafin` date DEFAULT NULL,
  `campo` varchar(30) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `estado` varchar(255) NOT NULL,
  `prioridad` int(11) DEFAULT NULL,
  `detalles` text,
  `aplicativo` varchar(255) DEFAULT NULL,
  `cierre` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  CONSTRAINT `gestiones_ibfk_1` FOREIGN KEY (`user`) REFERENCES `usuario` (`user`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for masivo_clientes
-- ----------------------------
DROP TABLE IF EXISTS `masivo_clientes`;
CREATE TABLE `masivo_clientes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_CONFIG` int(11) DEFAULT NULL,
  `CLIENTE` int(11) NOT NULL,
  `NOMBRE` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` int(11) DEFAULT NULL,
  `CAMPO` varchar(255) DEFAULT NULL,
  `OFICINA` int(255) DEFAULT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`,`CLIENTE`)
) ENGINE=InnoDB AUTO_INCREMENT=84120 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for masivo_config
-- ----------------------------
DROP TABLE IF EXISTS `masivo_config`;
CREATE TABLE `masivo_config` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TIPO` varchar(255) DEFAULT NULL,
  `CLASIFICACION` varchar(255) DEFAULT NULL,
  `ASUNTO` text,
  `CAMPO` varchar(255) DEFAULT NULL,
  `USUARIO` varchar(255) DEFAULT NULL,
  `FECHA_SUBIDA` date DEFAULT NULL,
  `CANTIDAD` int(11) DEFAULT NULL,
  `DESCRIPCION` varchar(255) DEFAULT NULL,
  `ESTATUS` varchar(255) DEFAULT 'Pendiente',
  `ULT_ENVIO` date DEFAULT NULL,
  `RECORDAR` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for monitorplus
-- ----------------------------
DROP TABLE IF EXISTS `monitorplus`;
CREATE TABLE `monitorplus` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `BANCO` int(11) DEFAULT NULL,
  `AGENCIA` int(11) DEFAULT NULL,
  `CLIENTE` varchar(255) NOT NULL,
  `NOMCLIENTE` varchar(255) DEFAULT NULL,
  `USUARIO` varchar(255) DEFAULT NULL,
  `CUENTA` varchar(255) DEFAULT NULL,
  `BANCA` int(11) DEFAULT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  `CONDICION` int(11) DEFAULT NULL,
  `FECHARECEP` date DEFAULT NULL COMMENT 'FECHA RECEPCION',
  `FECHAAPER` date DEFAULT NULL COMMENT 'FECHA APRETURA',
  `ENCARGADO` char(255) DEFAULT NULL,
  `ESTADO_ENVIO` int(1) DEFAULT '0',
  `ARCHIVO` int(11) DEFAULT NULL,
  `IDENTIFICACION` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8770 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for observaciones
-- ----------------------------
DROP TABLE IF EXISTS `observaciones`;
CREATE TABLE `observaciones` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACTIVIDAD` int(11) DEFAULT NULL,
  `TIPO` varchar(255) DEFAULT NULL,
  `OBSERVACION` text,
  `FECHA` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for observaciones_cognos
-- ----------------------------
DROP TABLE IF EXISTS `observaciones_cognos`;
CREATE TABLE `observaciones_cognos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comentario` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `id_cognos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for oficinas
-- ----------------------------
DROP TABLE IF EXISTS `oficinas`;
CREATE TABLE `oficinas` (
  `OFICINA` int(11) NOT NULL DEFAULT '0',
  `NOMBRE_OFICINA` varchar(255) DEFAULT NULL,
  `EMAIL` text,
  PRIMARY KEY (`OFICINA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for remediaciones
-- ----------------------------
DROP TABLE IF EXISTS `remediaciones`;
CREATE TABLE `remediaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `aplicativo` varchar(255) DEFAULT NULL,
  `usuario` varchar(255) DEFAULT NULL,
  `campos` int(11) DEFAULT NULL COMMENT 'almacena la cantidad de campos remediados',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for solicitudes
-- ----------------------------
DROP TABLE IF EXISTS `solicitudes`;
CREATE TABLE `solicitudes` (
  `ID_SOLICITUD` int(11) NOT NULL AUTO_INCREMENT,
  `PRIORIDAD` varchar(255) CHARACTER SET latin1 DEFAULT 'URGENTE',
  `FECHA_ENVIO` date DEFAULT NULL,
  `TIPO_GESTION` varchar(255) CHARACTER SET latin1 NOT NULL,
  `CLASIFICACION` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ESTADO` varchar(255) CHARACTER SET latin1 DEFAULT 'ABIERTA',
  `FECHA_CIERRE` date DEFAULT NULL,
  `BANCO` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `OFICINA` int(255) DEFAULT NULL,
  `CLIENTE` int(255) NOT NULL,
  `EJECUTIVO` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `ALERTA` int(255) DEFAULT NULL,
  `FECHA_RECEPCION` date DEFAULT NULL,
  `USUARIO_ENCARGADO` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `BANCA` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `CAMPOS` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `COMENTARIO` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `CERRADO` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `NOMBRE_CLIENTE` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `IDENTIFICACION` int(255) DEFAULT NULL,
  `DESCRIPCION` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `CONFIG_MA` int(255) DEFAULT NULL,
  `NUM_ENVIOS` int(11) DEFAULT '1',
  PRIMARY KEY (`ID_SOLICITUD`)
) ENGINE=InnoDB AUTO_INCREMENT=298927 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for solicitudes2
-- ----------------------------
DROP TABLE IF EXISTS `solicitudes2`;
CREATE TABLE `solicitudes2` (
  `ID_SOLICITUD` int(11) NOT NULL AUTO_INCREMENT,
  `PRIORIDAD` varchar(255) DEFAULT 'Urgente' COMMENT 'URGENTE',
  `FECHA_ENVIO` date DEFAULT NULL,
  `TIPO_GESTION` varchar(255) NOT NULL,
  `EST_ENVIO` varchar(255) DEFAULT NULL COMMENT '1 enviado, 0 no enviado',
  `ESTADO` varchar(255) DEFAULT 'ABIERTA',
  `FECHA_CIERRE` date DEFAULT NULL,
  `BANCO` varchar(255) DEFAULT NULL,
  `OFICINA` int(255) DEFAULT NULL,
  `CLIENTE` varchar(255) NOT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  `ALERTA` varchar(255) DEFAULT NULL,
  `CUENTA` varchar(255) DEFAULT NULL,
  `FECHA_APERTURA` date DEFAULT NULL,
  `FECHA_RECEPCION` date DEFAULT NULL,
  `USUARIO_ENCARGADO` varchar(255) DEFAULT NULL,
  `BANCA` varchar(255) DEFAULT NULL,
  `CAMPOS` varchar(255) DEFAULT NULL,
  `COMENTARIO` varchar(255) DEFAULT NULL,
  `TIPO_CLIENTE` varchar(255) DEFAULT NULL,
  `NOMBRE_CLIENTE` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `DESCRIPCION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID_SOLICITUD`,`CLIENTE`,`TIPO_GESTION`)
) ENGINE=InnoDB AUTO_INCREMENT=342397 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for usuario
-- ----------------------------
DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `nombre` varchar(50) NOT NULL,
  `cedula` varchar(10) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `fechanac` date DEFAULT NULL,
  `user` varchar(50) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `rango` int(11) DEFAULT '0',
  `keypass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
