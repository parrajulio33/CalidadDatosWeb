<?php

namespace Calidad\GestionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GestionBundle extends Bundle
{
}
