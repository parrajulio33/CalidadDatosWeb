<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

set_time_limit ( 0 );
date_default_timezone_set('America/Caracas');


$link = mysql_connect('calidad4', 'gsilva', 'Bod12345') or die('No se pudo conectar: ' . mysql_error());
mysql_select_db('db_clientes') or die('No se pudo seleccionar la base de datos');


class ClientesController extends Controller
{
	public function ClientesAction(Request $request)
    {
    	$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");

        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }


        
        $query = "SELECT A.NumerodeCliente AS CL,A.TipodePersona AS TP,A.NumerodeIdentificacion AS ID,A.NombreLegal AS NOM FROM tabla_calidad AS A INNER JOIN dbclientes AS B ON A.NumerodeIdentificacion = B.IDENTF GROUP BY A.NumerodeCliente LIMIT 100";

        $result = mysql_query($query);

        $rows = "";


 		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)){
 			$rows .= "<tr>
 				<td><a onClick='BuscarClientes(\"".$line['ID']."\",\"".$line['CL']."\")'>".$line['NOM']."</a></td>
 				<td class='text-center'>".$line['CL']."</td>
 				<td class='text-center'>".trim($line['TP'])."</td>
 				<td class='text-center'>".$line['ID']."</td>
 				</tr>";
 		}
        
        

        

        

        return $this->render('GestionBundle:Default:clientes.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                "rows" 		=>  $rows
                )
            );
    }



    function BuscarClienteAction(Request $request)
    {
    	$response = array("code"=>404);
    	$id = $request->get("id");
    	$client = $request ->get("client");

    	$tabs = '';
    	$panel_tabs = '';

    	$query = "SELECT ";
		$query .= "A.TIPOPE, A.IDENTF, A.DBORIGEN, A.TIPOID, IF(LTRIM(RTRIM(A.NOMCOM)) IS NULL ,CONCAT(A.APELL1,' ',A.APELL2,', ',A.NOMB1,' ',A.NOMB2),A.NOMCOM) AS NOMBRE, ";
		$query .= "A.SEXO, A.ESTCIVIL, A.PROFESION, A.ACTECO, A.LUGNAC, A.FECNAC, A.PAISID, A.NACIONALIDAD, A.NIVACA, A.NUMHIJOS, A.TIPOVIA, A.NOMVIA, A.TIPOIMB, ";
		$query .= "A.NOMIMB, A.NUMIMB, A.TIPOPISO, A.NUMPISO, A.TIPOSEC, A.NOMSEC, A.PAIS, A.ESTADO, A.CIUDAD, A.MUNICIPIO, A.PARROQUIA, A.ZONAPOS, A.EMPRESA, ";
		$query .= "A.CARGO, A.TIPOSERV, A.INGRESOS, A.INGOTROS, A.TIPOVIA_T, A.NOMVIA_T, A.TIPOIMB_T, A.NOMIMB_T, A.NUMIMB_T, A.TIPOPISO_T, A.NUMPISO_T, ";
		$query .= "A.TIPOSEC_T, A.NOMSEC_T, A.PAIS_T, A.ESTADO_T, A.CIUDAD_T, A.MUNICIPIO_T, A.PARROQUIA_T, A.ZONAPOST_T, A.DIR_PRINCIPAL, A.DIR_TRABAJO, ";
		$query .= "A.CLI_RIF, A.EMP_RIF, A.ESTATUS, A.TELFHAB, A.TELFCON, A.TEFLFAX, A.TELFTRA, A.TELF01, A.TELF02, A.TELF03, A.TELF04, A.TELF05, A.TELF06, ";
		$query .= "A.TELF07, A.TELF08, A.TELF09,  A.TELF10,  A.TELF11, A.TELF12, A.TELF13, A.TELF14, A.TELF15, A.TELF16, A.TELF17, A.TELF18, A.TELF19, A.TELF20, ";
		$query .= "A.EMAIL01, A.EMAIL02, A.EMAIL03, A.EMAIL04, A.EMAIL05, A.GSE ";
		$query .= "FROM ";
		$query .= "dbclientes AS A ";
		$query .= "WHERE ";
		$query .= "A.IDENTF = '$id' ";


		$result = mysql_query($query);
		$active = "active";
 		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)){
 			$tabs .= '<li role="presentation" class="'.$active.'">';
			$tabs .= '<a href="#'.$line['DBORIGEN'].'" aria-controls="home" role="tab" data-toggle="tab"><b>'.$line['DBORIGEN'].'</b></a>';
			$tabs .= '</li>';

			$panel_tabs .= $this->getHtml($line,$client,$line['DBORIGEN'],$active);
			$active = "";
		}

		if($tabs != "" && $panel_tabs != "")
		{
			$response = array("code"=> 401,"tabs"=>$tabs,"panel_tabs"=>$panel_tabs);
		}else
		{
			$response = array("code"=> 404,"tabs"=>$tabs,"panel_tabs"=>$panel_tabs);
		}


    	return new Response(json_encode($response));
    }





    function getHtml($line,$numero,$dborigen,$class){
    	$html = "";
    	$html .= '<div role="tabpanel" class="tab-pane '.$class.'" id="'.$dborigen.'">';
		$html .= '	<div class="row">';
		$html .= '		<br>';

		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '			<b>Datos Personales</b>';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Numero de Cliente</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.$numero.'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-6">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre del Cliente</label>';
		$html .= '				<input class="form-control" disabled="true" value="'.utf8_decode($line['NOMBRE']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo de Persona</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOPE']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Identificacion</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['IDENTF']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo de Documento</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOID']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Pais Emisor del Documento</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['PAISID']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nacionalidad</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NACIONALIDAD']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Sexo</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['SEXO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Fecha de Nacimiento</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['FECNAC']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Lugar de Nacimiento</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['LUGNAC']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Numero de Hijos</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NUMHIJOS']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Estrato Social</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['GSE']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Estado Civil</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['ESTCIVIL']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<br>';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '				<b>Datos de Profesión u Oficio</b>';
		$html .= '			</div>';
		$html .= '		</div>';


		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nivel Academico</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NIVACA']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Profesión</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['PROFESION']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-8">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Actividad Economica</label>';
		$html .= '				<input class="form-control" disabled="true"  value="'.utf8_decode($line['ACTECO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';


		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<br>';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '				<b>Datos de Empleo</b>';
		$html .= '			</div>';
		$html .= '		</div>';




		$html .= '		<div class="col-md-6">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre de la Empresa</label>';
		$html .= '				<input class="form-control" disabled="true"  value="'.utf8_decode($line['EMPRESA']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Rif</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['EMP_RIF']).'">';
		$html .= '			</div>';
		$html .= '		</div>';
				
		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo de Servicio</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOSERV']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Cargo</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['CARGO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Estatus</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['ESTATUS']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Ingresos</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['INGRESOS']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Otros Ingresos</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['INGOTROS']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<br>';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '				<b>Datos de Localización - Dirección de Habitación</b>';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center" >';
		$html .= '			<h4>';
		$html .= '				<span class="label label-primary" style="border-radius: 0px;">Direccion Compactada';
							
		$html .= '				</span></h4>';
		$html .= '			<hr>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Direccion de Habitacion</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['DIR_PRINCIPAL']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<h4>';
		$html .= '				<span class="label label-primary" style="border-radius: 0px;">Direccion Estructurada';							
		$html .= '				</span>';
		$html .= '			</h4>';
		$html .= '			<hr>';
		$html .= '		</div>';


		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo De Vía</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOVIA']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-10">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre De La Vía</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NOMVIA']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo De Inmueble</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOIMB']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Número De Inmueble</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NUMIMB']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre Del Inmueble</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NOMIMB']).'">';
		$html .= '			</div>';
		$html .= '		</div>';


		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo De Piso</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOPISO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Número De Piso</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NUMPISO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Sector</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOSEC']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-10">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre Del Sector</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NOMSEC']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">País</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['PAIS']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Estado</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['ESTADO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Ciudad</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['CIUDAD']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Municipio</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['MUNICIPIO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Parroquia</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['PARROQUIA']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Zona Postal</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['ZONAPOS']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<br>';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '				<b>Datos de Localización - Dirección de Trabajo</b>';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center" >';
		$html .= '			<h4>';
		$html .= '				<span class="label label-primary" style="border-radius: 0px;">Direccion Compactada';
							
		$html .= '				</span></h4>';
		$html .= '			<hr>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Direccion de Trabajo</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['DIR_TRABAJO']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<h4>';
		$html .= '				<span class="label label-primary" style="border-radius: 0px;">Direccion Estructurada';
							
		$html .= '				</span>';
		$html .= '			</h4>';
		$html .= '			<hr>';
		$html .= '		</div>';


		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo De Vía</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOVIA_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-10">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre De La Vía</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NOMVIA_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo De Inmueble</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOIMB_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Número De Inmueble</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NUMIMB_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre Del Inmueble</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NOMIMB_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';


		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Tipo De Piso</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOPISO_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Número De Piso</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NUMPISO_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Sector</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TIPOSEC_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-10">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Nombre Del Sector</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['NOMSEC_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">País</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['PAIS_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Estado</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['ESTADO_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Ciudad</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['CIUDAD_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Municipio</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['MUNICIPIO_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Parroquia</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['PARROQUIA_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-2">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Zona Postal</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['ZONAPOST_T']).'">';
		$html .= '			</div>';
		$html .= '		</div>';



		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<br>';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '				<b>Telefono de Contactos</b>';
		$html .= '			</div>';
		$html .= '		</div>';



		for ($i=1; $i < 20; $i++) { 			
			if(trim($line['TELF'.str_pad($i, 2, "0", STR_PAD_LEFT)]) != '' ){
				$html .= '		<div class="col-md-2">';
				$html .= '			<div class="form-group">';
				$html .= '				<label class="label-control">Teléfono</label>';
				$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['TELF'.str_pad($i, 2, "0", STR_PAD_LEFT)]).'">';
				$html .= '			</div>';
				$html .= '		</div>';
			}
		}
		


		$html .= '		<div class="col-md-12 text-center">';
		$html .= '			<br>';
		$html .= '			<div class="alert alert-success" style="border-radius: 0px; padding: 5px; backgroud:#5cb85c;">';
		$html .= '				<b>Correos Electronicos</b>';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Correo 1</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['EMAIL01']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Correo 2</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['EMAIL02']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Correo 3</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['EMAIL03']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Correo 4</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['EMAIL04']).'">';
		$html .= '			</div>';
		$html .= '		</div>';

		$html .= '		<div class="col-md-4">';
		$html .= '			<div class="form-group">';
		$html .= '				<label class="label-control">Correo 5</label>';
		$html .= '				<input class="form-control text-center" disabled="true"  value="'.utf8_decode($line['EMAIL05']).'">';
		$html .= '			</div>';
		$html .= '		</div>';
		$html .= '	</div>';

		$html .= '</div>';

		return $html;

    }





















}//end class