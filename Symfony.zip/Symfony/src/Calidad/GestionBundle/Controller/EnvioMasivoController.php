<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;

use Calidad\GestionBundle\Entity\MasivoConfig;
use Calidad\GestionBundle\Entity\MasivoClientes;

set_time_limit ( 0 );
date_default_timezone_set('America/Caracas');

class EnvioMasivoController extends Controller
{
	public function IndexAction(Request $request)
    {
 		$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto"); 



        return $this->render('GestionBundle:Default:masivo.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                )
            );


    }


    public function RegistrarEnvioAction(Request $request)
    {
 		
    	$motivo = $request->get("motivo");
		$tipo 	= $request->get("tipo");
		$campo 	= $request->get("campo");
		$asunto = $request->get("asunto");

		

		if(isset($_FILES['file1'])){
        	
        	$Nombre_Archivo = $_FILES['file1']['name'];
        	$Ruta_Archivo   = $_FILES['file1']['tmp_name'];
        	$Tipo_Archivo   = $_FILES['file1']['type'];

        	$XLFileType = \PHPExcel_IOFactory::identify($Ruta_Archivo);
        	$objReader = \PHPExcel_IOFactory::createReader($XLFileType);  
        	$objPHPExcel = $objReader->load($Ruta_Archivo);


        	$MaxRow = $objPHPExcel->getActiveSheet()->getHighestRow();
        	$MaxColumn = $objPHPExcel->getActiveSheet()->getHighestColumn(); 
        
        	$sheet = $objPHPExcel->getActiveSheet();


		    $em = $this->getDoctrine()->getManager();   

            for ($i = 2; $i <= $MaxRow ; $i++)
            {
                if($sheet->getCell('A'.$i)->getValue()){
                    $cheque = new Cheque();

                    $cheque->setCliente(            $sheet->getCell('V'.$i)->getValue());
                    $cheque->setNombre(             $sheet->getCell('Y'.$i)->getValue());
                    $cheque->setIdentificacion(     $sheet->getCell('X'.$i)->getValue());
                    $cheque->setOficina(            $sheet->getCell('P'.$i)->getValue());
                    $cheque->setEjecutivo(          $sheet->getCell('N'.$i)->getValue());
                    $cheque->setBanca(              $sheet->getCell('L'.$i)->getValue());
                    $cheque->setFecha(              $this->getFechaFormat($sheet->getCell('I'.$i)->getValue()));
                    $cheque->setTelefono1(          $sheet->getCell('Z'.$i)->getValue());
                    $cheque->setTelefono2(          $sheet->getCell('AA'.$i)->getValue());
                    $cheque->setTelefono3(          $sheet->getCell('AB'.$i)->getValue());
                    $cheque->setCorreo(             $sheet->getCell('AC'.$i)->getValue());

                    $em->persist($cheque);
                    $em->flush();

                    $em->clear();
                }

            }//for




        	
    	}else{
    		$session->getFlashBag()->add('error', "<label class='text-danger'>Error: Archivo No Procesado</label>");
    	}



 		return new Response(json_encode($response));
    }




}