<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;

use Calidad\GestionBundle\Entity\ObservacionesCognos;
use Calidad\GestionBundle\Entity\Observaciones;
use Calidad\GestionBundle\Entity\Solicitudes;
use Calidad\GestionBundle\Entity\Gestiones;
use Calidad\GestionBundle\Entity\Usuario;
use Calidad\GestionBundle\Entity\Cognos;

set_time_limit ( 0 );

class CognosController extends Controller
{

	public function CognosAction(Request $request)
    {
    	$session = $request->getSession();
 		
 		$nombre = $session->get("nombre");
 		$cargo = $session->get("cargo");
 		$rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");

        if(empty($nombre) && empty($user))
        {
        	return $this->redirect($this->generateUrl('index'), 301);
        }


        $repository = $this->getDoctrine()->getRepository('GestionBundle:Cognos');

        $result = $repository->findAll();


        $cognos_array = array();

        foreach($result as $cognos) {
        	
        	$id = $cognos->getId();
			$mejora = $cognos->getMejora();
			$reportado = $cognos->getReportado();
			$fecha = (!empty($cognos->getFecha())) ? date_format($cognos->getFecha(),"d/m/Y"): "";
			$estado = $cognos->getEstado();
			$observaciones = nl2br($cognos->getObservaciones());
			$usuario = $cognos->getUsuario()->getUser();


				
			array_push($cognos_array, 
				array(
					"id"=>$id,
					"mejora"=>$mejora,
					"reportado"=>$reportado,
					"fecha"=>$fecha,
					"estado"=>$estado,
					"usuario"=>$usuario
				));
        }


       
        return $this->render('GestionBundle:Default:cognos.html.twig',
        	array(
        		"UserType"=>$rango,
        		"username"=>$user,
        		"nombre"=>$nombre,
        		"cargo"=>$cargo,
        		"cognos"=>$cognos_array,
                "foto" => $foto
        		));
    }



    public function AgregarAction(Request $request)
    {
    	$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");



        $desc = $request->get("desc");
        $reportado = $request->get("repo");
        $fecha = $request->get("fech");
        $estado = $request->get("esta");


        $fecha= \DateTime::createFromFormat("d/m/Y", $fecha)->format("Y/m/d");


        $user2 = $this->getDoctrine()->getRepository("GestionBundle:Usuario")->findOneByUser($user);

        if(!empty($user2)){
            $cogno = new Cognos();
    		$cogno->setMejora($desc);
    		$cogno->setReportado($reportado);
    		$cogno->setFecha(new \DateTime($fecha));
    		$cogno->setEstado($estado);
    		$cogno->setUsuario($user2);


            $em = $this->getDoctrine()->getManager();
            $em->persist($cogno);
            $em->flush();
        }
        
        return $this->redirect($this->generateUrl('cognos'), 301);
    }


    public function ObservacionesAction(Request $request)
    {

        $id = $request->get("cognos");

        $repository = $this->getDoctrine()->getRepository('GestionBundle:ObservacionesCognos');
 
        $query = $repository->createQueryBuilder('g')
            ->where('g.idCognos = :id')
            ->setParameter('id', $id)
            ->orderBy('g.fecha', 'DESC')
            ->getQuery();
         
        $cognos = $query->getArrayResult();


        $Obs = "";


        /*Array ( [0] => Array ( [id] => 3 [comentario] => Hay que ajustar la generación del campo "ClienteGenerado" para ambos errores en Diagnostico. [fecha] => DateTime Object ( [date] => 2015-02-20 00:00:00 [timezone_type] => 3 [timezone] => Europe/Berlin ) [idCognos] => 3 ) )*/

        foreach ($cognos as $cog) {
           
            $comentario = $cog['comentario'];
            $fecha = (!empty($cog['fecha']) ) ? date_format($cog['fecha'],"d/m/Y"): "";

            $Obs .= "<tr><td>$comentario</td><td>$fecha</td></tr>";
        }

        if(!empty($Obs))
        {
            $response = array("code"=>401,"row"=>$Obs);
        }else{
            $response = array("code"=>404);
        }
        
        
        return new Response(json_encode($response));
    }


    public function AgregarObservacionesAction(Request $request)
    {
        $id_cognos = $request->get("cognos");
        $comentario = $request->get("comentario"); 
        


        $ObsCognos = new ObservacionesCognos();

        if(!empty($id_cognos) && !empty($comentario))
        {
            $ObsCognos->setComentario($comentario);
            $ObsCognos->setFecha(new \DateTime());
            $ObsCognos->setIdCognos($id_cognos);
        }

        $em = $this->getDoctrine()->getManager();

        $em->persist($ObsCognos);
        $em->flush();

        $response = array("code"=>401);
        return new Response(json_encode($response));
    }   


}//end class