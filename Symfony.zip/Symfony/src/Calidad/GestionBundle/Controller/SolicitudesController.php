<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;



use Calidad\GestionBundle\Entity\Cpsolicitudes;




set_time_limit(0);
date_default_timezone_set('America/Caracas');

class SolicitudesController extends Controller
{
	public function SolicitudesAction(Request $request)
	{

		$session = $request->getSession();

		$nombre = $session->get("nombre");
        $cargo  = $session->get("cargo");
        $rango  = $session->get("UserType");
        $user   = $session->get("user");
        $foto   = $session->get("foto");


        if(empty($nombre) && empty($user))
        {
        	return $this->redirect($this->generateUrl('index'), 301);
        }

        

        $solicitudes = null;


        if($rango == "Admin")
        {
        	$repository = $this->getDoctrine()
			    ->getRepository('GestionBundle:Cpsolicitudes');
			 
			$query = $repository->createQueryBuilder('cp')
			    ->orderBy('cp.fechaRecibida', 'DESC')
			    ->getQuery();
			 
			$solicitudes = $query->getArrayResult();

			
        }else
        {

        	$repository = $this->getDoctrine()
			    ->getRepository('GestionBundle:Cpsolicitudes');
			 
			$query = $repository->createQueryBuilder('cp')
				->where("cp.usuario = :usuario")
				->setParameter("usuario",$user)
			    ->orderBy('cp.fechaRecibida', 'DESC')
			    ->getQuery();
			 
			$solicitudes = $query->getArrayResult();

        }


		return $this->render('GestionBundle:Default:Solicitudes.html.twig',
    		array(
    			"UserType"=>$rango,
    			"username"=>strtoupper($user),
    			"nombre"=>$nombre,
    			"cargo"=>$cargo,
    			"foto"=>$foto,
    			"solicitud"=>$solicitudes
    		)
    	);
	}


	public function AgregarSolicitudAction(Request $request)
	{

		$session = $request->getSession();

		$user = $session->get("user");


		$response = array("code"=>404);


    	$fechaini = ( !empty($request->get("fechaini")) ) ? \DateTime::createFromFormat('d/m/Y', $request->get("fechaini"))->format('Y-m-d') : "";
    	$fechafin = ( !empty($request->get("fechafin")) ) ? \DateTime::createFromFormat('d/m/Y', $request->get("fechafin"))->format('Y-m-d') : "";


    	$Solicitud_cp = new Cpsolicitudes();

		$Solicitud_cp->setDescripcion($request->get("descripcion"));
		$Solicitud_cp->setTipo($request->get("tipo"));
		$Solicitud_cp->setCodigoTabla($request->get("codigo"));
		$Solicitud_cp->setEstado($request->get("estado"));
		

		if(!empty($fechaini)){
			$Solicitud_cp->setFechaRecibida(new \DateTime($fechaini));
		}

		if(!empty($fechafin)){
			$Solicitud_cp->setFechaCierre(new \DateTime($fechafin));
		}


		$Solicitud_cp->setArea($request->get("area"));
		$Solicitud_cp->setSistema($request->get("sistema"));
		$Solicitud_cp->setPrioridad($request->get("prioridad"));
		$Solicitud_cp->setObservacion($request->get("observacion"));
		$Solicitud_cp->setUsuario($user);



		$em = $this->getDoctrine()->getManager();
        $em->persist($Solicitud_cp);
        $em->flush();
		


        if($Solicitud_cp->getId() != null)
        {
        	$response = array("code"=>101);
        }

    	return new Response(json_encode($response));
	}



	function BuscarSolicitudAction(Request $request)
	{

		$response = array("code"=>404);

		$id = $request->get("id");


		$repository = $this->getDoctrine()
		    ->getRepository('GestionBundle:Cpsolicitudes');
		 
		$query = $repository->createQueryBuilder('cp')
		    ->where("cp.id = :id")
		    ->setParameter("id",$id)
		    ->orderBy('cp.fechaRecibida', 'DESC')
		    ->getQuery();
		 
		$solicitud = $query->getArrayResult();


		$Datos = Array(
		"descripcion" 	=> $solicitud[0]["descripcion"],
		"tipo" 			=> $solicitud[0]["tipo"],
		"codigoTabla" 	=> $solicitud[0]["codigoTabla"],
		"estado" 		=> $solicitud[0]["estado"],
		"fechaRecibida" => (!empty($solicitud[0]["fechaRecibida"])) ? date_format($solicitud[0]["fechaRecibida"], "d/m/Y"): "",
		"fechaCierre" 	=> (!empty($solicitud[0]["fechaCierre"])) ? date_format($solicitud[0]["fechaCierre"], "d/m/Y"): "",
		"area" 			=> $solicitud[0]["area"],
		"sistema" 		=> $solicitud[0]["sistema"],
		"prioridad" 	=> $solicitud[0]["prioridad"],
		"observacion" 	=> $solicitud[0]["observacion"],
		"usuario" 		=> $solicitud[0]["usuario"]);





		if(!empty($solicitud))
        {
        	$response = array("code"=>101,"sol"=>$Datos);
        }

    	return new Response(json_encode($response));
	}

	function CerrarSolicitudAction(Request $request)
	{

		$id = $request->get("id");

		$em = $this->getDoctrine()->getManager();
		$sol = $em->getRepository('GestionBundle:Cpsolicitudes')
        	->find($id);


		if(!empty($sol))
		{
			
			$sol->setFechaCierre(new \DateTime());
			$sol->setEstado("Cerrada");

			$em->flush();


			$response = array("code"=>101);
		}else{
			$response = array("code"=>404);
		}

    	return new Response(json_encode($response));
	}



}