<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;

use Calidad\GestionBundle\Entity\Observaciones;
use Calidad\GestionBundle\Entity\ActividadesProductos;
use Calidad\GestionBundle\Entity\Usuario;


//include_once('clases\class.phpmailer.php');
//include_once('clases\class.smtp.php');
set_time_limit ( 0 );
date_default_timezone_set('America/Caracas');

class ActividadesProductoController extends Controller
{

	public function GestionesAction(Request $request)
    {
 		$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo  = $session->get("cargo");
        $rango  = $session->get("UserType");
        $user   = $session->get("user");
        $foto   = $session->get("foto");


        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }

        $repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario')
            ->createQueryBuilder('Us')
            ->where('Us.area = :area')
            ->setParameter('area', 'Producto')
            ->orderBy('Us.nombre', 'ASC')
            ->getQuery();
 
        $usuario = $repository->getArrayResult();


        $repository = $this->getDoctrine()->getRepository("GestionBundle:ActividadesProductos");
        $actividades = $repository->findAll();

        $Actividades = Array();

        foreach ($actividades as $act) {

            
            $fecha_ini = $act->getFechaInicio();
            $fecha_fin = $act->getFechaFin();
            $fecha_cie = $act->getFechaCierre();

            
            $atraso = $this->getAtraso($fecha_fin,$fecha_cie);
            
           

            array_push($Actividades, 
                Array(
                    "id"=> $act->getId(),
                    "descripcion"=> $act->getDescripcion(),
                    "encargado"=> $act->getUsuario()->getNombre(),
                    "inicio"=>date_format($fecha_ini,"d/m/Y"),
                    "fin" => date_format($fecha_fin,"d/m/Y"),
                    "atraso" =>$atraso,
                    "estado" => $act->getEstado(),
                )
            );


        }





        return $this->render('GestionBundle:Default:actividades_producto.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                "usuarios"  =>  $usuario,
                "Datos"     =>  $Actividades,
                "Usuarios"  =>  $usuario,
                )
            );
    }





//=================================================================================================================




    public function RegistrarGestionAction(Request $request)
    {
        $session = $request->getSession();

        $rango = $session->get("UserType");
        $user = $session->get("user");
        $gestion = $request->get("gestion");

       

        //variables enviadas por post//////////////////////////

            $index = $request->get("index");
            $descripcion = $request->get("descripcion");
            $tipo = $request->get("tipo");
            $fecha_inicio = $request->get("fecha_inicio");
            $fecha_fin = $request->get("fecha_fin");
            $estado = $request->get("estado");
            $user = $request->get("user");
            $prioridad = $request->get("prioridad");
            $aplicacion = $request->get("aplicacion");
            $detalles = $request->get("detalles");

        ///////////////////////////////////////////////////////
        
        if($index != ""){
            $repository = $this->getDoctrine()->getRepository("GestionBundle:ActividadesProductos");
            $actividad = $repository->findOneById($index);
        }else{
            $actividad = new ActividadesProductos();
        }





        $repository= $this->getDoctrine()->getRepository('GestionBundle:Usuario');
        $usuario = $repository->findOneByUser($user);


        if($usuario){

            
            $actividad->setDescripcion($descripcion);
            $actividad->setTipo($tipo);
            $actividad->setFechaInicio(new \DateTime($this->convertFecha($fecha_inicio)));
            $actividad->setFechaFin(new \DateTime($this->convertFecha($fecha_fin)));
            $actividad->setEstado($estado);
            $actividad->setUsuario($usuario);
            $actividad->setAplicativo($aplicacion);
            $actividad->setDetalles($detalles);
            $actividad->setPrioridad($prioridad);

            $em = $this->getDoctrine()->getManager();
            $em->persist($actividad);
            $em->flush();

        }


        if($actividad->getId()){
           $response = array("code"=>401,"actividades"=>$this->getActividades());
        }else{
            $response = Array("code"=>404);
        }


        
        return new Response(json_encode($response));
        
    }


    public function RegistrarObservacionAction(Request $request){
        
        $gestion = $request->get("id");
        $Observacion = $request->get("Observacion");

        $response = array('code' =>404);

        $Observaciones = new Observaciones();

        
        $Observaciones->setActividad($gestion);
        $Observaciones->setTipo("ACT-PRO");
        $Observaciones->setObservacion($Observacion);
        $Observaciones->setFecha(new \DateTime());

        $em = $this->getDoctrine()->getManager();
        $em->persist($Observaciones);
        $em->flush();


        if($Observaciones->getId()){
            $response = array("code"=>401,);
        }

        return new Response(json_encode($response));

    }




    //####################################################################################################################################################3

    public function BuscarGestionAction(Request $request){
        
        $id = $request->get("id");


        $repository = $this->getDoctrine()->getRepository("GestionBundle:ActividadesProductos");
        $actividad = $repository->findOneById($id);


        $repository = $this->getDoctrine()->getRepository("GestionBundle:Observaciones");
        $query = $repository->createQueryBuilder('OBS')
            ->where('OBS.actividad = :act AND OBS.tipo = :type')
            ->setParameter('act', $id)
            ->setParameter('type', "ACT-PRO")
            ->getQuery();
         
        $observacion = $query->getResult();



        if($actividad){

            $row = "";
            if($observacion)
            {
                foreach ($observacion as $key) {
                    
                $row .= "<tr><td>".$key->getObservacion()."</td><td>".date_format($key->getFecha(),"d/m/Y")."</td></tr>";


                }
            }else{
                $row .= "<tr><td></td><td></td></tr>";

            }



            
            $response = array("code"=>401,
            "Id"            =>$actividad->getId(),
            "Descripcion"   =>$actividad->getDescripcion(),
            "Tipo"          =>$actividad->getTipo(),
            "FechaInicio"   =>date_format($actividad->getFechaInicio(),"d/m/Y"),
            "FechaFin"      =>date_format($actividad->getFechaFin(),"d/m/Y"),
            "Estado"        =>$actividad->getEstado(),
            "Aplicativo"    =>$actividad->getAplicativo(),
            "Detalles"      =>$actividad->getDetalles(),
            "Prioridad"     =>$actividad->getPrioridad(),
            "FechaCierre"   =>$actividad->getFechaCierre(),
            "Usuario"       =>$actividad->getUsuario()->getUser(),
            "observacion"   =>$row,
            );

        }else{
            $response = array("code"=>404);
        }
        
        

        return new Response(json_encode($response));


    }



    public function FinalizarGestionAction(Request $request)
    {
        
        $id = $request->get("id");




        $response = array("code"=>404);


        $repository = $this->getDoctrine()->getRepository("GestionBundle:ActividadesProductos");
        $actividad = $repository->findOneById($id);
        if($actividad){
            
            $actividad->setEstado("Finalizada");
            $actividad->setFechaCierre(new \DateTime());

            $em = $this->getDoctrine()->getManager();
            $em->persist($actividad);
            $em->flush();

            $response = array("code"=>401, "actividades" => $this->getActividades());

        }

        return new Response(json_encode($response));
    }



































    public function convertFecha($fecha){
        
        if($fecha != ""){
            $fecha = explode("/",$fecha);
            return $fecha[2]."/".$fecha[1]."/".$fecha[0];
        }else{
            return "";
        }

    }







    public function getActividades(){

        $pendientes = "";
        $finalizadas = "";
        
        $repository = $this->getDoctrine()->getRepository("GestionBundle:ActividadesProductos");
        $actividades = $repository->findAll();

        foreach ($actividades as $act) {
            
            
            
            
            $fecha_ini = $act->getFechaInicio();
            $fecha_fin = $act->getFechaFin();
            $fecha_cie = $act->getFechaCierre();

            $atraso = $this->getAtraso($fecha_fin,$fecha_cie);


            $fila = "<tr>".
                "<td>".$act->getId()."</td>".
                "<td>".$act->getDescripcion()."</td>".
                "<td>".$act->getUsuario()->getNombre()."</td>".
                "<td>".date_format($fecha_ini,"d/m/Y")."</td>".
                "<td>".date_format($fecha_fin,"d/m/Y")."</td>".
                '<td align="center">                                       
                    <div class="btn-group" align="center" style="width: 100%;">
                        <a class="dropdown-toggle opt" type="button" data-toggle="dropdown">
                            <b>OPCIONES</b>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right" style="cursor: pointer">
                            <li><a onclick="buscar('.$act->getId().')">Mostrar Informacion</a></li>
                            <li><a onclick="buscar('.$act->getId().')">Mostrar Observaciones</a></li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <a onclick="actualizar('.$act->getId().')">Editar Informacion</a>
                            </li>
                            <li role="separator" class="divider"></li>        
                            <li>
                                <a onclick="observacion('.$act->getId().')">Agregar Observaciones</a>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li><a onclick="finalizar('.$act->getId().')"><b>Finalizar</b></a></li>  
                        </ul>
                    </div>                                    
                </td></tr>';

            if($act->getEstado() != "Finalizada")
            {
                if($atraso > 0){
                    $pendientes .= str_replace("<tr>", "<tr class='text-danger'>", $fila);
                }else{
                    $pendientes .= $fila;
                }
            }else{
                $finalizadas .= $fila;
            }



        }//actividades

        return array("pendientes"=>$pendientes,"finalizadas"=>$finalizadas);

    }


    public function getAtraso($fecha_fin,$fecha_cierre)
    {
        $diferencia_dias = 0;
        if($fecha_fin){
            $fecha_fin = date_format($fecha_fin, "Y/m/d");

            if($fecha_cierre){
                $segundos= strtotime(date_format($fecha_cierre, "Y/m/d")) - strtotime($fecha_fin);
                $diferencia_dias=intval($segundos/60/60/24);
            }else{
                $segundos= strtotime('now') - strtotime($fecha_fin);
                $diferencia_dias=intval($segundos/60/60/24);
            }
        }

        return  $diferencia_dias;

    }


   


}