<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;
use Calidad\GestionBundle\Entity\Usuario;


set_time_limit ( 0 );

class IncidenciasController extends Controller
{
	public function IncidenciaAction(Request $request)
    {
    	$session = $request->getSession();     		
 		$nombre = $session->get("nombre");
 		$cargo = $session->get("cargo");
 		$rango = $session->get("UserType");
        $user = $session->get("user");
       	$foto = $session->get("foto");

        if(empty($user))
        {
			    $user = explode(".",gethostbyaddr($_SERVER["REMOTE_ADDR"]));
          		return $this->render('GestionBundle:Default:login.html.twig',array("username"=>strtoupper($user[0]),));
        }


        return $this->render('GestionBundle:default:incidencias.html.twig',
        array(
            "UserType"=>$rango,
            "username"=>strtoupper($user[0]),
            "nombre"=>$nombre,
            "cargo"=>$cargo,
            "foto"=>$foto 
            )
        );


    }
}