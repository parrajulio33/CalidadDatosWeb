<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;

use Calidad\GestionBundle\Entity\Observaciones;
use Calidad\GestionBundle\Entity\Solicitudes;
use Calidad\GestionBundle\Entity\Actividades;
use Calidad\GestionBundle\Entity\Usuario;
use Calidad\GestionBundle\Entity\CamposRemediados;


//include_once('clases\class.phpmailer.php');
//include_once('clases\class.smtp.php');
set_time_limit ( 0 );
date_default_timezone_set('America/Caracas');

class ActividadesController extends Controller
{

	public function GestionesAction(Request $request)
    {
 		$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");       




        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }

       	$actividades = $this->getActividadesArray($user,$rango);






        $repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario')
            ->createQueryBuilder('Us')
            ->where('Us.area = :area')
            ->setParameter('area', 'Calidad')
            ->orderBy('Us.nombre', 'ASC')
            ->getQuery();
 
        $usuario = $repository->getArrayResult();

        





        return $this->render('GestionBundle:Default:gestion1.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                "Actividad" =>  $actividades,
                "usuarios"  =>  $usuario,
                )
            );
    }





//=================================================================================================================




    public function RegistrarGestionAction(Request $request)
    {
        $session = $request->getSession();

        $rango = $session->get("UserType");
        $user = $session->get("user");
        $gestion = $request->get("gestion");

        $response = array("code"=>404);
        $Actividad = new Actividades();



        $usuario_reg = $request->get("usuario");
        $repository= $this->getDoctrine()->getRepository('GestionBundle:Usuario');
        $usuario = $repository->findOneByUser($usuario_reg);



        if($usuario){
            $estatus = $request->get("estatus");
            $tipo = $request->get("tipog");
            $descripcion = ($tipo != "Periodica") ? $request->get("desc1") : $request->get("desc2");            
            
            $fech = ($request->get("fechaini") != "") ? explode("/", $request->get("fechaini")) : "";
            $fecha_ini = ($fech != "") ? $fech[2]."/".$fech[1]."/".$fech[0] :"";

            $fech = ($request->get("fechafin") != "") ? explode("/", $request->get("fechafin")) : "";
            $fecha_fin = ($fech != "") ? $fech[2]."/".$fech[1]."/".$fech[0] :"";
            
            $area = $request->get("area");
            $oficina = $request->get("oficina");
            $cantidad = $request->get("cantidad");
            $operacion = $request->get("operacion");
            $prioridad = $request->get("prioridad");


            
            $Actividad->setUsuario($usuario);

            $Actividad->setDescripcion($descripcion);

            $Actividad->setTipo($tipo);

            $Actividad->setOperacion($operacion);

            $Actividad->setFechaInicio(new \DateTime($fecha_ini));

            if($fecha_fin != ""){
                $Actividad->setFechaFin(new \DateTime($fecha_fin));
            }

            if($estatus == "Finalizada")
            {
                $Actividad->setFechaCierre(new \DateTime());
            }

            $Actividad->setEstado($estatus);
            $Actividad->setPrioridad($prioridad);
            $Actividad->setOficina($oficina);
            $Actividad->setArea($area);



            
            $em = $this->getDoctrine()->getManager();
            $em->persist($Actividad);
            $em->flush();
        
            if($Actividad->getId() != null ){
                $response = array("code"=>401,"id"=>$Actividad->getId(),"gestion"=>$Actividad->getDescripcion());
            }
        }
        
        return new Response(json_encode($response));
        
    }



    public function RegistrarCamposAction(Request $request){

        $response = array('code' => 404);
        $gestion = $request->get("id");
        $campos = $request->get("campos");

        $em = $this->getDoctrine()->getManager();

        foreach ($campos as $key => $value) {
            
            $Campos = new CamposRemediados();

            $explode_campos = explode("|", $value);

            $Campos->setIdRemediacion($gestion);
            $Campos->setTabla($explode_campos[0]);
            $Campos->setCampo($explode_campos[1]);
            $Campos->setCantidad($explode_campos[2]);

            
            $em->persist($Campos);
            $em->flush();
            $em->clear();
            $response = array('code' => 401);
        }


        if($response['code'] == 401){
            $acti = $this->getDoctrine()->getRepository("GestionBundle:Actividades");
            $activi = $acti->findOneById($gestion);

            


            $response = array("code"=>401,"id"=>$activi->getId(),"gestion"=>$activi->getDescripcion());
        }



        return new Response(json_encode($response));

    }


    public function RegistrarObservacionAction(Request $request){
        
        $gestion = $request->get("id");
        $Observacion = $request->get("Observacion");

        $response = array('code' =>404);

        $Observaciones = new Observaciones();

        
        $Observaciones->setActividad($gestion);
        $Observaciones->setTipo("ACT-CD");
        $Observaciones->setObservacion(nl2br($Observacion));
        $Observaciones->setFecha(new \DateTime());

        $em = $this->getDoctrine()->getManager();
        $em->persist($Observaciones);
        $em->flush();


        if($Observaciones->getId()){
            $response = array("code"=>401);
        }

        return new Response(json_encode($response));

    }


    public function DatosGestionAction(Request $request){
        $id_gestion = $request->get("id");

        $response = array("code"=>404);

        $filas_campos = ""; $filas_observacion="";

        $em = $this->getDoctrine()->getManager();


        $query = $em->createQuery('SELECT ac FROM GestionBundle:Actividades ac WHERE ac.id = :id ')->setParameter('id', $id_gestion);
        $Actividad = $query->getResult();
         
        //print_r($Actividad[0]);

        $query = $em->createQuery('SELECT cam FROM GestionBundle:CamposRemediados cam WHERE cam.idRemediacion = :id ')->setParameter('id', $id_gestion);
        $campos = $query->getArrayResult();

        //print_r($campos[0]);

        $query = $em->createQuery('SELECT obs FROM GestionBundle:Observaciones obs WHERE obs.actividad = :id AND obs.tipo = :tipo')->setParameter('id', $id_gestion)->setParameter('tipo','ACT-CD');
        $Observacion = $query->getArrayResult();


        //print_r($Observacion[0]);




        if($Actividad){

            $atraso = $this->getAtraso($Actividad[0]->getFechaFin(), $Actividad[0]->getFechaCierre());

            $ACT = Array( 
                'id'  => $Actividad[0]->getId(),        
                'descripcion'  => $Actividad[0]->getDescripcion(),        
                'tipo'         => $Actividad[0]->getTipo(),
                'user'         => $Actividad[0]->getUsuario()->getUser(), 
                'usuario'      => $Actividad[0]->getUsuario()->getNombre(),  
                'operacion'    => $Actividad[0]->getOperacion(),        
                'fechaInicio'  => ($Actividad[0]->getFechaInicio()) ? $Actividad[0]->getFechaInicio()->format("d/m/Y"): "",        
                'fechaFin'     => ($Actividad[0]->getFechaFin()) ? $Actividad[0]->getFechaFin()->format("d/m/Y"): "",        
                'estado'       => ($atraso <= 0) ? $Actividad[0]->getEstado() : "Atrasada",    
                'prioridad'    => $Actividad[0]->getPrioridad(),        
                'fechaCierre'  => ($Actividad[0]->getFechaCierre()) ? $Actividad[0]->getFechaCierre()->format("d/m/Y"): "",        
                'oficina'      => $Actividad[0]->getOficina(),    
                'area'         => $Actividad[0]->getArea(),
                'atraso'       => ($atraso > 0 && $Actividad[0]->getEstado() != "Continua" ) ? $atraso."Dia(s)":"",    
                'clientes'     => $Actividad[0]->getclientes(),         );

            foreach ($campos as $camp ) 
            {
                $filas_campos .= "<tr><td>".$camp['tabla']."</td><td>".$camp['campo']."</td><td>".$camp['cantidad']."</td></tr>";
            }

            foreach ($Observacion as $obs) {
                $filas_observacion .= "<tr><td>".$obs['observacion']."</td><td>".$obs['fecha']->format("d/m/Y")."</td></tr>";
            }
            
            $response = array("code"=>401,"a"=>$ACT,"campos"=>$filas_campos,"observaciones"=>$filas_observacion);
        }
        
        
        
        

        return new Response(json_encode($response));


    }




    public function ActualizarGestionAction(Request $request)
    {
        $session = $request->getSession();

        $rango = $session->get("UserType");
        $user = $session->get("user");
        $gestion = $request->get("gestion");

        $response = array("code"=>404);
        


        $repository= $this->getDoctrine()->getRepository('GestionBundle:Actividades');
        $Actividad = $repository->findOneById($request->get("id"));


        $usuario_reg = $request->get("usuario");
        $repository= $this->getDoctrine()->getRepository('GestionBundle:Usuario');
        $usuario = $repository->findOneByUser($usuario_reg);



        if($usuario != null && $Actividad != null){
            $estatus = $request->get("estatus");
            $tipo = $request->get("tipog");
            $descripcion = ($tipo != "Periodica") ? $request->get("desc1") : $request->get("desc2");
            
            //$fecha_ini = ($request->get("fechaini") != "") ? date("Y-m-d", strtotime($request->get("fechaini"))):"";


            $fech = ($request->get("fechaini") != "") ? explode("/", $request->get("fechaini")) : "";
            $fecha_ini = ($fech != "") ? $fech[2]."/".$fech[1]."/".$fech[0] :"";

            $fech = ($request->get("fechafin") != "") ? explode("/", $request->get("fechafin")) : "";
            $fecha_fin = ($fech != "") ? $fech[2]."/".$fech[1]."/".$fech[0] :"";
            

            $area = $request->get("area");
            $oficina = $request->get("oficina");
            $cantidad = $request->get("cantidad");
            $operacion = $request->get("operacion");
            $prioridad = $request->get("prioridad");


            
            $Actividad->setUsuario($usuario);
            $Actividad->setDescripcion($descripcion);
            $Actividad->setTipo($tipo);
            $Actividad->setOperacion($operacion);
            $Actividad->setFechaInicio(new \DateTime());

            if($fecha_fin != ""){
                $Actividad->setFechaFin(new \DateTime($fecha_fin));
            }

            if($fecha_ini != ""){
                $Actividad->setFechaInicio(new \DateTime($fecha_ini));
            }

            if($estatus == "Finalizada")
            {
                $Actividad->setFechaCierre(new \DateTime());
            }


            
            $Actividad->setPrioridad($prioridad);
            $Actividad->setOficina($oficina);
            $Actividad->setArea($area);





            
            $em = $this->getDoctrine()->getManager();
            $em->persist($Actividad);
            $em->flush();
        
            if($Actividad->getId() != null ){
                $response = array("code"=>401,"id"=>$Actividad->getId(),"gestion"=>$Actividad->getDescripcion());
            }
        }
        
        return new Response(json_encode($response));
        
    }









    public function FinalizarGestionAction(Request $request)
    {
        
        
        $operacion = $request->get("operacion");
        $cantidad = $request->get("cantidad");
        $oficina = $request->get("oficina");
        $campos = $request->get("campos");


        $repository= $this->getDoctrine()->getRepository('GestionBundle:Actividades');
        $Actividad = $repository->findOneById($request->get("id"));

        if($cantidad != ''){
            $Actividad->setClientes($cantidad);
        }
        if($oficina !=  ''){
            $Actividad->setOficina($oficina);
        }
        $Actividad->setOperacion($operacion);
        $Actividad->setEstado("Finalizada");
        $Actividad->setFechaCierre(new \DateTime());


        $em = $this->getDoctrine()->getManager();
        $em->persist($Actividad);
        $em->flush();

        if($campos){

            $em = $this->getDoctrine()->getManager();

            foreach ($campos as $key => $value) {
                
                $Campos = new CamposRemediados();

                $explode_campos = explode("|", $value);
                $Campos->setIdRemediacion($request->get("id"));
                $Campos->setTabla($explode_campos[0]);
                $Campos->setCampo($explode_campos[1]);
                $Campos->setCantidad($explode_campos[2]);

                
                $em->persist($Campos);
                $em->flush();
                $em->clear();
            }
        }
        $response = array("code"=>401);



        return new Response(json_encode($response));
    }

















































    public function getAtraso($fecha_fin,$fecha_cierre)
    {
        $diferencia_dias = 0;
        if($fecha_fin){
            $fecha_fin = date_format($fecha_fin, "Y/m/d");

            if($fecha_cierre){
                $segundos= strtotime(date_format($fecha_cierre, "Y/m/d")) - strtotime($fecha_fin);
                $diferencia_dias=intval($segundos/60/60/24);
            }else{
                $segundos= strtotime('now') - strtotime($fecha_fin);
                $diferencia_dias=intval($segundos/60/60/24);
            }
        }

        return  $diferencia_dias;

    }


     public function getActividadesArray($user,$rango)
    {
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Actividades');
 
        $query = $repository->createQueryBuilder('A');
            
            
        if(strtolower($rango) != "admin"){
            $query->where('A.usuario = :us');
            $query->setParameter('us', $user);
        }

        $actividades = $query->getQuery()->getResult();

        $ACT = Array();




        foreach ($actividades as $Actividad) {
            $atraso = $this->getAtraso($Actividad->getFechaFin(), $Actividad->getFechaCierre());



            if($atraso > 0 && !in_array(strtolower($Actividad->getEstado()), array("finalizada","continua"))){
                $estado = "Atrasada";
            }else{
                $estado = $Actividad->getEstado() ;
            }



            if($Actividad->getDescripcion() == "Prueba 1111"){echo $atraso;}
            



            
            array_push($ACT, Array( 
                    'id'           => $Actividad->getId(),
                    'descripcion'  => $Actividad->getDescripcion(),        
                    'user'         => $Actividad->getUsuario()->getUser(), 
                    'usuario'      => $Actividad->getUsuario()->getNombre(),
                    'fechaInicio'  => ($Actividad->getFechaInicio()) ? $Actividad->getFechaInicio()->format("d/m/Y"): "",        
                    'fechaFin'     => ($Actividad->getFechaFin()) ? $Actividad->getFechaFin()->format("d/m/Y"): "",        
                    'estado'       => $estado,    
                    'fechaCierre'  => ($Actividad->getFechaCierre()) ? $Actividad->getFechaCierre()->format("d/m/Y"): "",        
                    'atraso'       => ($atraso > 0) ? $atraso."Dia(s)":"",    
                )
            );
        }


        return $ACT;


    }


}