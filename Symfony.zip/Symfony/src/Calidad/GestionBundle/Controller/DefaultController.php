<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Calidad\GestionBundle\Entity\Solicitudes;
use Doctrine\ORM\Query\ResultSetMapping;
use Symfony\Component\HttpFoundation\Response;

set_time_limit(0);
date_default_timezone_set('America/Caracas');


class DefaultController extends Controller
{
    public function InicioAction(Request $request)
    {
     		
        $session = $request->getSession();
     		
     		$nombre = $session->get("nombre");
     		$cargo = $session->get("cargo");
     		$rango = $session->get("UserType");
        $user = $session->get("user");
        $actia = null;//$session->get("foto");

        $foto = $session->get("foto");

        if(empty($user))
        {
			    $user = explode(".",gethostbyaddr($_SERVER["REMOTE_ADDR"]));
          return $this->render('GestionBundle:Default:login.html.twig',
          array("username"=>strtoupper($user[0]),));
        }
        	
          

        //echo date('Y-m-d', strtotime(str_replace('/', '-','01/12/2015')));


        $actia = null;//$this->getActividad($user,$rango);       

        $Datos = $session->get("Graph");

		    if(!empty($Datos))
        {
        	$Datos = $this->getGraficaSolicitudes();
        	$session->set("Graph",$Datos);
        }

    	 

        //$cumple = $this->getCumple();


        return $this->render('GestionBundle:Default:index.html.twig',
          array(
            "UserType"=>$rango,
            "username"=>strtoupper($user[0]),
            "nombre"=>$nombre,
            "cargo"=>$cargo,
            "solicitudes"=>$Datos,
            "atraso"=>$actia,
            "cumple"=>"",
            "foto"=>$foto 
            )
          );
    }


   	


   	public function getUsers()
   	{
   		$em = $this->getDoctrine()->getManager();
		$query = $em->createQuery(
					    "SELECT us.user FROM GestionBundle:Usuarios us"
						);
		 
		return $Usuarios = $query->getArrayResult();

   	}


    public function LoginAction1(Request $request)
    { 
      $repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario');
      
      $username = $request->get("usuario");
      $password = md5($request->get("contra"));


      $user = $repository->find($username);
      if($user->getKeypass() == $password)
      {

        echo $user->getNombre();
        $nombre = $user->getNombre();
        $correo = $user->getCorreo();
        //$cargo = $user->
        //$username = $user->

      }else
      {
        










      }


      $sesion->set("nombre", $nombre);
      $sesion->set("correo", $correo);
      $sesion->set("cargo", $cargo);
      $sesion->set("user",strtolower($username));
      
      if(file_exists($username.".jpg")){
        $sesion->set("foto","http://calidad4/".$username.".jpg");
      }else
      {
        $sesion->set("foto","http://calidad4/usuario.png");
      }





      return new Response(json_encode(Array("code"=>404)));
      
    }




   	public function LoginAction(Request $request)
   	{
   		
		$sesion = $request->getSession();
		$response = array("code"=>404);

   		if($request->getMethod() == "POST" && $sesion->get("user") == null)
        {
                        
            if($sesion->get("user") == null){

                $adServer = "bod.com.ve";
                $servidor_dominio = "bod.com.ve";

                $username = $request->get("usuario");
                $password = $request->get("contra");

                $ldaprdn = $username;

                $ldap = ldap_connect($adServer);
                ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
                ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

                //    $bind = @ldap_bind($ldap, $ldaprdn, $password);
                $bind= @ldap_bind($ldap,$ldaprdn. "@" .$servidor_dominio,$password);

                if ($bind) {
                    
                    $filter="(mail=$username@$servidor_dominio)";

                    //$justthese = array('ou', 'sn', 'givenname', 'mail');
                    $dn="dc=BOD,dc=COM,dc=VE";


                    $result = ldap_search($ldap,$dn,$filter);

                    $info = ldap_get_entries($ldap, $result);

                                    

                    $nombre = $info[0]['cn'][0];
                    $cedula = $info[0]['postofficebox'][0];
                    $correo = $info[0]['mail'][0];
                    $cargo =  strtolower($info[0]['title'][0]);

                    
                    $sesion->set("nombre", $nombre);
                    $sesion->set("correo", $correo);
                    $sesion->set("cargo", $cargo);
                    $sesion->set("user",strtolower($username));
                    
                    if(file_exists($username.".jpg")){
                      $sesion->set("foto","http://calidad4/".$username.".jpg");
                    }else
                    {
                      $sesion->set("foto","http://calidad4/usuario.png");
                    }




                    $cargos = [0=>"coordinador",1=>"coordinadora",2=>"supervisor",3=>"gerente"];


                    if(in_array($cargo, $cargos))
                    {
                    	$sesion->set("UserType","Admin");
                    }else
                    {
                    	$sesion->set("UserType","User");
                    }

	                
                    @ldap_close($ldap);

                    $response = array("code"=>401);
                } else {
                    $response = array("code"=>404);
                }

            }//end if user
            

            
        }//end if POST

   		
		return new Response(json_encode($response));
   	}


   	public function LogoutAction(Request $request)
   	{
   		$session = $request->getSession();
   		$session->remove("nombre");
   		$session->remove("cargo");
   		$session->remove("UserType");
   		$session->remove("user");

   		return $this->redirect($this->generateUrl('index'), 301);
   	}





   	public function getGraficaSolicitudes()
   	{
  		$Estadisticas =  Array();
  		$Meses = Array("01","02","03","04","05","06","07","08","09","10","11","12");
  		$DscMeses = Array("ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DEC");
  		$i=0;

  		$em = $this->getDoctrine()->getManager();

  		foreach ($Meses as $key => $mes) {
  			
  			$query = $em->createQuery(
  					    "SELECT Count(So.idSolicitud) AS estadisticas, So.estado FROM GestionBundle:Solicitudes So
  						 WHERE So.fechaEnvio BETWEEN '2015/".$mes."/01' AND '2015/".$mes."/31' 
  						 GROUP BY So.estado"
  						);
  			$datos = $query->getArrayResult();

  			if(!empty($datos)){
  				$Estadisticas[$i] = 
          Array(
            "Mes"=>$DscMeses[$key],
            "abiertas"=>$datos[0]["estadisticas"],
            "cerradas"=>(empty($datos[1]["estadisticas"])) ? 0:$datos[1]["estadisticas"]);
  				$i++;
  			}

  		}
  		

  		return $Estadisticas;

   	}



   	public function getActividad($user,$rango)
   	{
   		
   		$repository = $this->getDoctrine()->getRepository('GestionBundle:Gestiones');


   		$Atrasadas = Array();
   		$i = 0;

   		if($rango == "Admin")
   		{
  			$query = $repository->createQueryBuilder('g')
  			    ->where('g.estado = :est')
  			    ->setParameter('est', 'Pendiente')
  			    ->getQuery();
  			 
  			$gestiones = $query->getResult();
  			
  			foreach ($gestiones as $ges) {
  				$fecha=date_format($date = $ges->getFechafin(), "Y/m/d");
  				$segundos= strtotime('now') - strtotime($fecha);
  				$diferencia_dias=intval($segundos/60/60/24);
  								
  				if($diferencia_dias > 0)
  				{
  					$Atrasadas[$i] = Array("titulo"=>$ges->getDescripcion(), "dias"=> $diferencia_dias." dias" );
  					$i++;
  				}
			}

			return $Atrasadas;
   		}else
   		{

   			$query = $repository->createQueryBuilder('g')
			    ->where('g.estado = :est AND g.user = :user')
			    ->setParameter('est', 'Pendiente')
			    ->setParameter('user', $user)
			    ->getQuery();
			 
  			$gestiones = $query->getResult();
  			
  			foreach ($gestiones as $ges) {				
  				$fecha=date_format($date = $ges->getFechafin(), "Y/m/d");
  				$segundos= strtotime('now') - strtotime($fecha);
  				$diferencia_dias=intval($segundos/60/60/24);
  								
  				if($diferencia_dias > 0)
  				{
  					$Atrasadas[$i] = Array("titulo"=>$ges->getDescripcion(), "dias"=> $diferencia_dias." dias" );
  					$i++;
  				}
  			}

  			return $Atrasadas;
   		}

   	}

    public function getCumple()
    {
        $mes_actual = date("m");
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario')
        ->createQueryBuilder('Us')->getQuery()
        ->getResult();


       

        $cumple = array();

        foreach ($repository as $us) {
          if(date_format($us->getFechanac(),"m") == $mes_actual){
            $nombre = explode(" ", $us->getNombre());
            $foto = (file_exists($us->getuser().".jpg") ) ? $us->getUser().".jpg" : "Usuario.png";

            array_push($cumple, array(
              "nombre" => $nombre[0]." ".$nombre[1],
              "foto" =>$foto,
              ));
          }
        }
        return $cumple;



       
    }


   


}
