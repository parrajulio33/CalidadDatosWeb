<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;



use Calidad\GestionBundle\Entity\Correos;





//include_once('clases\class.phpmailer.php');
//include_once('clases\class.smtp.php');
//include_once ('clases\Classes\PHPExcel.php');
//include_once ('clases\Classes\PHPExcel\IOFactory.php');
set_time_limit ( 0 );

class MasivoController extends Controller
{
	public function MasivoAction(Request $request)
	{	
		$session = $request->getSession();

		$user  = $session->get("user");
		$nombre = $session->get("nombre");
		$cargo = $session->get("cargo");
		$tipou = $session->get("rango");
		$foto  = $session->get("foto");




		if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }



		return $this->render('GestionBundle:Default:masivo.html.twig',
			array(
				"UserType"=>"Admin",
				"username"=>$user,
				"nombre"=>$nombre,
				"cargo"=>$cargo,
				"user"=>$user,
				"foto" =>$foto
				)
			);
	}


	public function LeerArchivoAction(request $request)
	{
		
		$secion = $request->getSession();

		$user = $secion->get("user");
		
		//borrar el contenido de la tabla

		//$conn = $em->getConnection();
		//$stmt = $conn->prepare("TRUNCATE TABLE Masivo");
		//$stmt->execute();
		



		$id_envio = null;



		if($request->getMethod() == "POST"){
    		
    		$TipoGestion = $request->get("gestion");
			//$TipoSolicitud = $request->get("solicitud");
			$Prioridad  = $request->get("prioridad");
			$BCCorreos = $request->get("correos");
	        
	        $descripcion = $request->get("descripcion");



    		if($_FILES['file1']['name'] != '')
			{
				
				
				$i=0;
				$name = $_FILES['file1']['name'];
				$tname = $_FILES['file1']['tmp_name'];
				$type = $_FILES['file1']['type'];

				
				$Registro =  new Correos();

				
				$Registro->setRtyp("ARCH");
				$Registro->setGestion($TipoGestion);
				$Registro->setFecha(new \DateTime);
				$Registro->setPrioridad($Prioridad);
				$Registro->setDescripcion($descripcion);
				$Registro->setCopia($BCCorreos);
				
				$Registro->setUsuario($user);

				$em = $this->getDoctrine()->getManager();
				$em->persist($Registro);
				$em->flush();

				$id_envio = $Registro->getReg();

				$objReader = \PHPExcel_IOFactory::createReader('Excel2007');
				$objReader->setReadDataOnly(true);
				 
				$objPHPExcel = $objReader->load($tname);
				$objWorksheet = $objPHPExcel->getActiveSheet();
				 
				
				$Datos = Array();

				foreach ($objWorksheet->getRowIterator() as $row) {
				
				 	if($row->getRowIndex() > 1 )
				 	{
						$cellIterator = $row->getCellIterator();
						$cellIterator->setIterateOnlyExistingCells(false); // This loops all cells,
						

						$Cliente = new Correos();	

						foreach ($cellIterator as $Cell) {
							$column = $Cell->getColumn();

							switch ($column) {
								case 'A':
									$Cliente->setCliente($Cell->getValue()); // CLIENTE
									break;
								case 'B':
									$Cliente->setNombre($Cell->getValue()); //NOMBRE 
									break;
								case 'C':
									$Cliente->setIdentificacion($Cell->getValue()); //IDENTIFICACIÓN
									break;
								case 'D':
									$Cliente->setOficina($Cell->getValue()); //OFICINA
									break;
								case 'E':
									$Cliente->setEjecutivo($Cell->getValue()); //EJECUTIVO
									break;
								case 'F':
									$Cliente->setCampo($Cell->getValue()); //CAMPO
									break;
							}
						}

						$Cliente->setRtyp("CLIE");
						$Cliente->setIdEnv($id_envio);

						$em = $this->getDoctrine()->getEntityManager();
						$em->persist($Cliente);
						$em->flush();
						$em->clear();
					}
				}

				
			}
		}

		$response  = "Archivo leido con exito!";



		//return $this->render('GestionBundle:Default:masivo.html.twig',array("UserType"=>"Admin","username"=>"","nombre"=>"Gustavo Silva","cargo"=>"Analista"));
		return new Response(json_encode($response));
	}



	public function CorreoAction(request $request)
	{

		$session = $request->getSession();

		$user  = $session->get("user");
		$nombre = $session->get("nombre");
		$cargo = $session->get("cargo");
		$tipou = $session->get("rango");
		$foto  = $session->get("foto");




		if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }



		return $this->render('GestionBundle:Default:correos.html.twig',
			array(
				"UserType"=>"Admin",
				"username"=>$user,
				"nombre"=>$nombre,
				"cargo"=>$cargo,
				"user"=>$user,
				"foto" =>$foto
				)
			);

	}

	




}