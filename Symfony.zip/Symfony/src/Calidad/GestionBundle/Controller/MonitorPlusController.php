<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Calidad\GestionBundle\Entity\Monitorplus;
use Calidad\GestionBundle\Entity\ArchivoSubido;
use Calidad\GestionBundle\Entity\Alertas;
use Calidad\GestionBundle\Entity\CorreosOficinas;


//include_once ('clases\Classes\PHPExcel.php');
//include_once ('clases\Classes\PHPExcel\IOFactory.php');
set_time_limit ( 0 );



class MonitorPlusController extends Controller
{
	public function MonitorPlusAction(Request $request)
    {	
    	$session = $request->getSession();
     		
     	$nombre = $session->get("nombre");
     	$cargo = $session->get("cargo");
     	$rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");

        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }





    	return $this->render('GestionBundle:Default:monitorplus.html.twig',
          array(
            "UserType"=>$rango,
            "username"=>strtoupper($user[0]),
            "nombre"=>$nombre,
            "cargo"=>$cargo,
            "foto"=>$foto ));

    }

    public function MonitorPlusSubirAction(Request $request)
    {
      $secion = $request->getSession();
      $user = $secion->get("user");

      $response = ""; $alertas_array = $this->getAlert();
      try {

        if(isset($_FILES['file1'])){
        $Nombre_Archivo = $_FILES['file1']['name'];
        $Ruta_Archivo   = $_FILES['file1']['tmp_name'];
        $Tipo_Archivo   = $_FILES['file1']['type'];

        
        $XLFileType = \PHPExcel_IOFactory::identify($Ruta_Archivo);
        $objReader = \PHPExcel_IOFactory::createReader($XLFileType);  
        $objPHPExcel = $objReader->load($Ruta_Archivo);


        $MaxRow = $objPHPExcel->getActiveSheet()->getHighestRow();
        $MaxColumn = $objPHPExcel->getActiveSheet()->getHighestColumn(); 
        
        $sheet = $objPHPExcel->getActiveSheet();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $em = $this->getDoctrine()->getManager();

        $RegArchivo = new ArchivoSubido();
        $RegArchivo ->setArchivo($Nombre_Archivo);
        $RegArchivo ->setFechaSubida(new \DateTime(date("Y-m-d")));
        $RegArchivo ->setStatus("Sin Enviar");
        $RegArchivo ->setTipo("MONITOR PLUS");
        $RegArchivo ->setUsuario($secion->get("usuario"));
        
        $em->persist($RegArchivo);
        $em->flush();

        $id_archivo = $RegArchivo->getId();

        $em->clear();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        
          
          for ($i=12; $i <= $MaxRow ; $i++) {
            $alert = $sheet->getCell('AZ'.$i)->getValue();
            $delimiter = (strpos($alert, ",")) ? ",": "»";

            $alertas = explode($delimiter, $alert);

            

            foreach ($alertas as $key => $value) {

              if(in_array(intval($value), $alertas_array)){
                //echo "$value\n";
                $Monitor = new Monitorplus();
                
                $fecrec = $sheet->getCell('F'.$i)->getValue();//FECHA DE RECEPCION

                $Monitor->setBanco($sheet->getCell('I'.$i)->getValue());
                $Monitor->setAgencia($sheet->getCell('J'.$i)->getValue());
                $Monitor->setCliente($sheet->getCell('M'.$i)->getValue());
                $Monitor->setNomcliente($sheet->getCell('N'.$i)->getValue());
                $Monitor->setUsuario($sheet->getCell('AL'.$i)->getValue());
                $Monitor->setEjecutivo($sheet->getCell('AT'.$i)->getValue());
                $Monitor->setBanca($sheet->getCell('Ax'.$i)->getValue());
                $Monitor->setIdentificacion($sheet->getCell('AR'.$i)->getValue());
                
                $Monitor->setCondicion($value);
                
                $Monitor->setArchivo($id_archivo);
                $Monitor->setFecharecep(new \DateTime(substr($fecrec, 0, -4)."/".substr($fecrec, 4, -2)."/".substr($fecrec, 6)));
                $Monitor->setEncargado($user);

                $em->persist($Monitor);
                $em->flush();
                $em->clear();
              }
            }

            

          }
          echo $this->getEstadisticas($id_archivo);
        
      }//existe variable
      else{
        echo "<label class='label label-danger'>ERROR: ARCHIVO NO EXISTE!</label>";
      }
      
    }catch (Exception $e)
    {
      echo "<label class='label label-danger'>ERROR: ".$e->getMessage()."</label>";

    }




      /*
      $Monitor->setBanco($Array[$i]["A2"]);
      $Monitor->setAgencia($Array[$i]["A3"]);
      $Monitor->setCliente($Array[$i]["A4"]);
      $Monitor->setNomcliente($Array[$i]["A5"]);
      $Monitor->setUsuario($Array[$i]["A6"]);
      $Monitor->setCuenta($Array[$i]["A7"]);
      $Monitor->setEjecutivo($Array[$i]["A9"]);
      $Monitor->setBanca($Array[$i]["A11"]);
      $Monitor->setCondicion($Alerta);
      $Monitor->setArchivo($RegArchivo->getId());
      $Monitor->setFecharecep(new \DateTime($Array[$i]["A1"]));
      $Monitor->setFechaaper(new \DateTime($Array[$i]["A8"]));
      $Monitor->setEncargado($user);
      */
      //$MaxRow = $objPHPExcel->getActiveSheet()->getHighestRow();
      //$MaxColumn = $objPHPExcel->getActiveSheet()->getHighestColumn(); 

//»

      return new Response(json_encode($response));
    }




    public function getAlert()
    {
      $em = $this->getDoctrine()->getManager();
      $query = $em->createQuery(
          'SELECT A.codigo FROM GestionBundle:Alertas A'
      );
       
      $alert = $query->getArrayResult();
      $alert_array = array();

      foreach ($alert as $key => $value) {
        array_push($alert_array, $value['codigo']);
      }

      

      return $alert_array;

    }

    public function getEntidadAlerta($codigo)
    {
      $repository = $this->getDoctrine()->getRepository('GestionBundle:Alertas');
      return $repository->findOneByCodigo($codigo);

    }

    public function getEntidadOficina()
    {
      $repository = $this->getDoctrine()->getRepository('GestionBundle:Oficinas');
      $ofi = $repository->findAll();

      $array = array();
      
      foreach ($ofi as $offi) {
        $array[$offi->getOficina()] = $offi->getOficina()." - ".$offi->getNombreOficina();
      }
      return $array;

    }



    public function getEstadisticas($id)
    {
      $em = $this->getDoctrine()->getManager();
      $query = $em->createQuery(
          'SELECT MP.agencia, count(MP) cantidad FROM GestionBundle:Monitorplus MP WHERE MP.archivo = :arc GROUP BY MP.agencia'
      )->setParameter("arc",$id);
      
       
      $alert = $query->getArrayResult();
      $oficina = $this->getEntidadOficina();

      $tabla = "<table class='table table-striped table-hove' style='width: 50%'>
        <thead><tr><th>OFICINA</th><th>CANTIDAD DE CLIENTES</th></tr></thead>
        <tbody>";
        
      foreach ($alert as $est ) {
        $tabla = $tabla."<tr><td>".$oficina[$est['agencia']]."</td><td>".$est['cantidad']."</td><tr>";
      }  


      $tabla = $tabla."</tbody></table>";

      return $tabla; 
      
    }


}
