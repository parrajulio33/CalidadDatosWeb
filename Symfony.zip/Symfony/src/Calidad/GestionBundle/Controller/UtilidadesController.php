<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Calidad\GestionBundle\Entity\Direccion;
use Doctrine\ORM\Query\ResultSetMapping;
use Symfony\Component\HttpFoundation\Response;


//include_once ('clases\Classes\PHPExcel.php');
//include_once ('clases\Classes\PHPExcel\IOFactory.php');


set_time_limit(0);
date_default_timezone_set('America/Caracas');

class UtilidadesController extends Controller
{
    
	public function MonitorAction(Request $request, $id)
	{
		$session = $request->getSession();

		$nombre = $session->get("nombre");
        $cargo  = $session->get("cargo");
        $rango  = $session->get("UserType");
        $user   = $session->get("user");
        $foto   = $session->get("foto");

    	return $this->render('GestionBundle:Default:correos_c_m.html.twig',
    		array(
    			"UserType"=>$rango,
    			"username"=>strtoupper($user),
    			"nombre"=>$nombre,
    			"cargo"=>$cargo,
    			"tabs" => $id,
    			"foto"=>$foto
    		)
    	);
	}


    public function CalculoRifAction(Request $request)
    {

		$secion = $request->getSession();

		$user = $secion->get("user");
		$nombre = $secion->get("nombre");
		$cargo = strtoupper($secion->get("cargo"));

    	return $this->render('GestionBundle:Default:calculorif.html.twig',
    		array(
    			"UserType"=>null,
    			"username"=>strtoupper($user[0]),
    			"nombre"=>$nombre,
    			"cargo"=>$cargo,
    		)
    	);
    }


    public function CalcularRifArchivoAction(Request $request)
    {
    	
    	if($_FILES['file1']['name'] != '')
			{
				
				
				$i=0;
				$name = $_FILES['file1']['name'];
				$tname = $_FILES['file1']['tmp_name'];
				$type = $_FILES['file1']['type'];

				$myfile = fopen("acumst.txt", "w") or die("Unable to open file!");
			    
				


				$objReader = \PHPExcel_IOFactory::createReader('Excel2007');
				$objReader->setReadDataOnly(true);
				 
				$objPHPExcel = $objReader->load($tname);
				$objWorksheet = $objPHPExcel->getActiveSheet();
				 
				
				$Datos = Array();

				foreach ($objWorksheet->getRowIterator() as $row) {
				
				 	if($row->getRowIndex() > 4 )
				 	{
						$cellIterator = $row->getCellIterator();
						$cellIterator->setIterateOnlyExistingCells(false);
					
						

						foreach ($cellIterator as $Cell) {
							$column = $Cell->getColumn();

							switch ($column) {
								case 'A':
									$cliente = $Cell->getValue();
									break;
								case 'B':
									$nacionalidad = $Cell->getValue();
									break;
								case 'C':
									$tipo_id = $Cell->getValue();
									break;
								case 'D':
									$cedula = $Cell->getValue();
									break;
								case 'E':
									$nombre = $Cell->getValue();
									break;
								case 'F':
									$rif = $Cell->getValue();
									break;
								case 'G':
									$credito = $Cell->getValue();
									break;
								case 'H':
									$dolares = $Cell->getValue();
									break;
							}

							

						}//for
						
						if(!empty($nacionalidad) && $nacionalidad != "R"){
							echo $rif = $this->getRif($nacionalidad,$cedula);
						}
						
						$line = str_pad($cliente, 10, " ", STR_PAD_LEFT).
								str_pad("CUMST" , 10, " ").
								str_pad("CUSID3", 10, " ").
								str_pad("", 4, " ").
								str_pad($rif, 80, " ");

						fwrite($myfile, $line);
					}
				}
				
				
				fclose($myfile);
                
         

			}











    	$response = array("code"=>404);
    	return new Response(json_encode($response));
    }




    public function getRif($nac,$ced)
    {
    	

    	$nac = strtoupper($nac);
    	$ced = str_pad($ced, 8,"0",STR_PAD_LEFT); 



    	switch ($nac) {
            case 'V':
                $nac2 = 1;
                break;
            case 'E':
                $nac2 = 2;
                break;
            case 'J':
                $nac2 = 3;
                break;
            case 'P':
                $nac2 = 4;
                break;
            case 'G':
                $nac2 = 5;
                break;
        }

		$RIF =  $nac2."".$ced;
		$Digitos_rif  = str_split($RIF);

		$Digitos_rif[0] *= 4;
		$Digitos_rif[1] *= 3;
		$Digitos_rif[2] *= 2;
		$Digitos_rif[3] *= 7;
		$Digitos_rif[4] *= 6;
		$Digitos_rif[5] *= 5;
		$Digitos_rif[6] *= 4;
		$Digitos_rif[7] *= 3;
		$Digitos_rif[8] *= 2;
		
		
		$cod_rif =  11 - (array_sum($Digitos_rif) % 11);

		return $nac." ".$ced.$cod_rif;
    }

    


    public function BuscarEmpresaAction()
    {
    	
		


    	return new Response(json_encode($response));

    }




    public function EntidadAction(Request $request)
    {
    	$session = $request->getSession();

		$nombre = $session->get("nombre");
        $cargo  = $session->get("cargo");
        $rango  = $session->get("UserType");
        $user   = $session->get("user");
        $foto   = $session->get("foto");

    	return $this->render('GestionBundle:Default:entidad_territorial.html.twig',
    		array(
    			"UserType"=>$rango,
    			"username"=>strtoupper($user),
    			"nombre"=>$nombre,
    			"cargo"=>$cargo,
    			"foto"=>$foto
    		)
    	);
    }

    public function EntidadConsultaAction(Request $request)
    {

    	$Sector = $request->get("Sector");
    	$Ciudad = $request->get("Ciudad");
    	$Estado = $request->get("Estado");

    	$query = "";
    	
    	if($Sector != "")
    	{
    		$query = "ET.sector LIKE '%".$Sector."%'";
    	}

    	if($Ciudad != "" ){    		
    		if($query != "")
    		{
    			$query = $query." AND ET.ciudad = '".$Ciudad."'";
    		}else
    		{
    			$query = "ET.ciudad = '".$Ciudad."'";
    		}
    	}

    	if($Estado != 0 ){
    		if( $query != ""){
    			$query = $query." AND ET.codEstado = '".$Estado."'";
    		}else{
    			$query = "ET.codEstado = '".$Estado."'";
    		}	
    	}
    	

    	$repository = $this->getDoctrine()->getRepository('GestionBundle:Direccion');
		 
		$consulta = $repository->createQueryBuilder('ET')->where($query);
		$data = $consulta->getQuery()->getResult();
		 
		

    	$filas = "";

		if(!empty($data))
		{

			foreach ($data as $dir) {
				
				$filas .= "
					<tr onClick='buscar_direccion(".$dir->getId().")'>
						<td>".$dir->getSector()."</td>
						<td>".$dir->getCiudad()."</td>
						<td>".$dir->getEstado()."</td>
					</tr>
				";



			}

		}


    	$response = Array("code"=>401,"data"=>$filas);
    	return new Response(json_encode($response));
    }


    public function BEntidadConsultaAction(Request $request)
    {
    	

    	$repository = $this->getDoctrine()->getRepository("GestionBundle:Direccion");
		 
		$query = $repository->createQueryBuilder('DIR')
		    ->where('DIR.id ='.$request->get("id"))
		    ->getQuery();
		 
		$entidad = $query->getArrayResult();
    	
    	

    	if(!empty($entidad))
    	{
    		$response = Array(
    			"code"=>401,
    			"sector"		=>$entidad[0]["sector"],	
    			"cod_estado"	=>$entidad[0]["codEstado"],	 			
    			"estado"		=>$entidad[0]["estado"],		
    			"cod_ciudad"	=>$entidad[0]["codCiudad"],	 			
    			"ciudad"		=>$entidad[0]["ciudad"],		
    			"cod_municipio"	=>$entidad[0]["codMunicipio"],	    			
    			"municipio"		=>$entidad[0]["municipio"],	 			
    			"cod_parroquia"	=>$entidad[0]["codParroquia"],	
    			"parroquia"		=>$entidad[0]["parroquia"],	 			
    			"zpostal"		=>$entidad[0]["zonaPostal"],
    			"cod_area"		=>$entidad[0]["codArea"],			
    			);

    	}else
    	{
    		$response = Array("code"=>404);
    	}

    	return new Response(json_encode($response));
    }


    



    public function BuscarPersonaAction(Request $request)
    {
        
        $nac = strtoupper($request->get('nac'));
        $ced = $request->get('ced');

        $url = "http://www.cne.gov.ve/web/registro_electoral/ce.php?nacionalidad=$nac&cedula=$ced";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $result = curl_exec ($ch);

        
        //$result = str_replace(array("\n","&nbsp;"), "", $result);


        $result = $this->LimpiarHTLM($result);
        $result = strip_tags($result);

        $result = str_replace(":\n", ": ", $result);
        //$result = explode("\n",$result);

        print_r($result);








        $response = Array("code"=>401,"cne"=>$result);

        return new Response(json_encode($response));

    }



    private function LimpiarHTLM($result){
        $cadena = str_replace(array("&nbsp;","&nbsp;"), "",strip_tags($result));// strip_tags($result);
        $cadena = str_replace(array('á', 'à', 'ä', 'â', 'ª', 'Á', 'À', 'Â', 'Ä',"&aacute;","&Aacute;"),array('a', 'a', 'a', 'a', 'a', 'A', 'A', 'A', 'A', 'a', 'A'),$cadena);
        $cadena = str_replace(array('é', 'è', 'ë', 'ê', 'É', 'È', 'Ê', 'Ë',"&eacute;","&Eacute;"),array('e', 'e', 'e', 'e', 'E', 'E', 'E', 'E', 'e', 'E'),$cadena);
        $cadena = str_replace(array('í', 'ì', 'ï', 'î', 'Í', 'Ì', 'Ï', 'Î',"&iacute;","&Iacute;"),array('i', 'i', 'i', 'i', 'I', 'I', 'I', 'I', 'i', 'I'),$cadena);
        $cadena = str_replace(array('ó', 'ò', 'ö', 'ô', 'Ó', 'Ò', 'Ö', 'Ô',"&oacute;","&Oacute;"),array('o', 'o', 'o', 'o', 'O', 'O', 'O', 'O', 'o', 'O'),$cadena);
        $cadena = str_replace(array('ú', 'ù', 'ü', 'û', 'Ú', 'Ù', 'Û', 'Ü',"&uacute;","&Uacute;"),array('u', 'u', 'u', 'u', 'U', 'U', 'U', 'U', 'u', 'U'),$cadena);
        $cadena = str_replace(array('ñ', 'Ñ', 'ç', 'Ç',"&ntilde;","&Ntilde;"),array('n', 'N', 'c', 'C','n', 'N',),$cadena);
        
        $cadena = str_replace(":\n",":" ,$cadena);
        $cadena = str_replace("\n\n\n\n\n","" ,$cadena);
        return $cadena;
    }




}






