<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;


use Calidad\GestionBundle\Entity\Usuario;
use Calidad\GestionBundle\Entity\MasivoConfig;
use Calidad\GestionBundle\Entity\Solicitudes;
use Calidad\GestionBundle\Entity\ClientesTbl;



//include_once('clases\class.phpmailer.php');
//include_once('clases\class.smtp.php');
set_time_limit ( 0 );
date_default_timezone_set('America/Caracas');

$ListUser = Array();


$link = mysql_connect('localhost:3307', 'root', '') or die('No se pudo conectar: ' . mysql_error());
mysql_select_db('calidad') or die('No se pudo seleccionar la base de datos');


class SolicitudesCDController extends Controller
{
	

	public function SolicitudesAction(Request $request)
    {
    	$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");

        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }


        $repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario')
            ->createQueryBuilder('Us')
            ->where('Us.area = :area')
            ->setParameter('area', 'Calidad')
            ->orderBy('Us.nombre', 'ASC')
            ->getQuery();
 
        $usuario = $repository->getArrayResult();

        foreach ($usuario as $us) {
        	$this->ListUser[$us['user']] = $us['nombre'];
        }

        

        

        

        return $this->render('GestionBundle:Default:solicitudes_calidad.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                "usuarios"  =>  $usuario,
                "envios" 	=>  $this->getEnvios(),
                )
            );
    }






    function getEnvios()
	{
		$repository = $this->getDoctrine()->getRepository("GestionBundle:MasivoConfig");
		$datos = $repository->findAll();

		

		$envios = "";


		foreach ($datos as $key) {
			$envios .= "<tr>";
			$envios .= "<td align='center'>".$key->getId()."</td>";
			$envios .= "<td style='width:45%;'>".$key->getTipo()."</td>";
			$envios .= "<td align='center'>".$this->ListUser[$key->getUsuario()]."</td>";
			$envios .= "<td align='center'>".(($key->getFechaSubida()) ? date_format($key->getFechaSubida(),"d/m/Y") : "" )."</td>";
			$envios .= "<td align='center'>".$key->getCantidad()."</td>";
			$envios .= "<td align='center'>".$key->getEstatus()."</td>";
			if(strtolower($key->getEstatus()) == "pendiente"){
                $envios .= "<td align='center'><a title='Cancelar Envio' class='btn btn-danger btn-xs'><i class='glyphicon glyphicon-remove'></i></a></td>";
            }else{
                $envios .= "<td align='center'><a class='text-center' style='cursor: pointer;' onClick='detallar(".$key->getId().")' title='Se generaron ".$key->getCantidad()." solicitudes para este envio' >DETALLE</a></td>";
            }
			$envios .= "</tr>";
		}


		return $envios;

	}





    function getSolicitudes($query)
    {
        $result = mysql_query($query); 

        $envios = "";

        //echo mysql_error();

        while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) 
        {
            $envios .= "<tr>";
            $envios .= "<td align='center'>".$line['CLIENTE']."</td>";
            $envios .= "<td>".$line['NOMBRE_CLIENTE']."</td>";
            $envios .= "<td align='center'>".$line['FECHA']."</td>";
            $envios .= "<td align='center'>".$line['ESTADO']."</td>";
            $envios .= "<td align='center'>".$line['CAMPO']."</td>";
            $envios .= "<td align='center'>".$line['TIPO_GESTION']."</td>";
            
            $id = $line['ID_SOLICITUD'];
            if(strtoupper($line['ESTADO']) == "ABIERTA"){
                $envios .= "<td align='center'><a class='label label-default' style='border-radius: 0px;' onClick='cerrar(".$id.")' id='btn$id' ><b>CERRAR</b></a></td>";
            }else{
                $envios .= "<td align='center'><a class='label label-success' style='border-radius: 0px;'><i class='glyphicon glyphicon-ok'></i></a></td>";
            }

            $envios .= "</tr>";
        }

        return $envios;

    }



    function BuscarClientesAction(Request $request)
    {
        $clientes = trim($request->get('clientes'));
        
        $clientes = str_replace(","," ", trim($clientes));
        $clientes = str_replace("  "," ", trim($clientes));
        $clientes = str_replace(" ",", ", trim($clientes));

        //echo "SELECT * FROM clientes_tbl  AS A WHERE A.CLIENT IN (".$clientes.")";
        $result = mysql_query(str_replace(",)",")", "SELECT * FROM clientes_tbl  AS A WHERE A.CLIENT IN (".$clientes.")")); 

        $client = "";

        while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) 
        {
            $client .= "<tr>";
                $client .= "<td align='center'>".$line['CLIENT']."</td>";
                $client .= "<td>".utf8_decode($line['NOMBRE'])."</td>";
                $client .= "<td align='center'>".$line['IDENTF']."</td>";
                $client .= "<td align='center'>".$line['OFICINA']."</td>";
            $client .= "</tr>";
        }

        if($client != "")
        {
            $response = array("code"=>401, "clientes"=>$client);
        }else
        {
            $response = array("code"=>404, "clientes"=>$client);
        }


        return new Response(json_encode($response));
    }



    function BuscarSolicitudesAction(Request $request)
    {
        $clientes = trim($request->get('Cliente'));
        
        $clientes = str_replace(","," ", trim($clientes));
        $clientes = str_replace("  "," ", trim($clientes));
        $clientes = str_replace(" ",", ", trim($clientes));
        

        $Gestion  = trim($request->get('Gestion'));
        $Clasifi  = trim($request->get('Clasificacion'));
        $Estatus  = trim($request->get('Estatus'));
        $Fecha1   = $request->get('Fecha1');
        $Fecha2   = $request->get('Fecha2');

        $query = "SELECT A.ID_SOLICITUD, A.CLIENTE, A.NOMBRE_CLIENTE, DATE_FORMAT(A.FECHA_ENVIO,'%d-%m-%Y') AS FECHA, A.CAMPOS AS CAMPO, A.TIPO_GESTION, A.ESTADO FROM solicitudes AS A WHERE ";

        $query .= "A.TIPO_GESTION = '".$Gestion."' AND ";
        $query .= ((strtolower($Clasifi) != '' ) ? "A.CLASIFICACION = '".$Clasifi."' AND " : "");
        $query .= ((strtolower($Estatus) != 'todo' ) ? "A.ESTADO = '".$Estatus."' AND " : "");
        
        if($Fecha1 != '' && $Fecha2 != '' )
        {
            $query .= "DATE_FORMAT(A.FECHA_ENVIO, '%d/%m/%Y') BETWEEN '".$Fecha1."' AND '".$Fecha2."' AND ";
        }else
        {
            if($Fecha1 != '' && $Fecha2 == '' )
            {
                $query .= "DATE_FORMAT(A.FECHA_ENVIO, '%d/%m/%Y') = '".$Fecha1."' AND ";

            }

            if($Fecha1 == '' && $Fecha2 != '' )
            {
                $query .= "DATE_FORMAT(A.FECHA_ENVIO, '%d/%m/%Y') = '".$Fecha2."' AND ";
            }
        }


        if($clientes != ''){
             $query .= "A.CLIENTE IN (".$clientes.") ";
        }

        $query = str_replace("AND ;", "LIMIT 1000;", $query.";");        
        //echo "\n\n\n\n\n";
        $datos = $this->getSolicitudes($query);

        $response = array("code" => 401,"query"=>$query,"datos" => $datos);


        return new Response(json_encode($response));
    }







    function DetalleEnviosAction(Request $request){

        $id = $request->get("ind");
        $query = "SELECT A.ID_SOLICITUD, A.CLIENTE, A.NOMBRE_CLIENTE, DATE_FORMAT(A.FECHA_ENVIO,'%d-%m-%Y') AS FECHA, A.CAMPOS AS CAMPO, A.TIPO_GESTION, A.ESTADO FROM solicitudes AS A WHERE CONFIG_MA = ".$id;
        $datos = $this->getSolicitudes($query);
        $response = array("code" => 401,"query"=>$query,"datos" => $datos);

        return new Response(json_encode($response));
    }




    function CerrarSolicitudAction(Request $request)
    {

        $id = $request->get("id");
        $Act = $request->get("act");
        $coment = $request->get("coment");



        $query = "UPDATE solicitudes SET CERRADO = '$Act', COMENTARIO = '$coment', FECHA_CIERRE = now(),ESTADO = 'CERRADA' WHERE ID_SOLICITUD = $id";

        mysql_query($query);

        $response = array("code" => 401);
        return new Response(json_encode($response));

    }



    function CerrarSolicitudesAction(Request $request)
    {
        $act = $request->get("act");
        $get = $request->get("get");
        $cla = $request->get("cla");
        $com = $request->get("com");
        
        $clientes = trim($request->get('cli'));
        
        $clientes = str_replace(","," ", trim($clientes));
        $clientes = str_replace("  "," ", trim($clientes));
        $clientes = str_replace(" ",", ", trim($clientes));

        $query  = "SELECT ID_SOLICITUD AS ID FROM Solicitudes WHERE TIPO_GESTION = '$get' AND ESTADO = 'Abierta' AND ";
        
        if($cla != ''){
            $query .= "CLASIFICACION = '$cla' AND ";
        }

        $query .= "CLIENTE in(".$clientes.")";

        $result = mysql_query($query);

        while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) 
        {
            $line['ID']."\n";  

            $query = "UPDATE solicitudes SET CERRADO = '$act', COMENTARIO = '$com', FECHA_CIERRE = now(),ESTADO = 'CERRADA' WHERE ID_SOLICITUD = ".$line['ID'];
            mysql_query($query);
        }

        $response = array("code" => 401);
        return new Response(json_encode($response));

    }



    function RegistrarSolicitud1Action(Request $request)
    {
        $session = $request->getSession();
        $user = $session->get("user");


        $desc = $request->get("desc");
        $gest = $request->get("gest");
        $clas = $request->get("clas");
        $camp = $request->get("camp");
        $clie = explode(" ", $request->get("clie"));
        $fech = $this->FormatDate($request->get("fech"));

        foreach ($clie as $key => $value) {            
        
            $repository = $this->getDoctrine()->getRepository('GestionBundle:ClientesTbl');
            $cliente = $repository->findOneByClient($value);           

            
            if(!empty($cliente)){
                $Sol = new Solicitudes();

                $Sol->setPrioridad("URGENTE");
                $Sol->setFechaEnvio(new \DateTime($fech));
                $Sol->setTipoGestion($gest);
                $Sol->setClasificacion($clas);
                $Sol->setEstado("ABIERTA");
                $Sol->setOficina($cliente->getOficina());
                $Sol->setCliente($cliente->getClient());
                $Sol->setFechaRecepcion(new \DateTime($fech));
                $Sol->setUsuarioEncargado($user);                
                $Sol->setCampos($camp);
                $Sol->setNombreCliente($cliente->getNombre());
                $Sol->setIdentificacion($cliente->getIdentf());
                $Sol->setDescripcion($desc);


                $em = $this->getDoctrine()->getManager();
                $em->persist($Sol);
                $em->flush();


            }
        }







        $response = array("code" => 401);
        return new Response(json_encode($response));                
    }

    function FormatDate($fecha)
    {
        $fecha = explode("/", $fecha);
        
        return $fecha[2]."-".$fecha[1]."-".$fecha[0];
    }






}//end class







