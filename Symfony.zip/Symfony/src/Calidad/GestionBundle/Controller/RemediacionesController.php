<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query\ResultSetMapping;

use Calidad\GestionBundle\Entity\Observaciones;
use Calidad\GestionBundle\Entity\Solicitudes;
use Calidad\GestionBundle\Entity\Gestiones;
use Calidad\GestionBundle\Entity\Usuario;
use Calidad\GestionBundle\Entity\Remediaciones;
use Calidad\GestionBundle\Entity\CamposRemediados;

set_time_limit ( 0 );

class RemediacionesController extends Controller
{
	public function RemediacionesAction(Request $request)
    {
 		$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");


        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }


        $datos = array(); $i = 0;

        $repository = $this->getDoctrine()->getRepository('GestionBundle:Remediaciones');
		$query = $repository->createQueryBuilder('RE')->getQuery();
		$Remediaciones = $query->getArrayResult();

		foreach ($Remediaciones as $re) {
			$repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario');
			$usuario = $repository->findOneByUser($re["usuario"]);
			
			$nombres = explode(" ", $usuario->getNombre());
			
			$datos[$i] = array(
							"id"=>$re['id'],
							"descripcion"=>$re['descripcion'],
							"fecha"=>date_format($re['fecha'],"d/m/Y"),
							"nombre"=> $nombres[0]." ".$nombres[2],
							"cantidad"=>$re['campos']
						);
			$i++;
		}

        
        return $this->render('GestionBundle:Default:remediaciones.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                "remedia"   =>  $datos
                )
            );
    }



    public function RemediacionesRegistroAction(Request $request)
    {
 		$session = $request->getSession();
        
        $user = $session->get("user");
        


        
    	$descripcion = $request->get("descripcion");
        $fecha = new \DateTime(\DateTime::createFromFormat("d.m.Y", $request->get("fecha")));
        $aplicativo = $request->get("aplicativo");
        $campos = $request->get("campos");
        $cantidad = $request->get("cantidad");


        $remediacion = new Remediaciones();


        $remediacion->setDescripcion($descripcion);
        $remediacion->setFecha($fecha );
        $remediacion->setAplicativo($aplicativo);
        $remediacion->setUsuario($user);
        $remediacion->setCampos($cantidad);

        $em = $this->getDoctrine()->getManager();
        $em->persist($remediacion);
        $em->flush();

        $id_remediacion = $remediacion->getId();
        

        if($id_remediacion != ""){
        
	        foreach ($campos as $key => $value) {
	        	$datos = explode(",",$value);

	        	$campos_rem = new CamposRemediados();

	        	$campos_rem->setIdRemediacion($id_remediacion);
	        	$campos_rem->setTabla($datos[0]);
	        	$campos_rem->setCampo($datos[1]);
	        	$campos_rem->setCantidad($datos[2]);


	        	$em = $this->getDoctrine()->getManager();
		        $em->persist($campos_rem);
		        $em->flush();

	        }
        	$response = Array("code"=>401);
        }else
        {
        	$response = Array("code"=>404);
        }




        


    	return new Response(json_encode($response));
        
    }


    public function RemediacionesCamposAction(Request $request)
    {
    	$response = Array("code"=>404);

    	$id = $request->get('id_re');


    	$repository = $this->getDoctrine()
		    ->getRepository('GestionBundle:CamposRemediados');
		 
		$query = $repository->createQueryBuilder('Ca')
		    ->where('Ca.idRemediacion = :id')
		    ->setParameter('id', $id)
		    ->orderBy('Ca.idRemediacion', 'DESC')
		    ->getQuery();
		 
		$datos2 = $query->getResult();

		$filas = ""; $i = 1;
		foreach ($datos2 as $datos) {
			$filas = $filas."<tr><td class='text-center'>".($i++)."</td><td class='text-center'>".$datos->getTabla()."</td><td class='text-center'>".strtoupper($datos->getCampo())."</td><td class='text-center'>".$datos->getCantidad()."</td></tr>";

			$response = Array("code"=>401,"filas"=>$filas);			
		}

		

		



    	return new Response(json_encode($response));
    }



    public function RefrescarTablaAction(Request $request)
    {
    	$datos = array(); $i = 0;$fila="";

    	$response = Array("code"=>404);	
        
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Remediaciones');
		$query = $repository->createQueryBuilder('RE')->getQuery();
		$Remediaciones = $query->getArrayResult();

		foreach ($Remediaciones as $re) {
			$repository = $this->getDoctrine()->getRepository('GestionBundle:Usuario');
			$usuario = $repository->findOneByUser($re["usuario"]);
			
			$nombres = explode(" ", $usuario->getNombre());
			
			$fila = $fila.'
				<tr>
		            <td class="text-center">'.$re['id'].'</td>
		            <td>'.$re['descripcion'].'</td>
		            <td>'.$nombres[0]." ".$nombres[2].'</td>
		            <td>'.date_format($re['fecha'],"d/m/Y").'</td>
		            <td class="text-center">'.$re['campos'].'</td>
		            <td style="border-radius: 0px;" class="text-center">
		            	<a onclick="getCambos('.$re['id'].')" style="cursor: pointer;">
		            		CAMPOS
		            	</a>
		            </td>

		        </tr>
		        ';
			$response = Array("code"=>401,"filas"=>$fila);	
		}

			
		return new Response(json_encode($response));






    }



}