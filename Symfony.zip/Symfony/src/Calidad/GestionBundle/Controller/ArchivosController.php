<?php

namespace Calidad\GestionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;


set_time_limit(0);
date_default_timezone_set('America/Caracas');

$link = mysql_connect('localhost:3307', 'root', '') or die('No se pudo conectar: ' . mysql_error());
mysql_select_db('calidad') or die('No se pudo seleccionar la base de datos');





//require('C:\xampp\htdocs\Symfony\web\clases\Classes\PHPExcel\IOFactory.php');
//require('C:\xampp\htdocs\Symfony\web\clases\Classes\PHPExcel.php');



class ArchivosController extends Controller
{
    var $archivo = 'prueba';

    public function SolicitudesAction(Request $request)
    {

    	$session = $request->getSession();
        
        $nombre = $session->get("nombre");
        $cargo = $session->get("cargo");
        $rango = $session->get("UserType");
        $user = $session->get("user");
        $foto = $session->get("foto");
		$GESTION = '';
		$usuarios = '';

        if(empty($nombre) && empty($user))
        {
            return $this->redirect($this->generateUrl('index'), 301);
        }

        


        $result = mysql_unbuffered_query("SELECT A.TIPO_GESTION AS GESTION FROM solicitudes AS A GROUP BY A.TIPO_GESTION") or die('Consulta fallida: ' . mysql_error());
        while ($line = mysql_fetch_array($result, MYSQL_ASSOC))
        {
        	$GESTION .= "<option>".$line['GESTION']."</option>";
        }


        $result = mysql_unbuffered_query("SELECT A.`user`,A.nombre FROM usuario AS A INNER JOIN solicitudes AS B ON A.`user` = B.USUARIO_ENCARGADO GROUP BY A.`user`") or die('Consulta fallida: ' . mysql_error());
        while ($line = mysql_fetch_array($result, MYSQL_ASSOC))
        {
        	$usuarios .= "<option value='".$line['user']."'>".utf8_encode($line['nombre'])."</option>";
        }





    	



    	if($request->getMethod() == "POST")
    	{





		}

		
		return $this->render('GestionBundle:Default:archivos.html.twig',
            array(
                "UserType"  =>  $rango,
                "username"  =>  $user,
                "nombre"    =>  $nombre,
                "cargo"     =>  $cargo,
                "foto"      =>  $foto,
                "Usuarios"  =>  $usuarios,
                "gestion"   =>  $GESTION
                )
            );
		
    	//return $this->render('GestionBundle:Default:mensajes_archivos.html.twig',$Datos);
    	
    }



    public function IndicadoresAction(Request $request)
    {
        $session = $request->getSession();
        $this->setDatos("preuab21");

        $fec1 = date('Y-m-d', strtotime(str_replace('/', '-',$request->get('Fech-1'))));
		$fec2 = date('Y-m-d', strtotime(str_replace('/', '-',$request->get('Fech-2'))));


		$fecha = (new \DateTime())->format("Y-m-d");	

        $archivo = 'Consultado solicitudes';

		$objPHPExcel = \PHPExcel_IOFactory::load("C:/xampp/htdocs/Symfony/web/Plantillas/PLATILLA_REPORTE_INDICADORES.xlsx");
    	$objPHPExcel->setActiveSheetIndex(0);
    	$sheet = $objPHPExcel->getActiveSheet();	
        
        $query = 
            "SELECT
				A.PRIORIDAD     AS PRIORI,
				'ACTUALIZACION' AS TIPOSO,
				A.DESCRIPCION   AS DESCRI,
				A.CAMPOS	    AS CAMPOS,
				A.TIPO_GESTION  AS GESTIO,
				'OFICINA'		AS AREAAS,
				A.BANCA			AS BANCAS,
				A.BANCO			AS BANCOS,
				A.OFICINA		AS OFICIN,
				A.USUARIO_ENCARGADO AS USUARIO,
				DATE_FORMAT(A.FECHA_RECEPCION,'%d-%m-%Y') AS FECHREC,
				DATE_FORMAT(A.FECHA_ENVIO,'%d-%m-%Y') AS FECHAEN,
				(DATEDIFF(A.FECHA_RECEPCION,A.FECHA_ENVIO)*-1)-(SELECT COUNT(*) FROM fechas AS B WHERE B.FECHA BETWEEN A.FECHA_RECEPCION AND A.FECHA_ENVIO) AS DIASCD,
				IF(A.FECHA_CIERRE IS NOT NULL,
					(DATEDIFF(A.FECHA_ENVIO,A.FECHA_CIERRE)*-1)-(SELECT COUNT(*) FROM fechas AS B WHERE B.FECHA BETWEEN  A.FECHA_ENVIO AND A.FECHA_CIERRE),
					(DATEDIFF(A.FECHA_ENVIO,'$fecha')*-1)-(SELECT COUNT(*) FROM fechas AS B WHERE B.FECHA BETWEEN  A.FECHA_ENVIO AND '$fecha')
				) AS DIASOFC,
				B.EMAIL AS EJECUT,
				DATE_FORMAT(A.FECHA_CIERRE,'%d-%m-%Y') AS FECHACT,
				A.COMENTARIO AS COMENT,
				A.CLIENTE AS CLIENT,
				A.ESTADO
             FROM
             solicitudes AS A INNER JOIN oficinas AS B ON A.OFICINA = B.OFICINA
             WHERE
             DATE_FORMAT(A.FECHA_ENVIO,'%Y-%m-%d') BETWEEN '$fec1' AND '$fec2' AND
			 A.TIPO_GESTION IN ('CHEQUE DEVUELTO','MONITOR PLUS');
        ";


        $result = mysql_unbuffered_query($query) or die('Consulta fallida: ' . mysql_error());
        $i = 13;
        while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) 
        {
            

            $sheet->setCellValue('B'.$i, $line['PRIORI' ]);
            $sheet->setCellValue('C'.$i, $line['TIPOSO' ]);
            $sheet->setCellValue('D'.$i, utf8_encode($line['DESCRI']));
            $sheet->setCellValue('E'.$i, utf8_encode($line['CAMPOS']));
            $sheet->setCellValue('F'.$i, $line['GESTIO' ]);
            $sheet->setCellValue('G'.$i, $line['AREAAS' ]);
            $sheet->setCellValue('H'.$i, $line['BANCAS' ]);
            $sheet->setCellValue('I'.$i, $line['BANCOS' ]);
            $sheet->setCellValue('J'.$i, $line['OFICIN' ]);
            $sheet->setCellValue('K'.$i, $line['USUARIO']);
            $sheet->setCellValue('L'.$i, $line['FECHREC']);
            $sheet->setCellValue('M'.$i, $line['FECHAEN']);
            $sheet->setCellValue('N'.$i, $line['DIASCD' ]);
            $sheet->setCellValue('O'.$i, $line['DIASOFC']);
            $sheet->setCellValue('P'.$i, $line['EJECUT' ]);
            $sheet->setCellValue('Q'.$i, $line['FECHACT']);
            $sheet->setCellValue('R'.$i, utf8_encode($line['COMENT']));
            $sheet->setCellValue('S'.$i, utf8_encode($line['CLIENT']));
            $sheet->setCellValue('T'.$i, $line['ESTADO' ]);
            $i++;
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $objPHPExcel->setActiveSheetIndex(1);
    	$sheet = $objPHPExcel->getActiveSheet();	



        $query = 
        "SELECT 
		UPPER(A.prioridad) AS PRIORI,
		UPPER(A.tipo) AS TIPOSO,
		UPPER(A.descripcion) AS DESCRI,
		UPPER(A.area) AS AREAA,
		UPPER(A.usuario) AS USUARIO,
		A.fecha_recibida AS FECHA1,
		A.fecha_cierre AS FECHA2,
		UPPER(A.estado) AS ESTATUS,
		'CONFIGURACION DE PRODUCTO' AS UNIDAD
		FROM
		cpsolicitudes AS A
		WHERE
		A.fecha_recibida BETWEEN '$fec1' AND '$fec2';
        ";


        $result = mysql_unbuffered_query($query) or die('Consulta fallida: ' . mysql_error());
        $i = 13;
        while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) 
        {
            $sheet->setCellValue('B'.$i, $line['PRIORI' ]);
            $sheet->setCellValue('C'.$i, utf8_encode($line['TIPOSO' ]));
            $sheet->setCellValue('D'.$i, utf8_encode($line['DESCRI']));
            $sheet->setCellValue('E'.$i, utf8_encode($line['AREAA']));
            $sheet->setCellValue('F'.$i, utf8_encode($line['USUARIO']));
            $sheet->setCellValue('G'.$i, $line['FECHA1' ]);
            $sheet->setCellValue('H'.$i, $line['FECHA2' ]);
            $sheet->setCellValue('I'.$i, utf8_encode($line['ESTATUS' ]));
            $sheet->setCellValue('J'.$i, utf8_encode($line['UNIDAD' ]));
            $i++;
        }


		$this->archivo = 'finalizado';
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="REPORTE GENERAL.xlsx');
        header('Cache-Control: max-age=0');
        

        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        
        //return null;
    }



    function getProgressAction()
    {
        if($this->archivo == 'finalizado'){
            $response = array('code'=>401, 'sms'=> $this->archivo);
        }else{
            $response = array('code'=>404, 'sms'=> $this->archivo);
        }

        return new Response(json_encode($response));
    }


    function setDatos($datos){
        $this->archivo = 'finalizado';
    }





}//END CLASS