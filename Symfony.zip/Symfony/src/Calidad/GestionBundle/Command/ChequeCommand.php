<?php

namespace Calidad\GestionBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

use Calidad\GestionBundle\Entity\ChequeDevuelto;
use Calidad\GestionBundle\Entity\ArchivoSubido;
use Calidad\GestionBundle\Entity\Oficinas;
use Calidad\GestionBundle\Entity\HostEmail;
use Calidad\GestionBundle\Entity\Correocd;
use Calidad\GestionBundle\Entity\Solicitudes;


include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.phpmailer.php');
include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.smtp.php');

set_time_limit(0);
ini_set("memory_limit",-1);


class ChequeCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('gestion:EnviarCheque')
            ->setDescription('Envio de correo a oficinas')
            ->addArgument('name', InputArgument::OPTIONAL, 'Who do you want to greet?')
            ->addOption('yell', null, InputOption::VALUE_NONE, 'If set, the task will yell in uppercase letters')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        //SELECT cheque_devuelto.* FROM cheque_devuelto WHERE cheque_devuelto.NoCliente NOT IN (SELECT SO.CLIENTE FROM SOLICITUDES SO)
        
    	$oficinas = $this->getOficinas($output);
                           
        $output->writeln(date_format(new \DateTime(),"H:m d/m/Y"));
        $output->writeln("+--------------------------------------------------------------------------------+");
        $output->writeln("|                      PROCESO DE ENVIO CHEQUES DEVUELTOS                        |");
    	$output->writeln("+----------+----------------------------------------+---------------+------------+");
        $output->writeln("|CODIGO    |OFICINA                                 |CANT CLIENTES  |ESTADO      |");
        $output->writeln("+----------+----------------------------------------+---------------+------------+");



        if(is_array($oficinas)){
	    	foreach ($oficinas as $codigo) {
	    		if(!empty($codigo["cod"])){
                    $Oficina = $this->getDatosOficinas($codigo["cod"]); $output->write("|".str_pad(trim($codigo["cod"]," "), 10)."|".str_pad(trim($Oficina["Nombre"]," "), 40));
                    $Clientes = $this->getClientes($codigo["cod"], $output); 


                    if($Clientes != null){

                        $output->write("|".str_pad(count($Clientes), 15));
                        
                        if($this->SendMail($Clientes,$Oficina["Correo"],$output) == true){
                            
                            $output->writeln("|".str_pad("ENVIADO", 12)."|");  
                        }else
                        {
                            $output->writeln("|".str_pad("NO ENVIADO", 12)."|");
                        }

                    }
                    else
                    {
                        $output->write("|".str_pad("0", 15));
                        $output->writeln("|".str_pad("NO APLICA", 12)."|");  
                    }
	    		}
	    	}
    	}
    }

    public function getDoctrine()
	{
	    return $this->getContainer()->get('doctrine');
	}


	public function getOficinas($output)
	{
		return $Oficinas = $this->getDoctrine()->getManager()
            ->createQuery('SELECT c.propagencia as cod FROM GestionBundle:ChequeDevuelto c WHERE c.estadoEnvio <> 1 GROUP BY c.propagencia')
            ->getArrayResult();
	}

    public function getDatosOficinas($cod)
    {
        $repository = $this->getDoctrine()
                    ->getRepository('GestionBundle:Oficinas');

        $query = $repository->createQueryBuilder('o')
            ->where('o.oficina = :cod')
            ->setParameter('cod', $cod)
            ->getQuery();

        $Ofi = $query->getResult();


        foreach ($Ofi as $o) {
            return array("Nombre"=> $o->getNombreOficina(), "Correo"=> $o->getEmail());
        }
    }

    public function getClientes($Oficina, $output)
    {

        $em2 = $this->getDoctrine()->getManager();
        $query = $em2->createQuery(
            "SELECT CD FROM GestionBundle:ChequeDevuelto CD
             WHERE CD.estadoEnvio = :estado AND
                   CD.propagencia = :cod
             GROUP BY CD.nocliente"
        )->setParameter('cod', $Oficina)->setParameter('estado', '0');
         
        $Clientes = $query->getResult();

        $ArrayClientes[] = null;
        $Index = 0;


        $em3 = $this->getDoctrine()->getManager();
        foreach ($Clientes as $Client) {
            $em3 = $this->getDoctrine()->getManager();
            $Client->getNoCliente();

            $query = $em3->createQuery(
                "SELECT SO FROM GestionBundle:Solicitudes SO
                 WHERE SO.oficina = :OFICINA AND
                       SO.cliente = :CLIENTE AND
                       SO.tipoGestion = :GESTION
                "
            )->setParameter('OFICINA', $Oficina)
             ->setParameter('CLIENTE', $Client->getNoCliente())
             ->setParameter('GESTION', 'CHEQUE DEVUELTO');
             

            $Sol = $query->getResult();

            if(!$Sol)
            {
                //$Email = $this->ValidarEmail($Client->getEmail());
                //$Telefono1 = $this->ValidarTelefono($Client->getTelefono1(),"local");
                //$Telefono2 = $this->ValidarTelefono($Client->getTelefono2(),"local");
                //$Telefono3 = $this->ValidarTelefono($Client->getTelefono3(),"celular");

                //$output->writeln("Correo: ".$Email." T1:".$Telefono1." T2:".$Telefono2." T3:".$Telefono3);

                //if($Email == 1 || $Telefono1 == 1 || $Telefono2 == 1 || $Telefono3 == 1)
                //{
                    $ArrayClientes[$Index] = $Client;
                    $Index++;
                //}
            }
            $em3->clear();
        }
        if($Index != 0){
            $em2->clear();
            return $ArrayClientes;
        }else{
            return null;
        }

    }
    


   


















    public function SendMail($Clientes,$Correos,$output)
    {
        $asunto = "ACTUALIZACION DE DATOS";

        $filas = "";

        foreach ($Clientes as $Client) {
            
            $Cliente = $Client->getNoCliente();
            $Nombre = $Client->getNomcliente();
            $ID = $Client->getIdentifiacion();



            $filas = $filas.
                "<tr> 
                    <td>".$Client->getNoCliente()."</td>
                    <td>".$Client->getNomcliente()."</td>
                    <td>".$Client->getIdentifiacion()."</td>
                </tr>";

        }


        $body = "
            <div style=\"font-family:Trebuchet MS\">
                Buen d&iacute;a
                
                <p>En el marco del mejoramiento continuo de nuestros procesos y cumpliendo con las normativas que rigen nuestras operaciones, a trav&eacute;s de este medio queremos hacer de su conocimiento la importancia de mantener los datos de los clientes actualizados y consistentes. Para esto la Gerencia de Gesti&oacute;n de Dato y Configuraci&oacute;n de Producto, adscrita a la Vicepresidencia de Gesti&oacute;n para Calidad de Datos, ha dise&ntilde;ado un <i><u><b>Operativo Especial de Actualizaci&oacute;n de Datos</b></u></i> en conjunto con la Red de Agencias. Esta importancia radica principalmente en el mejoramiento del servicio prestado por nuestra instituci&oacute;n, as&iacute; como tambi&eacute;n evitar una posible sanci&oacute;n por parte de los entes regulatorios (SUDEBAN).</p>
                <p>Se Solicita verificar los Tel&eacute;fonos y el correo electronico de los siguiente(s) Cliente(s), ya que no pudieron ser contactados:</p>
                
                <table style=\"border:1px solid #ccc\" cellpadding=\"0\" cellspacing=\"5\" width=\"80%\">
                    <thead>
                        <tr bgcolor=\"#C4D79B\" bordercolordark=\"#666666\">
                            <th><b>Nro. de Cliente</b></th>
                            <th><b>Nombre del Cliente</b></th>
                            <th><b>Identificaci&oacute;n</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        ".$filas."
                    </tbody>
                </table>
                <br><br>

                <p>Es importante mencionar que la actualizaci&oacute;n deben ejecutarla cumpliendo con lo normado en el Manual de Normas y Procedimientos 002-02-A. </p>
                
                <p>\"6.5. Toda modificaci&oacute;n o actualizaci&oacute;n de datos de clientes efectuada en la plataforma GlobalFs debe estar soportada por dos ejemplares del formulario Registro Integral (Persona Natural) Mod. OP/ON-F-0059 o Registro Integral (Persona Jur&iacute;dica) Mod. OP/ON-F-0060 generado por el sistema, para la firma del Cliente y funcionario del banco.\"</p>
                
                <p>Sin nada m&aacute;s a que hacer referencia. </p>
                
                
                <img src='C:\\xampp\\htdocs\\Aplicativo\\web\\firma.png'>
            </div>
        ";



        //$output->writeln($body);

        $mail = new \PHPMailer();
        $mail->IsSMTP(); 
        $mail->IsHTML(true);
        $mail->Host = "mail.bod.com.ve";
        $mail->From = "MONITORCD@bod.com.ve";
        $mail->FromName = "MONITORCD";
        $mail->Subject = $asunto;
        $mail->AltBody = ""; 
        $mail->MsgHTML($body);


        $correo = explode(";",$Correos);

        foreach ($correo as $cor) {
            $mail->AddAddress($cor);
        }
        
        $mail->AddBCC("marinconr@bod.com.ve");
        $mail->AddBCC("gsilva@bod.com.ve");
        //$mail->AddBCC("JREVILLA@bod.com.ve");
        $mail->SMTPAuth = false;


        $estado = $mail->send();
        
        if($estado == true){
            $this->ActualizarEnvio($Clientes,"1");
            return $estado;
        }else{
            //$this->ActualizarEnvio($Clientes,"0");
            return $estado;
        }
    }





    public function ActualizarEnvio($Clientes,$estado){
        
        $emanager = $this->getDoctrine()->getManager();

        foreach ($Clientes as $Client) {

            
            $Regis = $emanager->getRepository('GestionBundle:ChequeDevuelto')->findByNocliente($Client->getNoCliente());
            
            foreach ($Regis as $Reg) {
                $Reg->setEstadoEnvio($estado);
                $emanager->flush();
            }
            
            

            
            $Sol = new Solicitudes();

            $Sol->setPrioridad("URGENTE");
            $Sol->setFechaRecepcion($Client->getFecha());
            $Sol->setFechaEnvio(new \DateTime());
            $Sol->setTipoGestion("CHEQUE DEVUELTO");
            $Sol->setBanco($Client->getBanco());
            $Sol->setOficina($Client->getPropagencia());
            $Sol->setCliente($Client->getNocliente());
            $Sol->setEjecutivo($Client->getEjecutivo());
            $Sol->setBanca($Client->getBanca());
            $Sol->setTipoCliente($Client->getTipoper());
            $Sol->setEstEnvio($estado);

            $emanager->persist($Sol);
            $emanager->flush();
            $emanager->clear();
        }
    

    }

}