<?php

namespace Calidad\GestionBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

use Calidad\GestionBundle\Entity\Munitorplus;
use Calidad\GestionBundle\Entity\Oficinas;
use Calidad\GestionBundle\Entity\Alertas;
use Calidad\GestionBundle\Entity\Solicitudes;


include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.phpmailer.php');
include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.smtp.php');

set_time_limit(0);
ini_set("memory_limit",-1);


class MonitorPlusCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('gestion:EnviarMonitor')
            ->setDescription('Envio de correo a oficinas')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        //SELECT cheque_devuelto.* FROM cheque_devuelto WHERE cheque_devuelto.NoCliente NOT IN (SELECT SO.CLIENTE FROM SOLICITUDES SO)
        
    	$oficinas = $this->getOficinas($output);
        //$Alertas = $this->getAlertas();
        $output->writeln("prueba en equivo gsilva");
        $output->writeln(date_format(new \DateTime(),"h:m d/m/Y"));
        $output->writeln("+--------------------------------------------------------------------------------+");
        $output->writeln("|                          PROCESO DE ENVIO MONITORPLUS                          |");
    	$output->writeln("+----------+----------------------------------------+---------------+------------+");
        $output->writeln("|CODIGO    |OFICINA                                 |CANT CLIENTES  |ESTADO      |");
        $output->writeln("+----------+----------------------------------------+---------------+------------+");




        if(is_array($oficinas)){
            foreach ($oficinas as $codigo) {
                $Oficina = $this->getDatosOficinas($codigo["cod"]); 
                $output->write("|".str_pad(trim($codigo["cod"]," "), 10)."|".str_pad(trim($Oficina["Nombre"]," "), 40));

                $clientes = $this->getClientes($codigo["cod"]);

                if($clientes != null)
                {
                    $output->write("|".str_pad(count($clientes), 15));

                    if($this->SendMail($Oficina["Correo"], $clientes) == true)
                    {
                        $output->writeln("|".str_pad("ENVIADO", 12)."|");  
                    }else
                    {
                        $output->writeln("|".str_pad("NO ENVIADO", 12)."|");
                    }
                    



                }else
                {
                    $output->write("|".str_pad("0", 15));
                }
            }
        }//if
        $output->writeln("+----------+----------------------------------------+---------------+------------+");

    }





    

    public function getDoctrine()
    {
        return $this->getContainer()->get('doctrine');
    }


    public function getOficinas($output)
    {
        return $Oficinas = $this->getDoctrine()->getManager()
            ->createQuery('SELECT MP.agencia as cod FROM GestionBundle:Monitorplus MP WHERE MP.estadoEnvio = :estado GROUP BY MP.agencia')
            ->setParameter("estado","0")
            ->getArrayResult();
    }

    public function getDatosOficinas($cod)
    {
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Oficinas');

        $query = $repository->createQueryBuilder('o')
            ->where('o.oficina = :cod')
            ->setParameter('cod', $cod)
            ->getQuery();

        $Ofi = $query->getResult();

        foreach ($Ofi as $o) {
            return array("Nombre"=> $o->getNombreOficina(), "Correo"=> $o->getEmail());
        }
    }

    public function getClientes($oficina)
    {
        return $Clientes = $this->getDoctrine()->getManager()
            ->createQuery("SELECT MP FROM GestionBundle:Monitorplus MP WHERE MP.agencia = :cod AND MP.estadoEnvio = :estado GROUP BY MP.cliente")
            ->setParameter("cod",$oficina)
            ->setParameter("estado","0")
            ->getResult();
    }

    public function getAlertas()
    {
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Alertas');

        $query = $repository->createQueryBuilder('A')->getQuery()->getResult();

        $Alertas = null;
        
        foreach ($query as $alertas) {
            $Alertas[$alertas->getCodigo()] = array("Desc"=>$alertas->getDescripcion(),"Campo"=>$alertas->getCampo());         
        }

        return $Alertas;
    }

    public function SendMail($Correos, $Clientes)
    {
        $filas = "";


        foreach ($Clientes as $Client) {
           $TS = $this->TieneSolicitud($Client->getCliente(),$Client->getCondicion());

           if($TS == false)
           {
                
                $filas = $filas.
                "<tr> 
                    <td>".$Client->getCliente()."</td>
                    <td>".$this->limpiar($Client->getNomcliente())."</td>
                    <td>".$this->limpiar($Client->getCondicion()->getDescripcion())."</td>
                    <td>".$this->limpiar($Client->getCondicion()->getCampo())."</td>
                </tr>";

           }
           
        }



        $asunto = "ACTUALIZACION DE DATOS (MP)";

        $body = "
                    <div style=\"font-family:Trebuchet MS\">
                        Buen d&iacute;a
                        
                        <p>En el marco del mejoramiento continuo de nuestros procesos y cumpliendo con las normativas que rigen nuestras operaciones, a trav&eacute;s de este medio queremos hacer de su conocimiento la importancia de mantener los datos de los clientes actualizados y consistentes. Para esto la Gerencia de Gesti&oacute;n de Dato y Configuraci&oacute;n de Producto, adscrita a la Vicepresidencia de Gesti&oacute;n para Calidad de Datos, ha dise&ntilde;ado un <i><u><b>Operativo Especial de Actualizaci&oacute;n de Datos</b></u></i> en conjunto con la Red de Agencias. Esta importancia radica principalmente en el mejoramiento del servicio prestado por nuestra instituci&oacute;n, as&iacute; como tambi&eacute;n evitar una posible sanci&oacute;n por parte de los entes regulatorios (SUDEBAN).</p>
                        <p>Se Solicita verificar los Tel&eacute;fonos y el correo electronico de los siguiente(s) Cliente(s), ya que no pudieron ser contactados:</p>
                        
                        <table style=\"border:1px solid #ccc\" cellpadding=\"0\" cellspacing=\"5\" width=\"80%\">
                            <thead>
                                <tr bgcolor=\"#C4D79B\" bordercolordark=\"#666666\">
                                    <th><b>Nro. de Cliente</b></th>
                                    <th><b>Nombre del Cliente</b></th>
                                    <th><b>Descripcion de Error</b></th>
                                    <th><b>Campo a Actualizar</b></th>
                                </tr>
                            </thead>
                            <tbody>
                                ".$filas."
                            </tbody>
                        </table>
                        <br><br>

                        <p>Es importante mencionar que la actualizaci&oacute;n deben ejecutarla cumpliendo con lo normado en el Manual de Normas y Procedimientos 002-02-A. </p>
                        
                        <p>\"6.5. Toda modificaci&oacute;n o actualizaci&oacute;n de datos de clientes efectuada en la plataforma GlobalFs debe estar soportada por dos ejemplares del formulario Registro Integral (Persona Natural) Mod. OP/ON-F-0059 o Registro Integral (Persona Jur&iacute;dica) Mod. OP/ON-F-0060 generado por el sistema, para la firma del Cliente y funcionario del banco.\"</p>
                        
                        <p>Sin nada m&aacute;s a que hacer referencia. </p>
                        
                        
                        <img src='C:\\xampp\\htdocs\\Symfony\\web\\firma.jpg'>
                    </div>        
                ";

        $mail = new \PHPMailer();
        $mail->IsSMTP(); 
        $mail->IsHTML(true);
        $mail->Host = "mail.bod.com.ve";
        $mail->From = "MONITORCD@bod.com.ve";
        $mail->FromName = "MONITORCD";
        $mail->Subject = $asunto;
        $mail->AltBody = ""; 
        $mail->MsgHTML($body);


        //$correo = explode(";",$Correos);

        //foreach ($correo as $cor) {
        //    $mail->AddAddress($cor);
        //}

        $mail->AddAddress("gsilva@bod.com.ve");
       
        //$mail->AddAddress("gsilva@bod.com.ve");
        $mail->AddBCC("marinconr@bod.com.ve");
        $mail->AddBCC("nfernandez@bod.com.ve");
        //$mail->AddBCC("gsilva@bod.com.ve");
        //$mail->AddBCC("JREVILLA@bod.com.ve");
        $mail->SMTPAuth = false;


        $estado = $mail->send();
        
        if($estado == true){
            $this->AgregarSolicitud($Clientes,"1");
            return $estado;
        }else{
            $this->AgregarSolicitud($Clientes,"0");
            return $estado;
        }

    }


    public function TieneSolicitud($Cliente, $Alerta)
    {
        $Clientes = $this->getDoctrine()->getManager()
            ->createQuery("SELECT SO FROM GestionBundle:Solicitudes SO WHERE SO.cliente = :cliente AND SO.alerta = :alerta")
            ->setParameter("cliente",$Cliente)
            ->setParameter("alerta",$Alerta)
            ->getArrayResult();


        

        if(empty($Clientes[0]))
        {
            return false;
        }else{ 
            $Clientes = null;
            return true;
        }

        
    }

    public function AgregarSolicitud($Cliente,$Estado)
    {   
        $em = $this->getDoctrine()->getManager();

        foreach ($Cliente as $Client) {

            $Sol = new Solicitudes();

            $Sol->setPrioridad("URGENTE");
            $Sol->setFechaRecepcion($Client->getFecharecep());
            $Sol->setFechaEnvio(new \DateTime());
            $Sol->setTipoGestion("MONITOR PLUS");
            $Sol->setBanco("BOD");
            $Sol->setOficina($Client->getAgencia());
            $Sol->setCliente($Client->getCliente());

            $Sol->setEjecutivo($Client->getEjecutivo());
            
            $Sol->setAlerta($Client->getCondicion()->getCodigo());
            $Sol->setCuenta($Client->getCuenta());
            $Sol->setFechaApertura($Client->getFechaaper());
            $Sol->setUsuarioEncargado($Client->getEncargado());

            $Sol->setEstEnvio($Estado);

            $em->persist($Sol);
            $em->flush();




            $query = $em->createQuery(
                'SELECT MP
                 FROM GestionBundle:Monitorplus MP
                 WHERE MP.cliente = :cliente AND
                       MP.condicion = :condicion'
            )->setParameter('cliente', $Client->getCliente())
             ->setParameter('condicion', $Client->getCondicion()->getCodigo());
             
            $MPClient = $query->getResult();

            foreach ($MPClient as $MPC) {
                $MPC->setEstadoEnvio($Estado);
                $em->flush();
            }
            
        }

        
    }

    public function limpiar($String){
        $String = str_replace(array('á','à'),"&aacute;",$String);
        $String = str_replace(array('Á','À'),"&Aacute;",$String);
        $String = str_replace(array('é','è'),"&eacute;",$String);
        $String = str_replace(array('É','È'),"&Eacute;",$String);

        $String = str_replace(array('Í','Ì'),"&Iacute;",$String);
        $String = str_replace(array('í','ì'),"&iacute;",$String);
        
        $String = str_replace(array('ó','ò'),"&oacute;",$String);
        $String = str_replace(array('Ó','Ò'),"&Oacute;",$String);
        $String = str_replace(array('ú','ù'),"&uacute;",$String);
        $String = str_replace(array('Ú','Ù'),"&Uacute;",$String);
        return $String;
    }

}//class