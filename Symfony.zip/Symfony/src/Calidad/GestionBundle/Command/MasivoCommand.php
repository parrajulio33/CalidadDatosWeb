<?php

namespace Calidad\GestionBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;


use Calidad\GestionBundle\Entity\Oficinas;
use Calidad\GestionBundle\Entity\Correos;
use Calidad\GestionBundle\Entity\Solicitudes;


include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.phpmailer.php');
include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.smtp.php');

set_time_limit(0);
ini_set("memory_limit",-1);
date_default_timezone_set('America/Caracas');

class MasivoCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('gestion:EnviarMasivo')
            ->setDescription('Envio de correo a oficinas')
            ->addArgument('name', InputArgument::OPTIONAL, 'Who do you want to greet?')
            ->addOption('yell', null, InputOption::VALUE_NONE, 'If set, the task will yell in uppercase letters')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        
        //$output->writeln("Iniciando envio de mensajes");


        $fecha = date_format(new \DateTime(), "g:i A d/m/Y");
        
        echo "\n\n\n";
        echo " ENVIANDO CORREOS A OFICINAS                                                  $fecha\n";
        echo "-------------------------------------------------------------------------------------------------\n";
        echo " OFICINA                                                                     | ESTADO            \n";
        echo "-------------------------------------------------------------------------------------------------\n";
        $oficinas = $this->getOficinas();
        echo "-------------------------------------------------------------------------------------------------\n";

        
        

            
            
       

    }   


    public function getDoctrine()
    {
        return $this->getContainer()->get('doctrine');
    }


    

    


    public function limpiar($String)
    {

        $String = str_replace(array('á','à','â','ã','ª','ä'),"&aacute;",$String);
        $String = str_replace(array('Á','À','Â','Ã','Ä'),    "&Aacute;",$String);
        $String = str_replace(array('Í','Ì','Î','Ï'),        "&eacute;",$String);
        $String = str_replace(array('í','ì','î','ï'),        "&Eacute;",$String);
        $String = str_replace(array('é','è','ê','ë'),        "&iacute;",$String);
        $String = str_replace(array('É','È','Ê','Ë'),        "&Iacute;",$String);
        $String = str_replace(array('ó','ò','ô','õ','ö','º'),"&oacute;",$String);
        $String = str_replace(array('Ó','Ò','Ô','Õ','Ö'),    "&Oacute;",$String);
        $String = str_replace(array('ú','ù','û','ü'),        "&uacute;",$String);
        $String = str_replace(array('Ú','Ù','Û','Ü'),        "&Uacute;",$String);
        
        return $String;
    }




    public function getOficinas()
    {
        $em = $this->getDoctrine()->getManager();
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Oficinas');

        $query = $em->createQuery(
            "SELECT COR.oficina
               FROM GestionBundle:Correos COR
              WHERE COR.rtyp = 'CLIE' AND COR.enviado = 0
             GROUP BY COR.oficina
             ORDER BY COR.oficina ASC"
        );
         
        $Oficinas = $query->getArrayResult();

        $Array = Array();
        
        $em->clear();

        if(!empty($Oficinas))
        {
            foreach ($Oficinas as $key => $value) {
                $query = $repository->createQueryBuilder('O')
                    ->where('O.oficina = :id')
                    ->setParameter('id', $value['oficina'])
                    ->getQuery();
                 
                $ofi = $query->getArrayResult();
                

                foreach ($ofi as $key => $value) {
                    
                    echo " ".str_pad($value['oficina'], 3)." - ".str_pad($value['nombreOficina'], 70)."| ENVIADO\n";
                    $Array[$value['oficina']] = Array("codigo"=>$value['oficina'],"nombre"=>$value['nombreOficina'],"correo"=>$value["email"]);
                }



                
            }

        }



        return $Oficinas;
    }



    public function getCopiar()
    {

        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery(
            "SELECT COR.copia
               FROM GestionBundle:Correos COR
              WHERE COR.rtyp = 'ARCH' AND COR.estado = 0
             GROUP BY COR.oficina
             ORDER BY COR.oficina ASC"
        )->setParameter('id_en', $id_envio);
         
        $Oficinas = $query->getArrayResult();

        $em->clear();





    }
















    public function getClientes($id_envio, $oficina, $copia)
    {

        
        
        
        $Datos_oficina = $this->getDoctrine()->getRepository('GestionBundle:Oficinas')->findOneByOficina($oficina);




        if(!empty($Datos_oficina))
        {
            $em = $this->getDoctrine()->getManager();
            $query = $em->createQuery(
                "SELECT COR
                   FROM GestionBundle:Correos COR
                  WHERE COR.rtyp = 'CLIE' AND COR.idEnv = :id_en AND COR.oficina = :ofi
                 GROUP BY COR.cliente
                "
            )->setParameter('id_en', $id_envio)->setParameter('ofi', $oficina);
             
            $Clientes = $query->getResult();


            $fila = "";

            foreach ($Clientes as $client ) {
                
                $fila .= "<tr><td>".$client->getCliente()."</td><td>".$client->getNombre()."</td><td>".$client->getIdentificacion()."</td><td>".$client->getCampo()."</td><tr>\n";
            }


            $asunto = "ACTUALIZACION DE DATOS";

            $body = "
                <div style=\"font-family:Trebuchet MS\">
                    Buen d&iacute;a
                    
                    <p>En el marco del mejoramiento continuo de nuestros procesos y cumpliendo con las normativas que rigen nuestras operaciones, a trav&eacute;s de este medio queremos hacer de su conocimiento la importancia de mantener los datos de los clientes actualizados y consistentes. Para esto la Gerencia de Gesti&oacute;n de Dato y Configuraci&oacute;n de Producto, adscrita a la Vicepresidencia de Gesti&oacute;n para Calidad de Datos, ha dise&ntilde;ado un <i><u><b>Operativo Especial de Actualizaci&oacute;n de Datos</b></u></i> en conjunto con la Red de Agencias. Esta importancia radica principalmente en el mejoramiento del servicio prestado por nuestra instituci&oacute;n, as&iacute; como tambi&eacute;n evitar una posible sanci&oacute;n por parte de los entes regulatorios (SUDEBAN).</p>
                    <p>Se Solicita verificar los Tel&eacute;fonos y el correo electronico de los siguiente(s) Cliente(s), ya que no pudieron ser contactados:</p>
                    
                    <table style=\"border:1px solid #ccc\" cellpadding=\"0\" cellspacing=\"5\" width=\"80%\">
                        <thead>
                            <tr bgcolor=\"#C4D79B\" bordercolordark=\"#666666\">
                                <th><b>Nro. de Cliente</b></th>
                                <th><b>Nombre del Cliente</b></th>
                                <th><b>Identificaci&oacute;n</b></th>
                                <th><b>Campo Requerido</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            ".str_replace("#","&ntilde;",$fila)."
                        </tbody>
                    </table>
                    <br><br>

                    <p>Es importante mencionar que la actualizaci&oacute;n deben ejecutarla cumpliendo con lo normado en el Manual de Normas y Procedimientos 002-02-A. </p>
                    
                    <p>\"6.5. Toda modificaci&oacute;n o actualizaci&oacute;n de datos de clientes efectuada en la plataforma GlobalFs debe estar soportada por dos ejemplares del formulario Registro Integral (Persona Natural) Mod. OP/ON-F-0059 o Registro Integral (Persona Jur&iacute;dica) Mod. OP/ON-F-0060 generado por el sistema, para la firma del Cliente y funcionario del banco.\"</p>
                    
                    <p>Sin nada m&aacute;s a que hacer referencia. </p>
                    
                    
                    <img src='C:\\xampp\\htdocs\\Aplicativo\\web\\firma.png'>
                </div>
            ";


             //$output->writeln($body);

            $mail = new \PHPMailer();
            $mail->IsSMTP(); 
            $mail->IsHTML(true);
            $mail->Host = "mail.bod.com.ve";
            $mail->From = "MONITORCD@bod.com.ve";
            $mail->FromName = "MONITORCD";
            $mail->Subject = $asunto;
            $mail->AltBody = ""; 
            $mail->MsgHTML($this->limpiar($body));


            

            
            //$mail->AddAddress("gsilva@bod.com.ve");
            
            
            //$mail->AddBCC("marinconr@bod.com.ve");
            //$mail->AddBCC("gsilva@bod.com.ve");
            //$mail->AddBCC("JREVILLA@bod.com.ve");
            $mail->SMTPAuth = false;


            $estado = $mail->send();
            
            if($estado == true){
                echo "Correo enviado\n";
            }
        }//inicio del if
        else
        {
            echo "NO EXISTE LA OFICINA NO. $oficina \n";
        }

    }


    public function getArchivo($id_archivo)
    {
        $em = $this->getDoctrine()->getRepository("GestionBundle:Correos");
    }




}