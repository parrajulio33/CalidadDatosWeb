<?php

namespace Calidad\GestionBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

use Calidad\GestionBundle\Entity\ChequeDevuelto;
use Calidad\GestionBundle\Entity\ArchivoSubido;
use Calidad\GestionBundle\Entity\Oficinas;
use Calidad\GestionBundle\Entity\HostEmail;
use Calidad\GestionBundle\Entity\Correocd;
use Calidad\GestionBundle\Entity\Solicitudes;
use Calidad\GestionBundle\Entity\Reenvios;
use Calidad\GestionBundle\Entity\Estadisticasreenvio;



include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.phpmailer.php');
include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.smtp.php');

set_time_limit(0);
ini_set("memory_limit",-1);

//C:/xampp/php/php.exe C:/xampp/htdocs/Symfony/app/console gestion:ReenviarHallazgo

class ReenvioHallazgoCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('gestion:ReenviarHallazgo')
            ->setDescription('Envio de correo a oficinas')
            ->addArgument('name', InputArgument::OPTIONAL, 'Who do you want to greet?')
            ->addOption('yell', null, InputOption::VALUE_NONE, 'If set, the task will yell in uppercase letters')
        ;
    }



    protected function execute(InputInterface $input, OutputInterface $output)
    {


        $oficinas = $this->getOficinas();
        $solicitudes = null;
        $cantidad = 0;

        $reenvio = new Reenvios();

        $reenvio->setDescripcion("Reenvio de solicitudes realizadas a oficinas por hallazgo");
        $reenvio->setfecha(new \DateTime());
        $em = $this->getDoctrine()->getManager();
        $em->persist($reenvio);
        $em->flush();


        foreach ($oficinas as $ofi) {
            $solicitudes = $this->getSolicitudes($ofi["codigo"]);
            
            if(!empty($solicitudes))
            {
                $enviado = $this->sendMail($solicitudes,$ofi["correo"],$ofi["codigo"],$reenvio->getIdEnvio());
                

                if($enviado == true){
                    
                    $cantidad =  $cantidad+count($solicitudes);
                    echo "Correo enviado a la oficina ".$ofi["codigo"]."\n";
                }
            }

        }

        
        $reenvio->setEstado("Completo");
        $em =  $this->getDoctrine()->getMaganers();
        $em->persist($reenvio);
        $em->flush();

    }



    public function getDoctrine()
    {
        return $this->getContainer()->get('doctrine');
    }


    public function getOficinas()
    {
        $oficinas = $this->getDoctrine()->getRepository("GestionBundle:Oficinas")->findAll();
        $Oficinas = array();

        foreach ($oficinas as $ofi ) {
                
            $Oficinas[$ofi->getOficina()]= array("codigo"=>$ofi->getOficina(),"correo"=>$ofi->getEmail());

        }

        return $Oficinas;


    }

    public function getSolicitudes($id_oficina)
    {
        $repository = $this->getDoctrine()->getRepository('GestionBundle:Solicitudes');
         
        $query = $repository->createQueryBuilder('so')
            ->where('so.oficina = :ofi and so.tipoGestion = :tg and so.estado = :est' )
            ->setParameter('ofi', $id_oficina)
            ->setParameter('tg', "HALLAZGO")
            ->setParameter('est', "ABIERTA")
            ->getQuery()->getResult();
         
        return $query;
    }

    
    public function sendMail($solicitudes,$correos,$oficina,$id_reenvio)
    {
        





        $filas = "";

        foreach ($solicitudes as $sol) {
            
            $filas .="
            <tr>
                <td>".$sol->getCliente()."</td>
                <td>".$sol->getNombreCliente()."</td>
                <td>".$sol->getIdentificacion()."</td>
                <td>".$sol->getEjecutivo()."</td>
                <td>".$sol->getCampos()."</td>
            </tr>";
        }
        

        $asunto = "RV:ACTUALIZACION DE DATOS";
        
        $body = "
            <div style=\"font-family:Trebuchet MS\">
                Buen d&iacute;a
                
                <p>En el marco del mejoramiento continuo de nuestros procesos y cumpliendo con las normativas que rigen nuestras operaciones, a trav&eacute;s de este medio queremos hacer de su conocimiento la importancia de mantener los datos de los clientes actualizados y consistentes. Para esto la Gerencia de Gesti&oacute;n de Dato y Configuraci&oacute;n de Producto, adscrita a la Vicepresidencia de Gesti&oacute;n para Calidad de Datos, ha dise&ntilde;ado un <i><u><b>Operativo Especial de Actualizaci&oacute;n de Datos</b></u></i> en conjunto con la Red de Agencias. Esta importancia radica principalmente en el mejoramiento del servicio prestado por nuestra instituci&oacute;n, as&iacute; como tambi&eacute;n evitar una posible sanci&oacute;n por parte de los entes regulatorios (SUDEBAN).</p>
                <p>Se Solicita la actualizacion de los siguiente(s) Cliente(s):</p>
                
                <table style=\"border:1px solid #ccc\" cellpadding=\"0\" cellspacing=\"5\" width=\"100%\">
                    <thead>
                        <tr bgcolor=\"#C4D79B\" bordercolordark=\"#666666\">
                            <th><b>Nro. de Cliente</b></th>
                            <th><b>Nombre del Cliente</b></th>
                            <th><b>Identificaci&oacute;n</b></th>
                            <th><b>Ejecutivo</b></th>
                            <th><b>Campo</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        ".$this->limpiar($filas)."
                    </tbody>
                </table>
                <br><br>

                <p>Es importante mencionar que la actualizaci&oacute;n deben ejecutarla cumpliendo con lo normado en el Manual de Normas y Procedimientos 002-02-A. </p>
                
                <p>\"6.5. Toda modificaci&oacute;n o actualizaci&oacute;n de datos de clientes efectuada en la plataforma GlobalFs debe estar soportada por dos ejemplares del formulario Registro Integral (Persona Natural) Mod. OP/ON-F-0059 o Registro Integral (Persona Jur&iacute;dica) Mod. OP/ON-F-0060 generado por el sistema, para la firma del Cliente y funcionario del banco.\"</p>
                
                <p>Sin nada m&aacute;s a que hacer referencia. </p>
                
                <a href='mailto:monitorcd@bod.com.ve'>
                    <img src='C:\\xampp\\htdocs\\Aplicativo\\web\\firma.png'>
                </a>
            </div>
        ";


        $mail = new \PHPMailer();
        $mail->IsSMTP(); 
        $mail->IsHTML(true);
        $mail->Host = "mail.bod.com.ve";
        $mail->From = "MONITORCD@bod.com.ve";
        $mail->FromName = "MONITORCD";
        $mail->Subject = $asunto;
        $mail->AltBody = ""; 
        $mail->MsgHTML($body);

        
        $correo = explode(";",$correos);
        
        foreach ($correo as $cor) {
            $mail->AddAddress($cor);
        }//correos
        


        
        //$mail->AddAddress("gsilva@bod.com.ve");

        //$mail->AddBCC("marinconr@bod.com.ve");
        $mail->AddBCC("gsilva@bod.com.ve");
        //$mail->AddBCC("JREVILLA@bod.com.ve");
        $mail->SMTPAuth = false;


        $estado = $mail->send();

        if($estado == true)
        {
            $estadistica = new Estadisticasreenvio();

            $estadistica->setIdEnvio($id_reenvio);
            $estadistica->setOficina($oficina);
            $estadistica->setCantidad(count($solicitudes));

            $em = $this->getDoctrine()->getManager();
            $em->persist($estadistica);
            $em->flush();

            return true;
        }else
        {
            return false;
        }


    }


    public function limpiar($String)
    {
        $String = str_replace(array('á','à','â','ã','ª','ä'),"a",$String);
        $String = str_replace(array('Á','À','Â','Ã','Ä'),"A",$String);
        $String = str_replace(array('Í','Ì','Î','Ï'),"I",$String);
        $String = str_replace(array('í','ì','î','ï'),"i",$String);
        $String = str_replace(array('é','è','ê','ë'),"e",$String);
        $String = str_replace(array('É','È','Ê','Ë'),"E",$String);
        $String = str_replace(array('ó','ò','ô','õ','ö','º'),"o",$String);
        $String = str_replace(array('Ó','Ò','Ô','Õ','Ö'),"O",$String);
        $String = str_replace(array('ú','ù','û','ü'),"u",$String);
        $String = str_replace(array('Ú','Ù','Û','Ü'),"U",$String);
        $String = str_replace(array('[','^','´','`','¨','~',']'),"",$String);
        $String = str_replace("ç","c",$String);
        $String = str_replace("Ç","C",$String);
        //$String = str_replace("ñ","n",$String);
        //$String = str_replace("Ñ","N",$String);
        $String = str_replace("Ý","Y",$String);
        $String = str_replace("ý","y",$String); 
        
        $String = str_replace("&aacute;","a",$String);
        $String = str_replace("&Aacute;","A",$String);
        $String = str_replace("&eacute;","e",$String);
        $String = str_replace("&Eacute;","E",$String);
        $String = str_replace("&iacute;","i",$String);
        $String = str_replace("&Iacute;","I",$String);
        $String = str_replace("&oacute;","o",$String);
        $String = str_replace("&Oacute;","O",$String);
        $String = str_replace("&uacute;","u",$String);
        $String = str_replace("&Uacute;","U",$String);
        

        return $String;
    }





}