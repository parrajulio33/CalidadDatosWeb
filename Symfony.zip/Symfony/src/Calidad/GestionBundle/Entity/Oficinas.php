<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Oficinas
 *
 * @ORM\Table(name="oficinas")
 * @ORM\Entity
 */
class Oficinas
{
    /**
     * @var integer
     *
     * @ORM\Column(name="OFICINA", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $oficina = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="NOMBRE_OFICINA", type="string", length=255, nullable=true)
     */
    private $nombreOficina;

    /**
     * @var string
     *
     * @ORM\Column(name="EMAIL", type="text", nullable=true)
     */
    private $email;



    /**
     * Get oficina
     *
     * @return integer 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set nombreOficina
     *
     * @param string $nombreOficina
     * @return Oficinas
     */
    public function setNombreOficina($nombreOficina)
    {
        $this->nombreOficina = $nombreOficina;

        return $this;
    }

    /**
     * Get nombreOficina
     *
     * @return string 
     */
    public function getNombreOficina()
    {
        return $this->nombreOficina;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return Oficinas
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }
}
