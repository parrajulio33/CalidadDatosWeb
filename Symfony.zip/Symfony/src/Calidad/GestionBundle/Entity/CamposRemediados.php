<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CamposRemediados
 *
 * @ORM\Table(name="campos_remediados")
 * @ORM\Entity
 */
class CamposRemediados
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_remediacion", type="integer", nullable=true)
     */
    private $idRemediacion;

    /**
     * @var string
     *
     * @ORM\Column(name="tabla", type="string", length=255, nullable=true)
     */
    private $tabla;

    /**
     * @var string
     *
     * @ORM\Column(name="campo", type="string", length=255, nullable=true)
     */
    private $campo;

    /**
     * @var integer
     *
     * @ORM\Column(name="cantidad", type="integer", nullable=true)
     */
    private $cantidad;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idRemediacion
     *
     * @param integer $idRemediacion
     * @return CamposRemediados
     */
    public function setIdRemediacion($idRemediacion)
    {
        $this->idRemediacion = $idRemediacion;

        return $this;
    }

    /**
     * Get idRemediacion
     *
     * @return integer 
     */
    public function getIdRemediacion()
    {
        return $this->idRemediacion;
    }

    /**
     * Set tabla
     *
     * @param string $tabla
     * @return CamposRemediados
     */
    public function setTabla($tabla)
    {
        $this->tabla = $tabla;

        return $this;
    }

    /**
     * Get tabla
     *
     * @return string 
     */
    public function getTabla()
    {
        return $this->tabla;
    }

    /**
     * Set campo
     *
     * @param string $campo
     * @return CamposRemediados
     */
    public function setCampo($campo)
    {
        $this->campo = $campo;

        return $this;
    }

    /**
     * Get campo
     *
     * @return string 
     */
    public function getCampo()
    {
        return $this->campo;
    }

    /**
     * Set cantidad
     *
     * @param integer $cantidad
     * @return CamposRemediados
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;

        return $this;
    }

    /**
     * Get cantidad
     *
     * @return integer 
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }
}
