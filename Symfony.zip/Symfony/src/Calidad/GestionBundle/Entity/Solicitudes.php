<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Solicitudes
 *
 * @ORM\Table(name="solicitudes")
 * @ORM\Entity
 */
class Solicitudes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID_SOLICITUD", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idSolicitud;

    /**
     * @var string
     *
     * @ORM\Column(name="PRIORIDAD", type="string", length=255, nullable=true)
     */
    private $prioridad = 'URGENTE';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_ENVIO", type="date", nullable=true)
     */
    private $fechaEnvio;

    /**
     * @var string
     *
     * @ORM\Column(name="TIPO_GESTION", type="string", length=255, nullable=false)
     */
    private $tipoGestion;

    /**
     * @var string
     *
     * @ORM\Column(name="CLASIFICACION", type="string", length=255, nullable=false)
     */
    private $clasificacion;

    /**
     * @var string
     *
     * @ORM\Column(name="ESTADO", type="string", length=255, nullable=true)
     */
    private $estado;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_CIERRE", type="date", nullable=true)
     */
    private $fechaCierre;

    /**
     * @var string
     *
     * @ORM\Column(name="BANCO", type="string", length=255, nullable=true)
     */
    private $banco;

    /**
     * @var integer
     *
     * @ORM\Column(name="OFICINA", type="integer", nullable=true)
     */
    private $oficina;

    /**
     * @var integer
     *
     * @ORM\Column(name="CLIENTE", type="integer", nullable=false)
     */
    private $cliente;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;

    /**
     * @var integer
     *
     * @ORM\Column(name="ALERTA", type="integer", nullable=true)
     */
    private $alerta;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_RECEPCION", type="date", nullable=true)
     */
    private $fechaRecepcion;

    /**
     * @var string
     *
     * @ORM\Column(name="USUARIO_ENCARGADO", type="string", length=255, nullable=true)
     */
    private $usuarioEncargado;

    /**
     * @var string
     *
     * @ORM\Column(name="BANCA", type="string", length=255, nullable=true)
     */
    private $banca;

    /**
     * @var string
     *
     * @ORM\Column(name="CAMPOS", type="string", length=255, nullable=true)
     */
    private $campos;

    /**
     * @var string
     *
     * @ORM\Column(name="COMENTARIO", type="string", length=255, nullable=true)
     */
    private $comentario;

    /**
     * @var string
     *
     * @ORM\Column(name="CERRADO", type="string", length=255, nullable=true)
     */
    private $cerrado;

    /**
     * @var string
     *
     * @ORM\Column(name="NOMBRE_CLIENTE", type="string", length=255, nullable=true)
     */
    private $nombreCliente;

    /**
     * @var integer
     *
     * @ORM\Column(name="IDENTIFICACION", type="integer", nullable=true)
     */
    private $identificacion;

    /**
     * @var string
     *
     * @ORM\Column(name="DESCRIPCION", type="string", length=255, nullable=true)
     */
    private $descripcion;

    /**
     * @var integer
     *
     * @ORM\Column(name="CONFIG_MA", type="integer", nullable=true)
     */
    private $configMa;

    /**
     * @var integer
     *
     * @ORM\Column(name="NUM_ENVIOS", type="integer", nullable=true)
     */
    private $numEnvios = '1';



    /**
     * Get idSolicitud
     *
     * @return integer 
     */
    public function getIdSolicitud()
    {
        return $this->idSolicitud;
    }

    /**
     * Set prioridad
     *
     * @param string $prioridad
     * @return Solicitudes
     */
    public function setPrioridad($prioridad)
    {
        $this->prioridad = $prioridad;

        return $this;
    }

    /**
     * Get prioridad
     *
     * @return string 
     */
    public function getPrioridad()
    {
        return $this->prioridad;
    }

    /**
     * Set fechaEnvio
     *
     * @param \DateTime $fechaEnvio
     * @return Solicitudes
     */
    public function setFechaEnvio($fechaEnvio)
    {
        $this->fechaEnvio = $fechaEnvio;

        return $this;
    }

    /**
     * Get fechaEnvio
     *
     * @return \DateTime 
     */
    public function getFechaEnvio()
    {
        return $this->fechaEnvio;
    }

    /**
     * Set tipoGestion
     *
     * @param string $tipoGestion
     * @return Solicitudes
     */
    public function setTipoGestion($tipoGestion)
    {
        $this->tipoGestion = $tipoGestion;

        return $this;
    }

    /**
     * Get tipoGestion
     *
     * @return string 
     */
    public function getTipoGestion()
    {
        return $this->tipoGestion;
    }

    /**
     * Set clasificacion
     *
     * @param string $clasificacion
     * @return Solicitudes
     */
    public function setClasificacion($clasificacion)
    {
        $this->clasificacion = $clasificacion;

        return $this;
    }

    /**
     * Get clasificacion
     *
     * @return string 
     */
    public function getClasificacion()
    {
        return $this->clasificacion;
    }

    /**
     * Set estado
     *
     * @param string $estado
     * @return Solicitudes
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;

        return $this;
    }

    /**
     * Get estado
     *
     * @return string 
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * Set fechaCierre
     *
     * @param \DateTime $fechaCierre
     * @return Solicitudes
     */
    public function setFechaCierre($fechaCierre)
    {
        $this->fechaCierre = $fechaCierre;

        return $this;
    }

    /**
     * Get fechaCierre
     *
     * @return \DateTime 
     */
    public function getFechaCierre()
    {
        return $this->fechaCierre;
    }

    /**
     * Set banco
     *
     * @param string $banco
     * @return Solicitudes
     */
    public function setBanco($banco)
    {
        $this->banco = $banco;

        return $this;
    }

    /**
     * Get banco
     *
     * @return string 
     */
    public function getBanco()
    {
        return $this->banco;
    }

    /**
     * Set oficina
     *
     * @param integer $oficina
     * @return Solicitudes
     */
    public function setOficina($oficina)
    {
        $this->oficina = $oficina;

        return $this;
    }

    /**
     * Get oficina
     *
     * @return integer 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set cliente
     *
     * @param integer $cliente
     * @return Solicitudes
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;

        return $this;
    }

    /**
     * Get cliente
     *
     * @return integer 
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return Solicitudes
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }

    /**
     * Set alerta
     *
     * @param integer $alerta
     * @return Solicitudes
     */
    public function setAlerta($alerta)
    {
        $this->alerta = $alerta;

        return $this;
    }

    /**
     * Get alerta
     *
     * @return integer 
     */
    public function getAlerta()
    {
        return $this->alerta;
    }

    /**
     * Set fechaRecepcion
     *
     * @param \DateTime $fechaRecepcion
     * @return Solicitudes
     */
    public function setFechaRecepcion($fechaRecepcion)
    {
        $this->fechaRecepcion = $fechaRecepcion;

        return $this;
    }

    /**
     * Get fechaRecepcion
     *
     * @return \DateTime 
     */
    public function getFechaRecepcion()
    {
        return $this->fechaRecepcion;
    }

    /**
     * Set usuarioEncargado
     *
     * @param string $usuarioEncargado
     * @return Solicitudes
     */
    public function setUsuarioEncargado($usuarioEncargado)
    {
        $this->usuarioEncargado = $usuarioEncargado;

        return $this;
    }

    /**
     * Get usuarioEncargado
     *
     * @return string 
     */
    public function getUsuarioEncargado()
    {
        return $this->usuarioEncargado;
    }

    /**
     * Set banca
     *
     * @param string $banca
     * @return Solicitudes
     */
    public function setBanca($banca)
    {
        $this->banca = $banca;

        return $this;
    }

    /**
     * Get banca
     *
     * @return string 
     */
    public function getBanca()
    {
        return $this->banca;
    }

    /**
     * Set campos
     *
     * @param string $campos
     * @return Solicitudes
     */
    public function setCampos($campos)
    {
        $this->campos = $campos;

        return $this;
    }

    /**
     * Get campos
     *
     * @return string 
     */
    public function getCampos()
    {
        return $this->campos;
    }

    /**
     * Set comentario
     *
     * @param string $comentario
     * @return Solicitudes
     */
    public function setComentario($comentario)
    {
        $this->comentario = $comentario;

        return $this;
    }

    /**
     * Get comentario
     *
     * @return string 
     */
    public function getComentario()
    {
        return $this->comentario;
    }

    /**
     * Set cerrado
     *
     * @param string $cerrado
     * @return Solicitudes
     */
    public function setCerrado($cerrado)
    {
        $this->cerrado = $cerrado;

        return $this;
    }

    /**
     * Get cerrado
     *
     * @return string 
     */
    public function getCerrado()
    {
        return $this->cerrado;
    }

    /**
     * Set nombreCliente
     *
     * @param string $nombreCliente
     * @return Solicitudes
     */
    public function setNombreCliente($nombreCliente)
    {
        $this->nombreCliente = $nombreCliente;

        return $this;
    }

    /**
     * Get nombreCliente
     *
     * @return string 
     */
    public function getNombreCliente()
    {
        return $this->nombreCliente;
    }

    /**
     * Set identificacion
     *
     * @param integer $identificacion
     * @return Solicitudes
     */
    public function setIdentificacion($identificacion)
    {
        $this->identificacion = $identificacion;

        return $this;
    }

    /**
     * Get identificacion
     *
     * @return integer 
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return Solicitudes
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set configMa
     *
     * @param integer $configMa
     * @return Solicitudes
     */
    public function setConfigMa($configMa)
    {
        $this->configMa = $configMa;

        return $this;
    }

    /**
     * Get configMa
     *
     * @return integer 
     */
    public function getConfigMa()
    {
        return $this->configMa;
    }

    /**
     * Set numEnvios
     *
     * @param integer $numEnvios
     * @return Solicitudes
     */
    public function setNumEnvios($numEnvios)
    {
        $this->numEnvios = $numEnvios;

        return $this;
    }

    /**
     * Get numEnvios
     *
     * @return integer 
     */
    public function getNumEnvios()
    {
        return $this->numEnvios;
    }
}
