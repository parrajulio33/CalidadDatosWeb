<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Monitorplus
 *
 * @ORM\Table(name="monitorplus")
 * @ORM\Entity
 */
class Monitorplus
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="BANCO", type="integer", nullable=true)
     */
    private $banco;

    /**
     * @var integer
     *
     * @ORM\Column(name="AGENCIA", type="integer", nullable=true)
     */
    private $agencia;

    /**
     * @var string
     *
     * @ORM\Column(name="CLIENTE", type="string", length=255, nullable=false)
     */
    private $cliente;

    /**
     * @var string
     *
     * @ORM\Column(name="NOMCLIENTE", type="string", length=255, nullable=true)
     */
    private $nomcliente;

    /**
     * @var string
     *
     * @ORM\Column(name="USUARIO", type="string", length=255, nullable=true)
     */
    private $usuario;

    /**
     * @var string
     *
     * @ORM\Column(name="CUENTA", type="string", length=255, nullable=true)
     */
    private $cuenta;

    /**
     * @var integer
     *
     * @ORM\Column(name="BANCA", type="integer", nullable=true)
     */
    private $banca;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;

    /**
     * @var integer
     *
     * @ORM\Column(name="CONDICION", type="integer", nullable=true)
     */
    private $condicion;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHARECEP", type="date", nullable=true)
     */
    private $fecharecep;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHAAPER", type="date", nullable=true)
     */
    private $fechaaper;

    /**
     * @var string
     *
     * @ORM\Column(name="ENCARGADO", type="string", length=255, nullable=true)
     */
    private $encargado;

    /**
     * @var integer
     *
     * @ORM\Column(name="ESTADO_ENVIO", type="integer", nullable=true)
     */
    private $estadoEnvio = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="ARCHIVO", type="integer", nullable=true)
     */
    private $archivo;

    /**
     * @var integer
     *
     * @ORM\Column(name="IDENTIFICACION", type="integer", nullable=true)
     */
    private $identificacion;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set banco
     *
     * @param integer $banco
     * @return Monitorplus
     */
    public function setBanco($banco)
    {
        $this->banco = $banco;

        return $this;
    }

    /**
     * Get banco
     *
     * @return integer 
     */
    public function getBanco()
    {
        return $this->banco;
    }

    /**
     * Set agencia
     *
     * @param integer $agencia
     * @return Monitorplus
     */
    public function setAgencia($agencia)
    {
        $this->agencia = $agencia;

        return $this;
    }

    /**
     * Get agencia
     *
     * @return integer 
     */
    public function getAgencia()
    {
        return $this->agencia;
    }

    /**
     * Set cliente
     *
     * @param string $cliente
     * @return Monitorplus
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;

        return $this;
    }

    /**
     * Get cliente
     *
     * @return string 
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * Set nomcliente
     *
     * @param string $nomcliente
     * @return Monitorplus
     */
    public function setNomcliente($nomcliente)
    {
        $this->nomcliente = $nomcliente;

        return $this;
    }

    /**
     * Get nomcliente
     *
     * @return string 
     */
    public function getNomcliente()
    {
        return $this->nomcliente;
    }

    /**
     * Set usuario
     *
     * @param string $usuario
     * @return Monitorplus
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return string 
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * Set cuenta
     *
     * @param string $cuenta
     * @return Monitorplus
     */
    public function setCuenta($cuenta)
    {
        $this->cuenta = $cuenta;

        return $this;
    }

    /**
     * Get cuenta
     *
     * @return string 
     */
    public function getCuenta()
    {
        return $this->cuenta;
    }

    /**
     * Set banca
     *
     * @param integer $banca
     * @return Monitorplus
     */
    public function setBanca($banca)
    {
        $this->banca = $banca;

        return $this;
    }

    /**
     * Get banca
     *
     * @return integer 
     */
    public function getBanca()
    {
        return $this->banca;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return Monitorplus
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }

    /**
     * Set condicion
     *
     * @param integer $condicion
     * @return Monitorplus
     */
    public function setCondicion($condicion)
    {
        $this->condicion = $condicion;

        return $this;
    }

    /**
     * Get condicion
     *
     * @return integer 
     */
    public function getCondicion()
    {
        return $this->condicion;
    }

    /**
     * Set fecharecep
     *
     * @param \DateTime $fecharecep
     * @return Monitorplus
     */
    public function setFecharecep($fecharecep)
    {
        $this->fecharecep = $fecharecep;

        return $this;
    }

    /**
     * Get fecharecep
     *
     * @return \DateTime 
     */
    public function getFecharecep()
    {
        return $this->fecharecep;
    }

    /**
     * Set fechaaper
     *
     * @param \DateTime $fechaaper
     * @return Monitorplus
     */
    public function setFechaaper($fechaaper)
    {
        $this->fechaaper = $fechaaper;

        return $this;
    }

    /**
     * Get fechaaper
     *
     * @return \DateTime 
     */
    public function getFechaaper()
    {
        return $this->fechaaper;
    }

    /**
     * Set encargado
     *
     * @param string $encargado
     * @return Monitorplus
     */
    public function setEncargado($encargado)
    {
        $this->encargado = $encargado;

        return $this;
    }

    /**
     * Get encargado
     *
     * @return string 
     */
    public function getEncargado()
    {
        return $this->encargado;
    }

    /**
     * Set estadoEnvio
     *
     * @param integer $estadoEnvio
     * @return Monitorplus
     */
    public function setEstadoEnvio($estadoEnvio)
    {
        $this->estadoEnvio = $estadoEnvio;

        return $this;
    }

    /**
     * Get estadoEnvio
     *
     * @return integer 
     */
    public function getEstadoEnvio()
    {
        return $this->estadoEnvio;
    }

    /**
     * Set archivo
     *
     * @param integer $archivo
     * @return Monitorplus
     */
    public function setArchivo($archivo)
    {
        $this->archivo = $archivo;

        return $this;
    }

    /**
     * Get archivo
     *
     * @return integer 
     */
    public function getArchivo()
    {
        return $this->archivo;
    }

    /**
     * Set identificacion
     *
     * @param integer $identificacion
     * @return Monitorplus
     */
    public function setIdentificacion($identificacion)
    {
        $this->identificacion = $identificacion;

        return $this;
    }

    /**
     * Get identificacion
     *
     * @return integer 
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }
}
