<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Fechas
 *
 * @ORM\Table(name="fechas")
 * @ORM\Entity
 */
class Fechas
{
    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA", type="date", nullable=true)
     */
    private $fecha;

    /**
     * @var string
     *
     * @ORM\Column(name="holdad", type="string", length=255, nullable=true)
     */
    private $holdad;

    /**
     * @var string
     *
     * @ORM\Column(name="holdam", type="string", length=255, nullable=true)
     */
    private $holdam;

    /**
     * @var string
     *
     * @ORM\Column(name="holday", type="string", length=255, nullable=true)
     */
    private $holday;

    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;



    /**
     * Set fecha
     *
     * @param \DateTime $fecha
     * @return Fechas
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \DateTime 
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set holdad
     *
     * @param string $holdad
     * @return Fechas
     */
    public function setHoldad($holdad)
    {
        $this->holdad = $holdad;

        return $this;
    }

    /**
     * Get holdad
     *
     * @return string 
     */
    public function getHoldad()
    {
        return $this->holdad;
    }

    /**
     * Set holdam
     *
     * @param string $holdam
     * @return Fechas
     */
    public function setHoldam($holdam)
    {
        $this->holdam = $holdam;

        return $this;
    }

    /**
     * Get holdam
     *
     * @return string 
     */
    public function getHoldam()
    {
        return $this->holdam;
    }

    /**
     * Set holday
     *
     * @param string $holday
     * @return Fechas
     */
    public function setHolday($holday)
    {
        $this->holday = $holday;

        return $this;
    }

    /**
     * Get holday
     *
     * @return string 
     */
    public function getHolday()
    {
        return $this->holday;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }
}
