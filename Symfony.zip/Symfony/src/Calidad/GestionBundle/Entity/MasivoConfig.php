<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MasivoConfig
 *
 * @ORM\Table(name="masivo_config")
 * @ORM\Entity
 */
class MasivoConfig
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="TIPO", type="string", length=255, nullable=true)
     */
    private $tipo;

    /**
     * @var string
     *
     * @ORM\Column(name="CLASIFICACION", type="string", length=255, nullable=true)
     */
    private $clasificacion;

    /**
     * @var string
     *
     * @ORM\Column(name="ASUNTO", type="text", nullable=true)
     */
    private $asunto;

    /**
     * @var string
     *
     * @ORM\Column(name="CAMPO", type="string", length=255, nullable=true)
     */
    private $campo;

    /**
     * @var string
     *
     * @ORM\Column(name="USUARIO", type="string", length=255, nullable=true)
     */
    private $usuario;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_SUBIDA", type="date", nullable=true)
     */
    private $fechaSubida;

    /**
     * @var integer
     *
     * @ORM\Column(name="CANTIDAD", type="integer", nullable=true)
     */
    private $cantidad;

    /**
     * @var string
     *
     * @ORM\Column(name="DESCRIPCION", type="string", length=255, nullable=true)
     */
    private $descripcion;

    /**
     * @var string
     *
     * @ORM\Column(name="ESTATUS", type="string", length=255, nullable=true)
     */
    private $estatus = 'Pendiente';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="ULT_ENVIO", type="date", nullable=true)
     */
    private $ultEnvio;

    /**
     * @var integer
     *
     * @ORM\Column(name="RECORDAR", type="integer", nullable=true)
     */
    private $recordar;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set tipo
     *
     * @param string $tipo
     * @return MasivoConfig
     */
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;

        return $this;
    }

    /**
     * Get tipo
     *
     * @return string 
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * Set clasificacion
     *
     * @param string $clasificacion
     * @return MasivoConfig
     */
    public function setClasificacion($clasificacion)
    {
        $this->clasificacion = $clasificacion;

        return $this;
    }

    /**
     * Get clasificacion
     *
     * @return string 
     */
    public function getClasificacion()
    {
        return $this->clasificacion;
    }

    /**
     * Set asunto
     *
     * @param string $asunto
     * @return MasivoConfig
     */
    public function setAsunto($asunto)
    {
        $this->asunto = $asunto;

        return $this;
    }

    /**
     * Get asunto
     *
     * @return string 
     */
    public function getAsunto()
    {
        return $this->asunto;
    }

    /**
     * Set campo
     *
     * @param string $campo
     * @return MasivoConfig
     */
    public function setCampo($campo)
    {
        $this->campo = $campo;

        return $this;
    }

    /**
     * Get campo
     *
     * @return string 
     */
    public function getCampo()
    {
        return $this->campo;
    }

    /**
     * Set usuario
     *
     * @param string $usuario
     * @return MasivoConfig
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return string 
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * Set fechaSubida
     *
     * @param \DateTime $fechaSubida
     * @return MasivoConfig
     */
    public function setFechaSubida($fechaSubida)
    {
        $this->fechaSubida = $fechaSubida;

        return $this;
    }

    /**
     * Get fechaSubida
     *
     * @return \DateTime 
     */
    public function getFechaSubida()
    {
        return $this->fechaSubida;
    }

    /**
     * Set cantidad
     *
     * @param integer $cantidad
     * @return MasivoConfig
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;

        return $this;
    }

    /**
     * Get cantidad
     *
     * @return integer 
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return MasivoConfig
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set estatus
     *
     * @param string $estatus
     * @return MasivoConfig
     */
    public function setEstatus($estatus)
    {
        $this->estatus = $estatus;

        return $this;
    }

    /**
     * Get estatus
     *
     * @return string 
     */
    public function getEstatus()
    {
        return $this->estatus;
    }

    /**
     * Set ultEnvio
     *
     * @param \DateTime $ultEnvio
     * @return MasivoConfig
     */
    public function setUltEnvio($ultEnvio)
    {
        $this->ultEnvio = $ultEnvio;

        return $this;
    }

    /**
     * Get ultEnvio
     *
     * @return \DateTime 
     */
    public function getUltEnvio()
    {
        return $this->ultEnvio;
    }

    /**
     * Set recordar
     *
     * @param integer $recordar
     * @return MasivoConfig
     */
    public function setRecordar($recordar)
    {
        $this->recordar = $recordar;

        return $this;
    }

    /**
     * Get recordar
     *
     * @return integer 
     */
    public function getRecordar()
    {
        return $this->recordar;
    }
}
