<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Estadisticasreenvio
 *
 * @ORM\Table(name="estadisticasreenvio")
 * @ORM\Entity
 */
class Estadisticasreenvio
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="id_envio", type="integer", nullable=true)
     */
    private $idEnvio;

    /**
     * @var string
     *
     * @ORM\Column(name="oficina", type="string", length=255, nullable=true)
     */
    private $oficina;

    /**
     * @var integer
     *
     * @ORM\Column(name="cantidad", type="integer", nullable=true)
     */
    private $cantidad;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idEnvio
     *
     * @param integer $idEnvio
     * @return Estadisticasreenvio
     */
    public function setIdEnvio($idEnvio)
    {
        $this->idEnvio = $idEnvio;

        return $this;
    }

    /**
     * Get idEnvio
     *
     * @return integer 
     */
    public function getIdEnvio()
    {
        return $this->idEnvio;
    }

    /**
     * Set oficina
     *
     * @param string $oficina
     * @return Estadisticasreenvio
     */
    public function setOficina($oficina)
    {
        $this->oficina = $oficina;

        return $this;
    }

    /**
     * Get oficina
     *
     * @return string 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set cantidad
     *
     * @param integer $cantidad
     * @return Estadisticasreenvio
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;

        return $this;
    }

    /**
     * Get cantidad
     *
     * @return integer 
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }
}
