<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Campos
 *
 * @ORM\Table(name="campos")
 * @ORM\Entity
 */
class Campos
{
    /**
     * @var string
     *
     * @ORM\Column(name="CAMPO", type="string", length=255, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $campo;

    /**
     * @var string
     *
     * @ORM\Column(name="TABLA", type="string", length=255, nullable=true)
     */
    private $tabla;

    /**
     * @var string
     *
     * @ORM\Column(name="DESCRIPCION", type="string", length=255, nullable=true)
     */
    private $descripcion;



    /**
     * Get campo
     *
     * @return string 
     */
    public function getCampo()
    {
        return $this->campo;
    }

    /**
     * Set tabla
     *
     * @param string $tabla
     * @return Campos
     */
    public function setTabla($tabla)
    {
        $this->tabla = $tabla;

        return $this;
    }

    /**
     * Get tabla
     *
     * @return string 
     */
    public function getTabla()
    {
        return $this->tabla;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return Campos
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }
}
