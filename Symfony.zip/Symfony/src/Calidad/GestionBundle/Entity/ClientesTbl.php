<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ClientesTbl
 *
 * @ORM\Table(name="clientes_tbl")
 * @ORM\Entity
 */
class ClientesTbl
{
    /**
     * @var integer
     *
     * @ORM\Column(name="CLIENT", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $client;

    /**
     * @var string
     *
     * @ORM\Column(name="NOMBRE", type="string", length=255, nullable=true)
     */
    private $nombre;

    /**
     * @var integer
     *
     * @ORM\Column(name="IDENTF", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $identf;

    /**
     * @var integer
     *
     * @ORM\Column(name="OFICINA", type="integer", nullable=true)
     */
    private $oficina;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;

    /**
     * @var integer
     *
     * @ORM\Column(name="BANCA", type="integer", nullable=true)
     */
    private $banca;



    /**
     * Set client
     *
     * @param integer $client
     * @return ClientesTbl
     */
    public function setClient($client)
    {
        $this->client = $client;

        return $this;
    }

    /**
     * Get client
     *
     * @return integer 
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return ClientesTbl
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string 
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Set identf
     *
     * @param integer $identf
     * @return ClientesTbl
     */
    public function setIdentf($identf)
    {
        $this->identf = $identf;

        return $this;
    }

    /**
     * Get identf
     *
     * @return integer 
     */
    public function getIdentf()
    {
        return $this->identf;
    }

    /**
     * Set oficina
     *
     * @param integer $oficina
     * @return ClientesTbl
     */
    public function setOficina($oficina)
    {
        $this->oficina = $oficina;

        return $this;
    }

    /**
     * Get oficina
     *
     * @return integer 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return ClientesTbl
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }

    /**
     * Set banca
     *
     * @param integer $banca
     * @return ClientesTbl
     */
    public function setBanca($banca)
    {
        $this->banca = $banca;

        return $this;
    }

    /**
     * Get banca
     *
     * @return integer 
     */
    public function getBanca()
    {
        return $this->banca;
    }
}
