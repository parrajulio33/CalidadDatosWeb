<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Solicitudes2
 *
 * @ORM\Table(name="solicitudes2")
 * @ORM\Entity
 */
class Solicitudes2
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID_SOLICITUD", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $idSolicitud;

    /**
     * @var string
     *
     * @ORM\Column(name="PRIORIDAD", type="string", length=255, nullable=true)
     */
    private $prioridad = 'Urgente';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_ENVIO", type="date", nullable=true)
     */
    private $fechaEnvio;

    /**
     * @var string
     *
     * @ORM\Column(name="TIPO_GESTION", type="string", length=255, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $tipoGestion;

    /**
     * @var string
     *
     * @ORM\Column(name="EST_ENVIO", type="string", length=255, nullable=true)
     */
    private $estEnvio;

    /**
     * @var string
     *
     * @ORM\Column(name="ESTADO", type="string", length=255, nullable=true)
     */
    private $estado = 'ABIERTA';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_CIERRE", type="date", nullable=true)
     */
    private $fechaCierre;

    /**
     * @var string
     *
     * @ORM\Column(name="BANCO", type="string", length=255, nullable=true)
     */
    private $banco;

    /**
     * @var integer
     *
     * @ORM\Column(name="OFICINA", type="integer", nullable=true)
     */
    private $oficina;

    /**
     * @var string
     *
     * @ORM\Column(name="CLIENTE", type="string", length=255, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $cliente;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;

    /**
     * @var string
     *
     * @ORM\Column(name="ALERTA", type="string", length=255, nullable=true)
     */
    private $alerta;

    /**
     * @var string
     *
     * @ORM\Column(name="CUENTA", type="string", length=255, nullable=true)
     */
    private $cuenta;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_APERTURA", type="date", nullable=true)
     */
    private $fechaApertura;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_RECEPCION", type="date", nullable=true)
     */
    private $fechaRecepcion;

    /**
     * @var string
     *
     * @ORM\Column(name="USUARIO_ENCARGADO", type="string", length=255, nullable=true)
     */
    private $usuarioEncargado;

    /**
     * @var string
     *
     * @ORM\Column(name="BANCA", type="string", length=255, nullable=true)
     */
    private $banca;

    /**
     * @var string
     *
     * @ORM\Column(name="CAMPOS", type="string", length=255, nullable=true)
     */
    private $campos;

    /**
     * @var string
     *
     * @ORM\Column(name="COMENTARIO", type="string", length=255, nullable=true)
     */
    private $comentario;

    /**
     * @var string
     *
     * @ORM\Column(name="TIPO_CLIENTE", type="string", length=255, nullable=true)
     */
    private $tipoCliente;

    /**
     * @var string
     *
     * @ORM\Column(name="NOMBRE_CLIENTE", type="string", length=255, nullable=true)
     */
    private $nombreCliente;

    /**
     * @var string
     *
     * @ORM\Column(name="IDENTIFICACION", type="string", length=255, nullable=true)
     */
    private $identificacion;

    /**
     * @var string
     *
     * @ORM\Column(name="DESCRIPCION", type="string", length=255, nullable=true)
     */
    private $descripcion;



    /**
     * Set idSolicitud
     *
     * @param integer $idSolicitud
     * @return Solicitudes2
     */
    public function setIdSolicitud($idSolicitud)
    {
        $this->idSolicitud = $idSolicitud;

        return $this;
    }

    /**
     * Get idSolicitud
     *
     * @return integer 
     */
    public function getIdSolicitud()
    {
        return $this->idSolicitud;
    }

    /**
     * Set prioridad
     *
     * @param string $prioridad
     * @return Solicitudes2
     */
    public function setPrioridad($prioridad)
    {
        $this->prioridad = $prioridad;

        return $this;
    }

    /**
     * Get prioridad
     *
     * @return string 
     */
    public function getPrioridad()
    {
        return $this->prioridad;
    }

    /**
     * Set fechaEnvio
     *
     * @param \DateTime $fechaEnvio
     * @return Solicitudes2
     */
    public function setFechaEnvio($fechaEnvio)
    {
        $this->fechaEnvio = $fechaEnvio;

        return $this;
    }

    /**
     * Get fechaEnvio
     *
     * @return \DateTime 
     */
    public function getFechaEnvio()
    {
        return $this->fechaEnvio;
    }

    /**
     * Set tipoGestion
     *
     * @param string $tipoGestion
     * @return Solicitudes2
     */
    public function setTipoGestion($tipoGestion)
    {
        $this->tipoGestion = $tipoGestion;

        return $this;
    }

    /**
     * Get tipoGestion
     *
     * @return string 
     */
    public function getTipoGestion()
    {
        return $this->tipoGestion;
    }

    /**
     * Set estEnvio
     *
     * @param string $estEnvio
     * @return Solicitudes2
     */
    public function setEstEnvio($estEnvio)
    {
        $this->estEnvio = $estEnvio;

        return $this;
    }

    /**
     * Get estEnvio
     *
     * @return string 
     */
    public function getEstEnvio()
    {
        return $this->estEnvio;
    }

    /**
     * Set estado
     *
     * @param string $estado
     * @return Solicitudes2
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;

        return $this;
    }

    /**
     * Get estado
     *
     * @return string 
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * Set fechaCierre
     *
     * @param \DateTime $fechaCierre
     * @return Solicitudes2
     */
    public function setFechaCierre($fechaCierre)
    {
        $this->fechaCierre = $fechaCierre;

        return $this;
    }

    /**
     * Get fechaCierre
     *
     * @return \DateTime 
     */
    public function getFechaCierre()
    {
        return $this->fechaCierre;
    }

    /**
     * Set banco
     *
     * @param string $banco
     * @return Solicitudes2
     */
    public function setBanco($banco)
    {
        $this->banco = $banco;

        return $this;
    }

    /**
     * Get banco
     *
     * @return string 
     */
    public function getBanco()
    {
        return $this->banco;
    }

    /**
     * Set oficina
     *
     * @param integer $oficina
     * @return Solicitudes2
     */
    public function setOficina($oficina)
    {
        $this->oficina = $oficina;

        return $this;
    }

    /**
     * Get oficina
     *
     * @return integer 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set cliente
     *
     * @param string $cliente
     * @return Solicitudes2
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;

        return $this;
    }

    /**
     * Get cliente
     *
     * @return string 
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return Solicitudes2
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }

    /**
     * Set alerta
     *
     * @param string $alerta
     * @return Solicitudes2
     */
    public function setAlerta($alerta)
    {
        $this->alerta = $alerta;

        return $this;
    }

    /**
     * Get alerta
     *
     * @return string 
     */
    public function getAlerta()
    {
        return $this->alerta;
    }

    /**
     * Set cuenta
     *
     * @param string $cuenta
     * @return Solicitudes2
     */
    public function setCuenta($cuenta)
    {
        $this->cuenta = $cuenta;

        return $this;
    }

    /**
     * Get cuenta
     *
     * @return string 
     */
    public function getCuenta()
    {
        return $this->cuenta;
    }

    /**
     * Set fechaApertura
     *
     * @param \DateTime $fechaApertura
     * @return Solicitudes2
     */
    public function setFechaApertura($fechaApertura)
    {
        $this->fechaApertura = $fechaApertura;

        return $this;
    }

    /**
     * Get fechaApertura
     *
     * @return \DateTime 
     */
    public function getFechaApertura()
    {
        return $this->fechaApertura;
    }

    /**
     * Set fechaRecepcion
     *
     * @param \DateTime $fechaRecepcion
     * @return Solicitudes2
     */
    public function setFechaRecepcion($fechaRecepcion)
    {
        $this->fechaRecepcion = $fechaRecepcion;

        return $this;
    }

    /**
     * Get fechaRecepcion
     *
     * @return \DateTime 
     */
    public function getFechaRecepcion()
    {
        return $this->fechaRecepcion;
    }

    /**
     * Set usuarioEncargado
     *
     * @param string $usuarioEncargado
     * @return Solicitudes2
     */
    public function setUsuarioEncargado($usuarioEncargado)
    {
        $this->usuarioEncargado = $usuarioEncargado;

        return $this;
    }

    /**
     * Get usuarioEncargado
     *
     * @return string 
     */
    public function getUsuarioEncargado()
    {
        return $this->usuarioEncargado;
    }

    /**
     * Set banca
     *
     * @param string $banca
     * @return Solicitudes2
     */
    public function setBanca($banca)
    {
        $this->banca = $banca;

        return $this;
    }

    /**
     * Get banca
     *
     * @return string 
     */
    public function getBanca()
    {
        return $this->banca;
    }

    /**
     * Set campos
     *
     * @param string $campos
     * @return Solicitudes2
     */
    public function setCampos($campos)
    {
        $this->campos = $campos;

        return $this;
    }

    /**
     * Get campos
     *
     * @return string 
     */
    public function getCampos()
    {
        return $this->campos;
    }

    /**
     * Set comentario
     *
     * @param string $comentario
     * @return Solicitudes2
     */
    public function setComentario($comentario)
    {
        $this->comentario = $comentario;

        return $this;
    }

    /**
     * Get comentario
     *
     * @return string 
     */
    public function getComentario()
    {
        return $this->comentario;
    }

    /**
     * Set tipoCliente
     *
     * @param string $tipoCliente
     * @return Solicitudes2
     */
    public function setTipoCliente($tipoCliente)
    {
        $this->tipoCliente = $tipoCliente;

        return $this;
    }

    /**
     * Get tipoCliente
     *
     * @return string 
     */
    public function getTipoCliente()
    {
        return $this->tipoCliente;
    }

    /**
     * Set nombreCliente
     *
     * @param string $nombreCliente
     * @return Solicitudes2
     */
    public function setNombreCliente($nombreCliente)
    {
        $this->nombreCliente = $nombreCliente;

        return $this;
    }

    /**
     * Get nombreCliente
     *
     * @return string 
     */
    public function getNombreCliente()
    {
        return $this->nombreCliente;
    }

    /**
     * Set identificacion
     *
     * @param string $identificacion
     * @return Solicitudes2
     */
    public function setIdentificacion($identificacion)
    {
        $this->identificacion = $identificacion;

        return $this;
    }

    /**
     * Get identificacion
     *
     * @return string 
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return Solicitudes2
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }
}
