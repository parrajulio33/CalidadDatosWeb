<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Remediaciones
 *
 * @ORM\Table(name="remediaciones")
 * @ORM\Entity
 */
class Remediaciones
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="descripcion", type="string", length=255, nullable=true)
     */
    private $descripcion;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="fecha", type="date", nullable=true)
     */
    private $fecha;

    /**
     * @var string
     *
     * @ORM\Column(name="aplicativo", type="string", length=255, nullable=true)
     */
    private $aplicativo;

    /**
     * @var string
     *
     * @ORM\Column(name="usuario", type="string", length=255, nullable=true)
     */
    private $usuario;

    /**
     * @var integer
     *
     * @ORM\Column(name="campos", type="integer", nullable=true)
     */
    private $campos;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return Remediaciones
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set fecha
     *
     * @param \DateTime $fecha
     * @return Remediaciones
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \DateTime 
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set aplicativo
     *
     * @param string $aplicativo
     * @return Remediaciones
     */
    public function setAplicativo($aplicativo)
    {
        $this->aplicativo = $aplicativo;

        return $this;
    }

    /**
     * Get aplicativo
     *
     * @return string 
     */
    public function getAplicativo()
    {
        return $this->aplicativo;
    }

    /**
     * Set usuario
     *
     * @param string $usuario
     * @return Remediaciones
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return string 
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * Set campos
     *
     * @param integer $campos
     * @return Remediaciones
     */
    public function setCampos($campos)
    {
        $this->campos = $campos;

        return $this;
    }

    /**
     * Get campos
     *
     * @return integer 
     */
    public function getCampos()
    {
        return $this->campos;
    }
}
