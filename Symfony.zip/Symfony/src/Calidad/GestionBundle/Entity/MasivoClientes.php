<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MasivoClientes
 *
 * @ORM\Table(name="masivo_clientes")
 * @ORM\Entity
 */
class MasivoClientes
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="ID_CONFIG", type="integer", nullable=true)
     */
    private $idConfig;

    /**
     * @var integer
     *
     * @ORM\Column(name="CLIENTE", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $cliente;

    /**
     * @var string
     *
     * @ORM\Column(name="NOMBRE", type="string", length=255, nullable=true)
     */
    private $nombre;

    /**
     * @var integer
     *
     * @ORM\Column(name="IDENTIFICACION", type="integer", nullable=true)
     */
    private $identificacion;

    /**
     * @var string
     *
     * @ORM\Column(name="CAMPO", type="string", length=255, nullable=true)
     */
    private $campo;

    /**
     * @var integer
     *
     * @ORM\Column(name="OFICINA", type="integer", nullable=true)
     */
    private $oficina;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;



    /**
     * Set id
     *
     * @param integer $id
     * @return MasivoClientes
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idConfig
     *
     * @param integer $idConfig
     * @return MasivoClientes
     */
    public function setIdConfig($idConfig)
    {
        $this->idConfig = $idConfig;

        return $this;
    }

    /**
     * Get idConfig
     *
     * @return integer 
     */
    public function getIdConfig()
    {
        return $this->idConfig;
    }

    /**
     * Set cliente
     *
     * @param integer $cliente
     * @return MasivoClientes
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;

        return $this;
    }

    /**
     * Get cliente
     *
     * @return integer 
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return MasivoClientes
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string 
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Set identificacion
     *
     * @param integer $identificacion
     * @return MasivoClientes
     */
    public function setIdentificacion($identificacion)
    {
        $this->identificacion = $identificacion;

        return $this;
    }

    /**
     * Get identificacion
     *
     * @return integer 
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }

    /**
     * Set campo
     *
     * @param string $campo
     * @return MasivoClientes
     */
    public function setCampo($campo)
    {
        $this->campo = $campo;

        return $this;
    }

    /**
     * Get campo
     *
     * @return string 
     */
    public function getCampo()
    {
        return $this->campo;
    }

    /**
     * Set oficina
     *
     * @param integer $oficina
     * @return MasivoClientes
     */
    public function setOficina($oficina)
    {
        $this->oficina = $oficina;

        return $this;
    }

    /**
     * Get oficina
     *
     * @return integer 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return MasivoClientes
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }
}
