<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Direccion
 *
 * @ORM\Table(name="direccion")
 * @ORM\Entity
 */
class Direccion
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="ZONA_POSTAL", type="string", length=255, nullable=true)
     */
    private $zonaPostal;

    /**
     * @var string
     *
     * @ORM\Column(name="COD_AREA", type="string", length=255, nullable=true)
     */
    private $codArea;

    /**
     * @var string
     *
     * @ORM\Column(name="SECTOR", type="string", length=255, nullable=true)
     */
    private $sector;

    /**
     * @var string
     *
     * @ORM\Column(name="PARROQUIA", type="string", length=255, nullable=true)
     */
    private $parroquia;

    /**
     * @var string
     *
     * @ORM\Column(name="MUNICIPIO", type="string", length=255, nullable=true)
     */
    private $municipio;

    /**
     * @var string
     *
     * @ORM\Column(name="CIUDAD", type="string", length=255, nullable=true)
     */
    private $ciudad;

    /**
     * @var string
     *
     * @ORM\Column(name="ESTADO", type="string", length=255, nullable=true)
     */
    private $estado;

    /**
     * @var string
     *
     * @ORM\Column(name="COD_PARROQUIA", type="string", length=255, nullable=true)
     */
    private $codParroquia;

    /**
     * @var string
     *
     * @ORM\Column(name="COD_MUNICIPIO", type="string", length=255, nullable=true)
     */
    private $codMunicipio;

    /**
     * @var string
     *
     * @ORM\Column(name="COD_CIUDAD", type="string", length=255, nullable=true)
     */
    private $codCiudad;

    /**
     * @var string
     *
     * @ORM\Column(name="COD_ESTADO", type="string", length=255, nullable=true)
     */
    private $codEstado;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set zonaPostal
     *
     * @param string $zonaPostal
     * @return Direccion
     */
    public function setZonaPostal($zonaPostal)
    {
        $this->zonaPostal = $zonaPostal;

        return $this;
    }

    /**
     * Get zonaPostal
     *
     * @return string 
     */
    public function getZonaPostal()
    {
        return $this->zonaPostal;
    }

    /**
     * Set codArea
     *
     * @param string $codArea
     * @return Direccion
     */
    public function setCodArea($codArea)
    {
        $this->codArea = $codArea;

        return $this;
    }

    /**
     * Get codArea
     *
     * @return string 
     */
    public function getCodArea()
    {
        return $this->codArea;
    }

    /**
     * Set sector
     *
     * @param string $sector
     * @return Direccion
     */
    public function setSector($sector)
    {
        $this->sector = $sector;

        return $this;
    }

    /**
     * Get sector
     *
     * @return string 
     */
    public function getSector()
    {
        return $this->sector;
    }

    /**
     * Set parroquia
     *
     * @param string $parroquia
     * @return Direccion
     */
    public function setParroquia($parroquia)
    {
        $this->parroquia = $parroquia;

        return $this;
    }

    /**
     * Get parroquia
     *
     * @return string 
     */
    public function getParroquia()
    {
        return $this->parroquia;
    }

    /**
     * Set municipio
     *
     * @param string $municipio
     * @return Direccion
     */
    public function setMunicipio($municipio)
    {
        $this->municipio = $municipio;

        return $this;
    }

    /**
     * Get municipio
     *
     * @return string 
     */
    public function getMunicipio()
    {
        return $this->municipio;
    }

    /**
     * Set ciudad
     *
     * @param string $ciudad
     * @return Direccion
     */
    public function setCiudad($ciudad)
    {
        $this->ciudad = $ciudad;

        return $this;
    }

    /**
     * Get ciudad
     *
     * @return string 
     */
    public function getCiudad()
    {
        return $this->ciudad;
    }

    /**
     * Set estado
     *
     * @param string $estado
     * @return Direccion
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;

        return $this;
    }

    /**
     * Get estado
     *
     * @return string 
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * Set codParroquia
     *
     * @param string $codParroquia
     * @return Direccion
     */
    public function setCodParroquia($codParroquia)
    {
        $this->codParroquia = $codParroquia;

        return $this;
    }

    /**
     * Get codParroquia
     *
     * @return string 
     */
    public function getCodParroquia()
    {
        return $this->codParroquia;
    }

    /**
     * Set codMunicipio
     *
     * @param string $codMunicipio
     * @return Direccion
     */
    public function setCodMunicipio($codMunicipio)
    {
        $this->codMunicipio = $codMunicipio;

        return $this;
    }

    /**
     * Get codMunicipio
     *
     * @return string 
     */
    public function getCodMunicipio()
    {
        return $this->codMunicipio;
    }

    /**
     * Set codCiudad
     *
     * @param string $codCiudad
     * @return Direccion
     */
    public function setCodCiudad($codCiudad)
    {
        $this->codCiudad = $codCiudad;

        return $this;
    }

    /**
     * Get codCiudad
     *
     * @return string 
     */
    public function getCodCiudad()
    {
        return $this->codCiudad;
    }

    /**
     * Set codEstado
     *
     * @param string $codEstado
     * @return Direccion
     */
    public function setCodEstado($codEstado)
    {
        $this->codEstado = $codEstado;

        return $this;
    }

    /**
     * Get codEstado
     *
     * @return string 
     */
    public function getCodEstado()
    {
        return $this->codEstado;
    }
}
