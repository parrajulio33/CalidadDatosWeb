<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ChequeDevuelto
 *
 * @ORM\Table(name="cheque_devuelto")
 * @ORM\Entity
 */
class ChequeDevuelto
{
    /**
     * @var string
     *
     * @ORM\Column(name="BANCO", type="string", length=255, nullable=true)
     */
    private $banco;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA", type="date", nullable=true)
     */
    private $fecha;

    /**
     * @var string
     *
     * @ORM\Column(name="BANCA", type="string", length=255, nullable=true)
     */
    private $banca;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;

    /**
     * @var string
     *
     * @ORM\Column(name="NomEjecutivo", type="string", length=255, nullable=true)
     */
    private $nomejecutivo;

    /**
     * @var integer
     *
     * @ORM\Column(name="PropAgencia", type="integer", nullable=true)
     */
    private $propagencia;

    /**
     * @var string
     *
     * @ORM\Column(name="ClienteEsp", type="string", length=255, nullable=true)
     */
    private $clienteesp;

    /**
     * @var string
     *
     * @ORM\Column(name="NoCliente", type="string", length=255, nullable=true)
     */
    private $nocliente;

    /**
     * @var string
     *
     * @ORM\Column(name="TipoPer", type="string", length=255, nullable=true)
     */
    private $tipoper;

    /**
     * @var string
     *
     * @ORM\Column(name="Identifiacion", type="string", length=255, nullable=true)
     */
    private $identifiacion;

    /**
     * @var string
     *
     * @ORM\Column(name="NomCliente", type="string", length=255, nullable=true)
     */
    private $nomcliente;

    /**
     * @var string
     *
     * @ORM\Column(name="Telefono1", type="string", length=255, nullable=true)
     */
    private $telefono1;

    /**
     * @var string
     *
     * @ORM\Column(name="Telefono2", type="string", length=255, nullable=true)
     */
    private $telefono2;

    /**
     * @var string
     *
     * @ORM\Column(name="Telefono3", type="string", length=255, nullable=true)
     */
    private $telefono3;

    /**
     * @var string
     *
     * @ORM\Column(name="Email", type="string", length=255, nullable=true)
     */
    private $email;

    /**
     * @var integer
     *
     * @ORM\Column(name="NoRegistro", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $noregistro;

    /**
     * @var integer
     *
     * @ORM\Column(name="Estado_envio", type="integer", nullable=true)
     */
    private $estadoEnvio = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="Error_local", type="integer", nullable=true)
     */
    private $errorLocal = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="Error_celular", type="integer", nullable=true)
     */
    private $errorCelular = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="Error_email", type="integer", nullable=true)
     */
    private $errorEmail = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="Archivo", type="integer", nullable=true)
     */
    private $archivo;

    /**
     * @var integer
     *
     * @ORM\Column(name="Error_contacto", type="integer", nullable=true)
     */
    private $errorContacto = '0';



    /**
     * Set banco
     *
     * @param string $banco
     * @return ChequeDevuelto
     */
    public function setBanco($banco)
    {
        $this->banco = $banco;

        return $this;
    }

    /**
     * Get banco
     *
     * @return string 
     */
    public function getBanco()
    {
        return $this->banco;
    }

    /**
     * Set fecha
     *
     * @param \DateTime $fecha
     * @return ChequeDevuelto
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \DateTime 
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set banca
     *
     * @param string $banca
     * @return ChequeDevuelto
     */
    public function setBanca($banca)
    {
        $this->banca = $banca;

        return $this;
    }

    /**
     * Get banca
     *
     * @return string 
     */
    public function getBanca()
    {
        return $this->banca;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return ChequeDevuelto
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }

    /**
     * Set nomejecutivo
     *
     * @param string $nomejecutivo
     * @return ChequeDevuelto
     */
    public function setNomejecutivo($nomejecutivo)
    {
        $this->nomejecutivo = $nomejecutivo;

        return $this;
    }

    /**
     * Get nomejecutivo
     *
     * @return string 
     */
    public function getNomejecutivo()
    {
        return $this->nomejecutivo;
    }

    /**
     * Set propagencia
     *
     * @param integer $propagencia
     * @return ChequeDevuelto
     */
    public function setPropagencia($propagencia)
    {
        $this->propagencia = $propagencia;

        return $this;
    }

    /**
     * Get propagencia
     *
     * @return integer 
     */
    public function getPropagencia()
    {
        return $this->propagencia;
    }

    /**
     * Set clienteesp
     *
     * @param string $clienteesp
     * @return ChequeDevuelto
     */
    public function setClienteesp($clienteesp)
    {
        $this->clienteesp = $clienteesp;

        return $this;
    }

    /**
     * Get clienteesp
     *
     * @return string 
     */
    public function getClienteesp()
    {
        return $this->clienteesp;
    }

    /**
     * Set nocliente
     *
     * @param string $nocliente
     * @return ChequeDevuelto
     */
    public function setNocliente($nocliente)
    {
        $this->nocliente = $nocliente;

        return $this;
    }

    /**
     * Get nocliente
     *
     * @return string 
     */
    public function getNocliente()
    {
        return $this->nocliente;
    }

    /**
     * Set tipoper
     *
     * @param string $tipoper
     * @return ChequeDevuelto
     */
    public function setTipoper($tipoper)
    {
        $this->tipoper = $tipoper;

        return $this;
    }

    /**
     * Get tipoper
     *
     * @return string 
     */
    public function getTipoper()
    {
        return $this->tipoper;
    }

    /**
     * Set identifiacion
     *
     * @param string $identifiacion
     * @return ChequeDevuelto
     */
    public function setIdentifiacion($identifiacion)
    {
        $this->identifiacion = $identifiacion;

        return $this;
    }

    /**
     * Get identifiacion
     *
     * @return string 
     */
    public function getIdentifiacion()
    {
        return $this->identifiacion;
    }

    /**
     * Set nomcliente
     *
     * @param string $nomcliente
     * @return ChequeDevuelto
     */
    public function setNomcliente($nomcliente)
    {
        $this->nomcliente = $nomcliente;

        return $this;
    }

    /**
     * Get nomcliente
     *
     * @return string 
     */
    public function getNomcliente()
    {
        return $this->nomcliente;
    }

    /**
     * Set telefono1
     *
     * @param string $telefono1
     * @return ChequeDevuelto
     */
    public function setTelefono1($telefono1)
    {
        $this->telefono1 = $telefono1;

        return $this;
    }

    /**
     * Get telefono1
     *
     * @return string 
     */
    public function getTelefono1()
    {
        return $this->telefono1;
    }

    /**
     * Set telefono2
     *
     * @param string $telefono2
     * @return ChequeDevuelto
     */
    public function setTelefono2($telefono2)
    {
        $this->telefono2 = $telefono2;

        return $this;
    }

    /**
     * Get telefono2
     *
     * @return string 
     */
    public function getTelefono2()
    {
        return $this->telefono2;
    }

    /**
     * Set telefono3
     *
     * @param string $telefono3
     * @return ChequeDevuelto
     */
    public function setTelefono3($telefono3)
    {
        $this->telefono3 = $telefono3;

        return $this;
    }

    /**
     * Get telefono3
     *
     * @return string 
     */
    public function getTelefono3()
    {
        return $this->telefono3;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return ChequeDevuelto
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Get noregistro
     *
     * @return integer 
     */
    public function getNoregistro()
    {
        return $this->noregistro;
    }

    /**
     * Set estadoEnvio
     *
     * @param integer $estadoEnvio
     * @return ChequeDevuelto
     */
    public function setEstadoEnvio($estadoEnvio)
    {
        $this->estadoEnvio = $estadoEnvio;

        return $this;
    }

    /**
     * Get estadoEnvio
     *
     * @return integer 
     */
    public function getEstadoEnvio()
    {
        return $this->estadoEnvio;
    }

    /**
     * Set errorLocal
     *
     * @param integer $errorLocal
     * @return ChequeDevuelto
     */
    public function setErrorLocal($errorLocal)
    {
        $this->errorLocal = $errorLocal;

        return $this;
    }

    /**
     * Get errorLocal
     *
     * @return integer 
     */
    public function getErrorLocal()
    {
        return $this->errorLocal;
    }

    /**
     * Set errorCelular
     *
     * @param integer $errorCelular
     * @return ChequeDevuelto
     */
    public function setErrorCelular($errorCelular)
    {
        $this->errorCelular = $errorCelular;

        return $this;
    }

    /**
     * Get errorCelular
     *
     * @return integer 
     */
    public function getErrorCelular()
    {
        return $this->errorCelular;
    }

    /**
     * Set errorEmail
     *
     * @param integer $errorEmail
     * @return ChequeDevuelto
     */
    public function setErrorEmail($errorEmail)
    {
        $this->errorEmail = $errorEmail;

        return $this;
    }

    /**
     * Get errorEmail
     *
     * @return integer 
     */
    public function getErrorEmail()
    {
        return $this->errorEmail;
    }

    /**
     * Set archivo
     *
     * @param integer $archivo
     * @return ChequeDevuelto
     */
    public function setArchivo($archivo)
    {
        $this->archivo = $archivo;

        return $this;
    }

    /**
     * Get archivo
     *
     * @return integer 
     */
    public function getArchivo()
    {
        return $this->archivo;
    }

    /**
     * Set errorContacto
     *
     * @param integer $errorContacto
     * @return ChequeDevuelto
     */
    public function setErrorContacto($errorContacto)
    {
        $this->errorContacto = $errorContacto;

        return $this;
    }

    /**
     * Get errorContacto
     *
     * @return integer 
     */
    public function getErrorContacto()
    {
        return $this->errorContacto;
    }
}
