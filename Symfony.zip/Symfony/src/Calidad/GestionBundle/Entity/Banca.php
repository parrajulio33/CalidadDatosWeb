<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Banca
 *
 * @ORM\Table(name="banca")
 * @ORM\Entity
 */
class Banca
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="cod_banca", type="string", length=255, nullable=true)
     */
    private $codBanca;

    /**
     * @var string
     *
     * @ORM\Column(name="Opcion", type="string", length=255, nullable=true)
     */
    private $opcion;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set codBanca
     *
     * @param string $codBanca
     * @return Banca
     */
    public function setCodBanca($codBanca)
    {
        $this->codBanca = $codBanca;

        return $this;
    }

    /**
     * Get codBanca
     *
     * @return string 
     */
    public function getCodBanca()
    {
        return $this->codBanca;
    }

    /**
     * Set opcion
     *
     * @param string $opcion
     * @return Banca
     */
    public function setOpcion($opcion)
    {
        $this->opcion = $opcion;

        return $this;
    }

    /**
     * Get opcion
     *
     * @return string 
     */
    public function getOpcion()
    {
        return $this->opcion;
    }
}
