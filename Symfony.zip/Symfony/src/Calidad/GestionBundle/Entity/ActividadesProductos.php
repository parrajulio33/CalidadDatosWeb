<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ActividadesProductos
 *
 * @ORM\Table(name="actividades_productos", indexes={@ORM\Index(name="USS", columns={"USUARIO"})})
 * @ORM\Entity
 */
class ActividadesProductos
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ID", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="DESCRIPCION", type="string", length=255, nullable=true)
     */
    private $descripcion;

    /**
     * @var string
     *
     * @ORM\Column(name="TIPO", type="string", length=50, nullable=true)
     */
    private $tipo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_INICIO", type="date", nullable=true)
     */
    private $fechaInicio;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_FIN", type="date", nullable=true)
     */
    private $fechaFin;

    /**
     * @var string
     *
     * @ORM\Column(name="ESTADO", type="string", length=50, nullable=true)
     */
    private $estado;

    /**
     * @var string
     *
     * @ORM\Column(name="APLICATIVO", type="string", length=50, nullable=true)
     */
    private $aplicativo;

    /**
     * @var string
     *
     * @ORM\Column(name="DETALLES", type="text", nullable=true)
     */
    private $detalles;

    /**
     * @var integer
     *
     * @ORM\Column(name="PRIORIDAD", type="integer", nullable=true)
     */
    private $prioridad;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA_CIERRE", type="date", nullable=true)
     */
    private $fechaCierre;

    /**
     * @var \Usuario
     *
     * @ORM\ManyToOne(targetEntity="Usuario")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="USUARIO", referencedColumnName="user")
     * })
     */
    private $usuario;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return ActividadesProductos
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set tipo
     *
     * @param string $tipo
     * @return ActividadesProductos
     */
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;

        return $this;
    }

    /**
     * Get tipo
     *
     * @return string 
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * Set fechaInicio
     *
     * @param \DateTime $fechaInicio
     * @return ActividadesProductos
     */
    public function setFechaInicio($fechaInicio)
    {
        $this->fechaInicio = $fechaInicio;

        return $this;
    }

    /**
     * Get fechaInicio
     *
     * @return \DateTime 
     */
    public function getFechaInicio()
    {
        return $this->fechaInicio;
    }

    /**
     * Set fechaFin
     *
     * @param \DateTime $fechaFin
     * @return ActividadesProductos
     */
    public function setFechaFin($fechaFin)
    {
        $this->fechaFin = $fechaFin;

        return $this;
    }

    /**
     * Get fechaFin
     *
     * @return \DateTime 
     */
    public function getFechaFin()
    {
        return $this->fechaFin;
    }

    /**
     * Set estado
     *
     * @param string $estado
     * @return ActividadesProductos
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;

        return $this;
    }

    /**
     * Get estado
     *
     * @return string 
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * Set aplicativo
     *
     * @param string $aplicativo
     * @return ActividadesProductos
     */
    public function setAplicativo($aplicativo)
    {
        $this->aplicativo = $aplicativo;

        return $this;
    }

    /**
     * Get aplicativo
     *
     * @return string 
     */
    public function getAplicativo()
    {
        return $this->aplicativo;
    }

    /**
     * Set detalles
     *
     * @param string $detalles
     * @return ActividadesProductos
     */
    public function setDetalles($detalles)
    {
        $this->detalles = $detalles;

        return $this;
    }

    /**
     * Get detalles
     *
     * @return string 
     */
    public function getDetalles()
    {
        return $this->detalles;
    }

    /**
     * Set prioridad
     *
     * @param integer $prioridad
     * @return ActividadesProductos
     */
    public function setPrioridad($prioridad)
    {
        $this->prioridad = $prioridad;

        return $this;
    }

    /**
     * Get prioridad
     *
     * @return integer 
     */
    public function getPrioridad()
    {
        return $this->prioridad;
    }

    /**
     * Set fechaCierre
     *
     * @param \DateTime $fechaCierre
     * @return ActividadesProductos
     */
    public function setFechaCierre($fechaCierre)
    {
        $this->fechaCierre = $fechaCierre;

        return $this;
    }

    /**
     * Get fechaCierre
     *
     * @return \DateTime 
     */
    public function getFechaCierre()
    {
        return $this->fechaCierre;
    }

    /**
     * Set usuario
     *
     * @param \Calidad\GestionBundle\Entity\Usuario $usuario
     * @return ActividadesProductos
     */
    public function setUsuario(\Calidad\GestionBundle\Entity\Usuario $usuario = null)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return \Calidad\GestionBundle\Entity\Usuario 
     */
    public function getUsuario()
    {
        return $this->usuario;
    }
}
