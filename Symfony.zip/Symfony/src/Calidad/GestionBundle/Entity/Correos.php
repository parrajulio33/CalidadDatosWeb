<?php

namespace Calidad\GestionBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Correos
 *
 * @ORM\Table(name="correos")
 * @ORM\Entity
 */
class Correos
{
    /**
     * @var integer
     *
     * @ORM\Column(name="REG", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $reg;

    /**
     * @var string
     *
     * @ORM\Column(name="RTYP", type="string", length=255, nullable=true)
     */
    private $rtyp;

    /**
     * @var string
     *
     * @ORM\Column(name="GESTION", type="string", length=255, nullable=true)
     */
    private $gestion;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="FECHA", type="date", nullable=true)
     */
    private $fecha;

    /**
     * @var string
     *
     * @ORM\Column(name="PRIORIDAD", type="string", length=255, nullable=true)
     */
    private $prioridad;

    /**
     * @var string
     *
     * @ORM\Column(name="DESCRIPCION", type="string", length=255, nullable=true)
     */
    private $descripcion;

    /**
     * @var string
     *
     * @ORM\Column(name="COPIA", type="string", length=255, nullable=true)
     */
    private $copia;

    /**
     * @var string
     *
     * @ORM\Column(name="ASUNTO", type="string", length=255, nullable=true)
     */
    private $asunto;

    /**
     * @var string
     *
     * @ORM\Column(name="CLIENTE", type="string", length=255, nullable=true)
     */
    private $cliente;

    /**
     * @var string
     *
     * @ORM\Column(name="NOMBRE", type="string", length=255, nullable=true)
     */
    private $nombre;

    /**
     * @var string
     *
     * @ORM\Column(name="IDENTIFICACION", type="string", length=255, nullable=true)
     */
    private $identificacion;

    /**
     * @var integer
     *
     * @ORM\Column(name="OFICINA", type="integer", nullable=true)
     */
    private $oficina;

    /**
     * @var string
     *
     * @ORM\Column(name="EJECUTIVO", type="string", length=255, nullable=true)
     */
    private $ejecutivo;

    /**
     * @var string
     *
     * @ORM\Column(name="CAMPO", type="string", length=255, nullable=true)
     */
    private $campo;

    /**
     * @var integer
     *
     * @ORM\Column(name="ID_ENV", type="integer", nullable=true)
     */
    private $idEnv;

    /**
     * @var string
     *
     * @ORM\Column(name="USUARIO", type="string", length=255, nullable=true)
     */
    private $usuario;

    /**
     * @var integer
     *
     * @ORM\Column(name="ENVIADO", type="integer", nullable=true)
     */
    private $enviado;



    /**
     * Get reg
     *
     * @return integer 
     */
    public function getReg()
    {
        return $this->reg;
    }

    /**
     * Set rtyp
     *
     * @param string $rtyp
     * @return Correos
     */
    public function setRtyp($rtyp)
    {
        $this->rtyp = $rtyp;

        return $this;
    }

    /**
     * Get rtyp
     *
     * @return string 
     */
    public function getRtyp()
    {
        return $this->rtyp;
    }

    /**
     * Set gestion
     *
     * @param string $gestion
     * @return Correos
     */
    public function setGestion($gestion)
    {
        $this->gestion = $gestion;

        return $this;
    }

    /**
     * Get gestion
     *
     * @return string 
     */
    public function getGestion()
    {
        return $this->gestion;
    }

    /**
     * Set fecha
     *
     * @param \DateTime $fecha
     * @return Correos
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \DateTime 
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set prioridad
     *
     * @param string $prioridad
     * @return Correos
     */
    public function setPrioridad($prioridad)
    {
        $this->prioridad = $prioridad;

        return $this;
    }

    /**
     * Get prioridad
     *
     * @return string 
     */
    public function getPrioridad()
    {
        return $this->prioridad;
    }

    /**
     * Set descripcion
     *
     * @param string $descripcion
     * @return Correos
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get descripcion
     *
     * @return string 
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set copia
     *
     * @param string $copia
     * @return Correos
     */
    public function setCopia($copia)
    {
        $this->copia = $copia;

        return $this;
    }

    /**
     * Get copia
     *
     * @return string 
     */
    public function getCopia()
    {
        return $this->copia;
    }

    /**
     * Set asunto
     *
     * @param string $asunto
     * @return Correos
     */
    public function setAsunto($asunto)
    {
        $this->asunto = $asunto;

        return $this;
    }

    /**
     * Get asunto
     *
     * @return string 
     */
    public function getAsunto()
    {
        return $this->asunto;
    }

    /**
     * Set cliente
     *
     * @param string $cliente
     * @return Correos
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;

        return $this;
    }

    /**
     * Get cliente
     *
     * @return string 
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * Set nombre
     *
     * @param string $nombre
     * @return Correos
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }

    /**
     * Get nombre
     *
     * @return string 
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Set identificacion
     *
     * @param string $identificacion
     * @return Correos
     */
    public function setIdentificacion($identificacion)
    {
        $this->identificacion = $identificacion;

        return $this;
    }

    /**
     * Get identificacion
     *
     * @return string 
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }

    /**
     * Set oficina
     *
     * @param integer $oficina
     * @return Correos
     */
    public function setOficina($oficina)
    {
        $this->oficina = $oficina;

        return $this;
    }

    /**
     * Get oficina
     *
     * @return integer 
     */
    public function getOficina()
    {
        return $this->oficina;
    }

    /**
     * Set ejecutivo
     *
     * @param string $ejecutivo
     * @return Correos
     */
    public function setEjecutivo($ejecutivo)
    {
        $this->ejecutivo = $ejecutivo;

        return $this;
    }

    /**
     * Get ejecutivo
     *
     * @return string 
     */
    public function getEjecutivo()
    {
        return $this->ejecutivo;
    }

    /**
     * Set campo
     *
     * @param string $campo
     * @return Correos
     */
    public function setCampo($campo)
    {
        $this->campo = $campo;

        return $this;
    }

    /**
     * Get campo
     *
     * @return string 
     */
    public function getCampo()
    {
        return $this->campo;
    }

    /**
     * Set idEnv
     *
     * @param integer $idEnv
     * @return Correos
     */
    public function setIdEnv($idEnv)
    {
        $this->idEnv = $idEnv;

        return $this;
    }

    /**
     * Get idEnv
     *
     * @return integer 
     */
    public function getIdEnv()
    {
        return $this->idEnv;
    }

    /**
     * Set usuario
     *
     * @param string $usuario
     * @return Correos
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return string 
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * Set enviado
     *
     * @param integer $enviado
     * @return Correos
     */
    public function setEnviado($enviado)
    {
        $this->enviado = $enviado;

        return $this;
    }

    /**
     * Get enviado
     *
     * @return integer 
     */
    public function getEnviado()
    {
        return $this->enviado;
    }
}
