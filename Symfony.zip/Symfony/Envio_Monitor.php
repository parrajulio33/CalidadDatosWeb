<?php
	

    date_default_timezone_set("America/Caracas");


	include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.phpmailer.php');
	include_once('C:\xampp\htdocs\Aplicativo\web\clases\class.smtp.php');

	set_time_limit(0);
	ini_set("memory_limit",-1);	


	$link = mysql_connect('localhost:3307', 'root', '') or die('No se pudo conectar: ' . mysql_error());
	mysql_select_db('calidad') or die('No se pudo seleccionar la base de datos');	
	$result = mysql_query('SELECT A.AGENCIA, B.NOMBRE_OFICINA, B.EMAIL FROM monitorplus AS A LEFT JOIN OFICINAS AS B ON A.AGENCIA = B.OFICINA WHERE A.ESTADO_ENVIO = 0 GROUP BY A.AGENCIA') or die('Consulta fallida: ' . mysql_error());

	while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) 
	{	
		ECHO $line['AGENCIA']." - ".$line['NOMBRE_OFICINA']."\n";

		$result2 = mysql_query('SELECT * FROM monitorplus AS A INNER JOIN alertas AS B ON A.CONDICION = B.CODIGO WHERE A.AGENCIA = '.$line['AGENCIA'].' AND A.ESTADO_ENVIO = 0 GROUP BY A.CLIENTE, A.CONDICION') or die('Consulta fallida: ' . mysql_error());

		$row = "";

		while ($line2 = mysql_fetch_array($result2, MYSQL_ASSOC)) 
		{
			//print_r($line2);


			/*
			$line2['ID'] 
			$line2['BANCO'] 
			$line2['AGENCIA'] 
			$line2['CLIENTE'] 
			$line2['NOMCLIENTE'] 
			$line2['USUARIO'] 
			$line2['CUENTA'] 
			$line2['BANCA'] 
			$line2['EJECUTIVO'] 
			$line2['CONDICION'] 
			$line2['FECHARECEP'] 
			$line2['FECHAAPER'] 
			$line2['ENCARGADO'] 
			$line2['ESTADO_ENVIO'] 
			$line2['ARCHIVO'] 
			$line2['CODIGO'] 
			$line2['DESCRIPCION'] 
			$line2['CAMPO'] 
			*/



			$row .= "<tr>";
			$row .= "<td align='center'>".$line2['CLIENTE']."</td>";
			$row .= "<td>".$line2['NOMCLIENTE']."</td>";
			$row .= "<td align='center'>".$line2['IDENTIFICACION'] ."</td>";
			$row .= "<td align='center'>".$line2['CAMPO']."</td>";
			$row .= "</tr>";
			//echo "INSERT INTO solicitudes (TIPO_GESTION, EST_ENVIO, BANCO, OFICINA, CLIENTE, EJECUTIVO, ALERTA, FECHA_RECEPCION, USUARIO_ENCARGADO, NOMBRE_CLIENTE, DESCRIPCION) VALUES 		('MONITOR PLUS', '1', 'BOD', ".$line2['AGENCIA'].", ".$line2['CLIENTE'].", ".$line2['EJECUTIVO'].", ".$line2['CONDICION'].", '".$line2['FECHARECEP']."', '".$line2['ENCARGADO'] ."', '".$line2['NOMCLIENTE']."', '".$line2['DESCRIPCION'] ."')\n";
			mysql_query("INSERT INTO solicitudes (TIPO_GESTION, EST_ENVIO, BANCO, OFICINA, CLIENTE, EJECUTIVO, ALERTA, FECHA_RECEPCION, USUARIO_ENCARGADO, NOMBRE_CLIENTE, DESCRIPCION) VALUES 		('MONITOR PLUS', '1', 'BOD', ".$line2['AGENCIA'].", ".$line2['CLIENTE'].", '".$line2['EJECUTIVO']."', ".$line2['CONDICION'].", '".$line2['FECHARECEP']."', '".$line2['ENCARGADO'] ."', '".$line2['NOMCLIENTE']."', '".$line2['DESCRIPCION'] ."')")  or die('Consulta fallida: ' . mysql_error());
			
		}

		//SendMail($row,$line['EMAIL']);



		

		echo "=================================================================\n";

	}






	function SendMail($row,$email)
	{
		$asunto = "ACTUALIZACION DE DATOS (MP)";

        $body = "
                    <div style=\"font-family:Trebuchet MS\">
                        Buen d&iacute;a
                        
                        <p>En el marco del mejoramiento continuo de nuestros procesos y cumpliendo con las normativas que rigen nuestras operaciones, a trav&eacute;s de este medio queremos hacer de su conocimiento la importancia de mantener los datos de los clientes actualizados y consistentes. Para esto la Gerencia de Gesti&oacute;n de Dato y Configuraci&oacute;n de Producto, adscrita a la Vicepresidencia de Gesti&oacute;n para Calidad de Datos, ha dise&ntilde;ado un <i><u><b>Operativo Especial de Actualizaci&oacute;n de Datos</b></u></i> en conjunto con la Red de Agencias. Esta importancia radica principalmente en el mejoramiento del servicio prestado por nuestra instituci&oacute;n, as&iacute; como tambi&eacute;n evitar una posible sanci&oacute;n por parte de los entes regulatorios (SUDEBAN).</p>
                        <p>Se requiere con caracter urgente la actualizacion de los siguientes clientes:</p>
                        
                        <table style=\"border:1px solid #ccc\" cellpadding=\"0\" cellspacing=\"5\" width=\"100%\">
                            <thead>
                                <tr bgcolor=\"#C4D79B\" bordercolordark=\"#666666\">
                                    <th><b>Cliente Nro.</b></th>
                                    <th><b>Nombre</b></th>
                                    <th><b>Iidentificacion</b></th>
                                    <th><b>Campo a Actualizar</b></th>
                                </tr>
                            </thead>
                            <tbody>
                                ".$row."
                            </tbody>
                        </table>
                        <br><br>

                        <p>Es importante mencionar que la actualizaci&oacute;n deben ejecutarla cumpliendo con lo normado en el Manual de Normas y Procedimientos 002-02-A. </p>
                        
                        <p>\"6.5. Toda modificaci&oacute;n o actualizaci&oacute;n de datos de clientes efectuada en la plataforma GlobalFs debe estar soportada por dos ejemplares del formulario Registro Integral (Persona Natural) Mod. OP/ON-F-0059 o Registro Integral (Persona Jur&iacute;dica) Mod. OP/ON-F-0060 generado por el sistema, para la firma del Cliente y funcionario del banco.\"</p>
                        
                        <p>Sin nada m&aacute;s a que hacer referencia. </p>
                        
                        
                        <img src='C:\\xampp\\htdocs\\Symfony\\web\\firma.jpg'>
                    </div>        
                ";

        $mail = new \PHPMailer();
        $mail->IsSMTP(); 
        $mail->IsHTML(true);
        $mail->Host = "mail.bod.com.ve";
        $mail->From = "MONITORCD@bod.com.ve";
        $mail->FromName = "MONITORCD";
        $mail->Subject = $asunto;
        $mail->AltBody = ""; 
        $mail->MsgHTML($body);


        //$correo = explode(";",$Correos);

        //foreach ($correo as $cor) {
        //    $mail->AddAddress($cor);
        //}

        $mail->AddAddress("gsilva@bod.com.ve");
       
        //$mail->AddAddress("gsilva@bod.com.ve");
        //$mail->AddBCC("marinconr@bod.com.ve");
        //$mail->AddBCC("nfernandez@bod.com.ve");
        //$mail->AddBCC("gsilva@bod.com.ve");
        //$mail->AddBCC("JREVILLA@bod.com.ve");
        $mail->SMTPAuth = false;


        return $mail->send();
        
        
	}//sendmail
	

	function limpiar($String){

        $String = str_replace(array('á','à'),"&aacute;",$String);
        $String = str_replace(array('Á','À'),"&Aacute;",$String);
        $String = str_replace(array('é','è'),"&eacute;",$String);
        $String = str_replace(array('É','È'),"&Eacute;",$String);

        $String = str_replace(array('Í','Ì'),"&Iacute;",$String);
        $String = str_replace(array('í','ì'),"&iacute;",$String);
        
        $String = str_replace(array('ó','ò'),"&oacute;",$String);
        $String = str_replace(array('Ó','Ò'),"&Oacute;",$String);
        $String = str_replace(array('ú','ù'),"&uacute;",$String);
        $String = str_replace(array('Ú','Ù'),"&Uacute;",$String);

        $String = str_replace("Ñ","&Ntilde;",$String);
        $String = str_replace("ñ","&ntilde;",$String);


        return $String;
    }



?>

